
var GENRES = [
    {
  "name": "Glitch Capitalism",
  "scale": "hyper_exploitation",
  "root": "F#",
  "bpm": 155,
  "roles": {
    "lead": { "oct": [5, 6] },
    "bass": { "oct": [1, 2] },
    "chords": { "oct": [3, 4] },
    "drums": { "kit": "industrial" }
  },
  "wave": "square",
  "instruments": { "lead": 87, "bass": 39, "chords": 97 },
  "leadOptions": [87, 81, 30, 102, 118],
  "bassOptions": [39, 38, 81, 110],
  "chordsOptions": [97, 91, 98, 101]
},
    {
        name: 'Ambient',
        scale: 'dorian',
        root: 'D',
        bpm: 80,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2, 3] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 88, bass: 35, chords: 92 },
        leadOptions: [88, 89, 92, 94, 73, 5, 90, 91, 95, 102, 99, 52, 53, 54, 96],
        bassOptions: [35, 32, 43, 36, 37, 38, 39, 87, 48, 49, 34, 33, 45, 46],
        chordsOptions: [92, 88, 48, 51, 5, 89, 90, 94, 95, 52, 53, 102, 99, 96, 97]
    },
    {
        name: 'Techno',
        scale: 'chromatic',
        root: 'C',
        bpm: 128,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 62 },
        leadOptions: [81, 80, 86, 62, 90, 87, 84, 85, 95, 102, 103, 82, 83, 104, 105],
        bassOptions: [39, 38, 87, 36, 37, 35, 81, 86, 85, 84, 83, 82, 104, 105],
        chordsOptions: [62, 90, 80, 18, 19, 17, 81, 87, 95, 102, 103, 104, 105, 106, 107]
    },
    {
        name: 'House',
        scale: 'major',
        root: 'G',
        bpm: 124,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '707' }
        },
        wave: 'triangle',
        instruments: { lead: 80, bass: 33, chords: 17 },
        leadOptions: [80, 4, 86, 81, 62, 5, 87, 90, 88, 89, 95, 82, 83, 84, 85],
        bassOptions: [33, 35, 38, 32, 34, 36, 37, 39, 87, 86, 85, 84, 83, 82],
        chordsOptions: [4, 5, 17, 90, 62, 16, 18, 19, 88, 89, 92, 93, 94, 95, 96]
    },
    {
        name: 'Trance',
        scale: 'major',
        root: 'D',
        bpm: 138,
        roles: {
            lead: { oct: [6] },
            bass: { oct: [2, 3] },
            chords: { oct: [4, 5] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 86, bass: 39, chords: 95 },
        leadOptions: [86, 81, 95, 84, 90, 87, 85, 82, 83, 102, 103, 104, 105, 106, 107],
        bassOptions: [39, 38, 87, 36, 37, 81, 86, 85, 84, 83, 82, 104, 105, 106],
        chordsOptions: [95, 90, 94, 88, 89, 91, 92, 102, 103, 99, 100, 101, 104, 105, 106]
    },
    {
        name: 'Drum&Bass',
        scale: 'minor',
        root: 'B',
        bpm: 170,
        roles: {
            lead: { oct: [6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'amen' }
        },
        wave: 'sine',
        instruments: { lead: 62, bass: 87, chords: 50 },
        leadOptions: [62, 39, 87, 81, 50, 51, 86, 85, 84, 102, 103, 104, 105, 106, 107],
        bassOptions: [87, 39, 38, 36, 37, 35, 81, 86, 85, 84, 83, 82, 104, 105, 106],
        chordsOptions: [50, 51, 90, 91, 92, 93, 94, 95, 102, 103, 104, 105, 106, 107, 108]
    },
    {
        name: 'Dubstep',
        scale: 'phrygian',
        root: 'E',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 39, chords: 118 },
        leadOptions: [87, 81, 62, 118, 86, 85, 84, 83, 102, 103, 104, 105, 106, 107],
        bassOptions: [39, 38, 87, 36, 37, 81, 86, 85, 84, 83, 82, 104, 105, 106],
        chordsOptions: [118, 87, 62, 97, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111]
    },
    {
        name: 'Pop',
        scale: 'major',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'pop' }
        },
        wave: 'sine',
        instruments: { lead: 5, bass: 33, chords: 25 },
        leadOptions: [5, 4, 73, 27, 48, 49, 52, 53, 1, 2, 6, 7, 8, 9, 10],
        bassOptions: [33, 34, 38, 32, 35, 36, 37, 39, 43, 44, 45, 46, 47, 48],
        chordsOptions: [25, 27, 5, 4, 1, 0, 2, 6, 7, 16, 17, 18, 19, 20, 21]
    },
    {
        name: 'Rock',
        scale: 'minor',
        root: 'E',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 29, 34, 18, 66, 67, 27, 28, 31, 25, 26, 32, 33, 35, 36],
        bassOptions: [34, 33, 35, 32, 36, 37, 38, 39, 43, 44, 45, 46, 47, 48],
        chordsOptions: [30, 29, 18, 17, 19, 27, 28, 25, 26, 16, 20, 21, 22, 23, 24]
    },
    {
        name: 'Metal',
        scale: 'phrygian',
        root: 'E',
        bpm: 150,
        roles: {
            lead: { oct: [6] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'metal' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 29, 34, 61, 87, 86, 85, 84, 83, 82, 81, 80, 79, 78],
        bassOptions: [34, 39, 33, 32, 36, 37, 38, 35, 43, 44, 45, 46, 47, 48],
        chordsOptions: [30, 29, 18, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71]
    },
    {
        name: 'Jazz',
        scale: 'dorian',
        root: 'G',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 65, bass: 32, chords: 26 },
        leadOptions: [65, 66, 56, 4, 11, 12, 13, 64, 67, 71, 73, 74, 75, 76, 77],
        bassOptions: [32, 35, 43, 33, 34, 36, 37, 38, 39, 40, 41, 42, 44, 45],
        chordsOptions: [26, 4, 16, 5, 0, 1, 2, 6, 7, 17, 18, 19, 20, 21, 22]
    },
    {
        name: 'Blues',
        scale: 'pentatonic',
        root: 'A',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'blues' }
        },
        wave: 'triangle',
        instruments: { lead: 66, bass: 33, chords: 17 },
        leadOptions: [66, 27, 30, 22, 17, 16, 18, 19, 20, 21, 23, 24, 25, 26],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45],
        chordsOptions: [17, 16, 4, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },
    {
        name: 'Funk',
        scale: 'dorian',
        root: 'D',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'funk' }
        },
        wave: 'triangle',
        instruments: { lead: 27, bass: 36, chords: 4 },
        leadOptions: [27, 36, 4, 65, 34, 35, 37, 38, 39, 40, 41, 42, 43, 44],
        bassOptions: [36, 37, 33, 34, 35, 38, 39, 40, 41, 42, 43, 44, 45, 46],
        chordsOptions: [4, 5, 27, 7, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    },
    {
        name: 'Reggae',
        scale: 'major',
        root: 'C',
        bpm: 74,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'reggae' }
        },
        wave: 'sine',
        instruments: { lead: 22, bass: 33, chords: 17 },
        leadOptions: [22, 35, 25, 66, 17, 16, 18, 19, 20, 21, 23, 24, 26, 27],
        bassOptions: [33, 35, 39, 32, 34, 36, 37, 38, 40, 41, 42, 43, 44, 45],
        chordsOptions: [17, 24, 25, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    },
    {
        name: 'Afrobeats',
        scale: 'major',
        root: 'F',
        bpm: 108,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'afro' }
        },
        wave: 'sine',
        instruments: { lead: 75, bass: 39, chords: 24 },
        leadOptions: [75, 73, 113, 24, 108, 109, 110, 111, 112, 114, 115, 116, 117, 118],
        bassOptions: [39, 32, 33, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44, 45],
        chordsOptions: [24, 25, 4, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124]
    },
    {
        name: 'Salsa',
        scale: 'major',
        root: 'C',
        bpm: 180,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'latin' }
        },
        wave: 'triangle',
        instruments: { lead: 56, bass: 33, chords: 0 },
        leadOptions: [56, 21, 114, 73, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        bassOptions: [33, 32, 35, 34, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45],
        chordsOptions: [0, 4, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]
    },
    {
        name: 'Klezmer',
        scale: 'phrygian',
        root: 'D',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'folk' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 32, chords: 40 },
        leadOptions: [21, 40, 71, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120],
        bassOptions: [32, 58, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54],
        chordsOptions: [40, 48, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]
    },
    {
        name: 'Indian Raga',
        scale: 'phrygian',
        root: 'C',
        bpm: 96,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2, 3] },
            chords: { oct: [3, 4] },
            drums: { kit: 'tabla' }
        },
        wave: 'sine',
        instruments: { lead: 104, bass: 105, chords: 107 },
        leadOptions: [104, 107, 77, 106, 105, 108, 109, 110, 111, 112, 113, 114, 115, 116],
        bassOptions: [105, 43, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 44],
        chordsOptions: [107, 104, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99]
    },
    {
        name: 'Middle Eastern',
        scale: 'phrygian',
        root: 'D',
        bpm: 112,
        roles: {
            lead: { oct: [6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'daf' }
        },
        wave: 'triangle',
        instruments: { lead: 111, bass: 32, chords: 106 },
        leadOptions: [111, 106, 104, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85],
        bassOptions: [32, 43, 35, 36, 37, 38, 39, 40, 41, 42, 44, 45, 46, 47],
        chordsOptions: [106, 104, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]
    },
    {
        name: 'Lo-Fi',
        scale: 'minor',
        root: 'G',
        bpm: 72,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'lofi' }
        },
        wave: 'sine',
        instruments: { lead: 4, bass: 33, chords: 89 },
        leadOptions: [4, 5, 89, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83],
        bassOptions: [33, 32, 39, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44, 45],
        chordsOptions: [89, 4, 5, 1, 2, 3, 6, 7, 8, 9, 10, 11, 12, 13]
    },
    {
        name: 'Experimental',
        scale: 'chromatic',
        root: 'C',
        bpm: 100,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'glitch' }
        },
        wave: 'square',
        instruments: { lead: 85, bass: 39, chords: 97 },
        leadOptions: [85, 97, 102, 118, 99, 100, 101, 103, 104, 105, 106, 107, 108, 109],
        bassOptions: [39, 38, 87, 86, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76],
        chordsOptions: [97, 102, 99, 90, 91, 92, 93, 94, 95, 96, 98, 100, 101, 103]
    },
    {
        name: 'Chiptune',
        scale: 'major',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [6] },
            bass: { oct: [2, 3] },
            chords: { oct: [4] },
            drums: { kit: 'chips' }
        },
        wave: 'square',
        instruments: { lead: 80, bass: 81, chords: 90 },
        leadOptions: [80, 81, 86, 82, 83, 84, 85, 87, 88, 89, 90, 91, 92, 93],
        bassOptions: [81, 38, 39, 80, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91],
        chordsOptions: [90, 80, 81, 88, 89, 91, 92, 93, 94, 95, 96, 97, 98, 99]
    },
    {
        name: 'Ribab (Rwira)',
        scale: 'pentatonic',
        root: 'A',
        bpm: 105,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'daf' }
        },
        wave: 'triangle',
        instruments: { lead: 110, bass: 35, chords: 25 },
        leadOptions: [110, 105, 104, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35],
        bassOptions: [35, 32, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54],
        chordsOptions: [25, 24, 73, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117]
    },
    {
        name: 'Rai',
        scale: 'phrygian',
        root: 'D',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'afro' }
        },
        wave: 'sawtooth',
        instruments: { lead: 66, bass: 33, chords: 21 },
        leadOptions: [66, 75, 21, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121],
        bassOptions: [33, 34, 36, 35, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46],
        chordsOptions: [21, 24, 17, 18, 19, 20, 22, 23, 25, 26, 27, 28, 29, 30]
    },
    {
        name: 'Chinese Classical',
        scale: 'pentatonic',
        root: 'G',
        bpm: 72,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [3, 4] },
            chords: { oct: [4, 5] },
            drums: { kit: 'chinese' }
        },
        wave: 'sine',
        instruments: { lead: 111, bass: 117, chords: 112 },
        leadOptions: [111, 106, 105, 104, 107, 108, 109, 110, 112, 113, 114, 115, 116, 117],
        bassOptions: [117, 107, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43],
        chordsOptions: [112, 107, 106, 105, 104, 108, 109, 110, 111, 113, 114, 115, 116, 117]
    },
    {
        name: 'Chinese Traditional',
        scale: 'pentatonic',
        root: 'C',
        bpm: 88,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2, 3] },
            chords: { oct: [3, 4] },
            drums: { kit: 'chinese_traditional' }
        },
        wave: 'triangle',
        instruments: { lead: 106, bass: 32, chords: 107 },
        leadOptions: [106, 105, 111, 104, 107, 108, 109, 110, 112, 113, 114, 115, 116, 117],
        bassOptions: [32, 117, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54],
        chordsOptions: [107, 112, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]
    },
    {
        name: 'Oriental',
        scale: 'phrygian',
        root: 'E',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'tabla' }
        },
        wave: 'sine',
        instruments: { lead: 111, bass: 43, chords: 104 },
        leadOptions: [111, 104, 106, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85],
        bassOptions: [43, 32, 35, 36, 37, 38, 39, 40, 41, 42, 44, 45, 46, 47],
        chordsOptions: [104, 106, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59]
    },
    {
        name: 'Bluegrass',
        scale: 'major',
        root: 'G',
        bpm: 160,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'folk' }
        },
        wave: 'triangle',
        instruments: { lead: 105, bass: 32, chords: 110 },
        leadOptions: [105, 110, 25, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
        bassOptions: [32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45],
        chordsOptions: [110, 105, 25, 24, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]
    },
    {
        name: 'Cinematic',
        scale: 'minor',
        root: 'A',
        bpm: 96,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'orchestral' }
        },
        wave: 'sine',
        instruments: { lead: 40, bass: 43, chords: 48 },
        leadOptions: [40, 44, 46, 56, 52, 97, 41, 42, 45, 47, 48, 49, 50, 51],
        bassOptions: [43, 32, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69],
        chordsOptions: [48, 49, 55, 14, 52, 53, 54, 56, 57, 58, 59, 60, 61, 62]
    },
    {
        name: 'Synthwave',
        scale: 'minor',
        root: 'F',
        bpm: 110,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'electro' }
        },
        wave: 'sawtooth',
        instruments: { lead: 86, bass: 38, chords: 90 },
        leadOptions: [86, 81, 80, 62, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104],
        bassOptions: [38, 39, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92],
        chordsOptions: [90, 88, 89, 4, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72]
    },
    {
        name: 'Trap',
        scale: 'minor',
        root: 'F',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'triangle',
        instruments: { lead: 81, bass: 87, chords: 88 },
        leadOptions: [81, 80, 87, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72],
        bassOptions: [87, 39, 38, 86, 85, 84, 83, 82, 81, 80, 79, 78, 77, 76],
        chordsOptions: [88, 90, 81, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72]
    },
	{
        name: 'Samba',
        scale: 'major',
        root: 'D',
        bpm: 110,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2, 3] },
            chords: { oct: [4, 5] },
            drums: { kit: 'samba' }
        },
        wave: 'triangle',
        instruments: { lead: 73, bass: 32, chords: 24 },
        leadOptions: [73, 72, 74, 75, 65, 66, 56, 57, 21, 22, 114, 115],
        bassOptions: [32, 33, 34, 35, 36, 43, 44, 45],
        chordsOptions: [24, 25, 26, 16, 17, 18, 19, 20, 21, 22, 23]
    },
    {
        name: 'Tango',
        scale: 'harmonic minor',
        root: 'A',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'tango' }
        },
        wave: 'sawtooth',
        instruments: { lead: 21, bass: 43, chords: 0 },
        leadOptions: [21, 23, 40, 41, 42, 68, 69, 71, 110, 111],
        bassOptions: [43, 32, 33, 34, 35, 36, 5, 6],
        chordsOptions: [0, 2, 6, 7, 16, 17, 18, 19, 20, 21, 22]
    },
    {
        name: 'Flamenco',
        scale: 'phrygian',
        root: 'E',
        bpm: 132,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2, 3] },
            chords: { oct: [3, 4] },
            drums: { kit: 'flamenco' }
        },
        wave: 'triangle',
        instruments: { lead: 24, bass: 32, chords: 24 },
        leadOptions: [24, 25, 26, 105, 106, 107, 40, 41, 73, 74],
        bassOptions: [32, 33, 35, 36, 43, 105, 106],
        chordsOptions: [24, 25, 26, 105, 106, 107, 16, 17, 18, 19, 20]
    },
    {
        name: 'Highlife',
        scale: 'major',
        root: 'F',
        bpm: 128,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'highlife' }
        },
        wave: 'sine',
        instruments: { lead: 27, bass: 36, chords: 17 },
        leadOptions: [27, 65, 66, 56, 57, 73, 74, 75, 113, 114],
        bassOptions: [36, 37, 33, 34, 35, 38, 39],
        chordsOptions: [17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27]
    },
    {
        name: 'Soukous',
        scale: 'major',
        root: 'G',
        bpm: 122,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'soukous' }
        },
        wave: 'triangle',
        instruments: { lead: 26, bass: 36, chords: 17 },
        leadOptions: [26, 27, 65, 66, 56, 73, 74, 113, 114, 115],
        bassOptions: [36, 37, 33, 34, 35, 38, 39],
        chordsOptions: [17, 18, 19, 20, 21, 22, 23, 24, 25, 26]
    },
    {
        name: 'Bhangra',
        scale: 'mixolydian',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'bhangra' }
        },
        wave: 'sawtooth',
        instruments: { lead: 104, bass: 38, chords: 52 },
        leadOptions: [104, 105, 106, 111, 77, 78, 16, 17, 18, 53],
        bassOptions: [38, 39, 33, 34, 35, 36, 37],
        chordsOptions: [52, 53, 16, 17, 18, 19, 20, 21, 22, 23, 24]
    },
    {
        name: 'Balkan Brass',
        scale: 'minor',
        root: 'G',
        bpm: 180,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'balkan' }
        },
        wave: 'square',
        instruments: { lead: 56, bass: 58, chords: 61 },
        leadOptions: [56, 57, 59, 60, 61, 62, 63, 64, 65, 66],
        bassOptions: [58, 43, 44, 45, 46, 47, 48, 34],
        chordsOptions: [61, 62, 63, 48, 49, 50, 51, 52, 53, 54, 55]
    },
    {
        name: 'Zydeco',
        scale: 'mixolydian',
        root: 'A',
        bpm: 132,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'zydeco' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 32, chords: 17 },
        leadOptions: [21, 22, 110, 105, 66, 67, 16, 17, 18],
        bassOptions: [32, 33, 34, 35, 36, 37, 38, 39],
        chordsOptions: [17, 16, 18, 19, 20, 21, 22, 23, 24, 25, 26]
    },
    {
        name: 'Cumbia',
        scale: 'minor',
        root: 'A',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'cumbia' }
        },
        wave: 'sine',
        instruments: { lead: 65, bass: 33, chords: 23 },
        leadOptions: [65, 66, 64, 56, 57, 21, 22, 23, 114, 115],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [23, 21, 22, 16, 17, 18, 19, 20, 24, 25, 26]
    },
    {
        name: 'Mariachi',
        scale: 'major',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'mariachi' }
        },
        wave: 'sawtooth',
        instruments: { lead: 56, bass: 43, chords: 25 },
        leadOptions: [56, 57, 59, 60, 65, 66, 64, 21, 22, 23],
        bassOptions: [43, 32, 33, 34, 35, 36, 5, 6],
        chordsOptions: [25, 26, 27, 16, 17, 18, 19, 20, 21, 22, 23]
    },
    {
        name: 'Polka',
        scale: 'major',
        root: 'F',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'polka' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 43, chords: 17 },
        leadOptions: [21, 22, 23, 65, 66, 64, 72, 73, 74, 13],
        bassOptions: [43, 32, 33, 34, 35, 36, 5, 6],
        chordsOptions: [17, 16, 18, 19, 20, 21, 22, 23, 24, 25, 26]
    },
    {
        name: 'Gospel',
        scale: 'major',
        root: 'Eb',
        bpm: 90,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'gospel' }
        },
        wave: 'sine',
        instruments: { lead: 53, bass: 33, chords: 1 },
        leadOptions: [53, 52, 54, 5, 4, 16, 17, 18, 19, 48],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [1, 0, 2, 16, 17, 18, 19, 20, 21, 48, 49]
    },
    {
        name: 'Ska',
        scale: 'major',
        root: 'G',
        bpm: 180,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'ska' }
        },
        wave: 'square',
        instruments: { lead: 57, bass: 34, chords: 17 },
        leadOptions: [57, 56, 59, 60, 65, 66, 27, 28, 29, 30],
        bassOptions: [34, 33, 35, 32, 36, 37, 38, 39],
        chordsOptions: [17, 16, 18, 19, 27, 28, 29, 30, 25, 26, 24]
    },
    {
        name: 'Soca',
        scale: 'major',
        root: 'C',
        bpm: 115,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'soca' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 17 },
        leadOptions: [81, 80, 82, 83, 84, 85, 55, 56, 57, 114],
        bassOptions: [39, 38, 87, 36, 37, 35, 81, 86],
        chordsOptions: [17, 18, 19, 80, 81, 82, 83, 84, 85, 55, 56]
    },
    {
        name: 'Juju',
        scale: 'major',
        root: 'F',
        bpm: 108,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'juju' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 16 },
        leadOptions: [24, 25, 26, 108, 109, 73, 74, 75, 113, 114],
        bassOptions: [32, 33, 34, 35, 36, 37, 38, 39],
        chordsOptions: [16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26]
    },
    {
        name: 'Mbalax',
        scale: 'mixolydian',
        root: 'D',
        bpm: 125,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'mbalax' }
        },
        wave: 'triangle',
        instruments: { lead: 66, bass: 36, chords: 17 },
        leadOptions: [66, 65, 67, 56, 57, 73, 74, 111, 112, 113],
        bassOptions: [36, 37, 33, 34, 35, 38, 39],
        chordsOptions: [17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27]
    },
    {
        name: 'Bossa Nova',
        scale: 'major',
        root: 'E',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'bossa' }
        },
        wave: 'sine',
        instruments: { lead: 73, bass: 32, chords: 24 },
        leadOptions: [73, 24, 65, 75, 74, 76, 77, 78, 79, 21],
        bassOptions: [32, 35, 24, 25, 26, 27, 28, 29],
        chordsOptions: [24, 26, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    },
    {
        name: 'Forró',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'forro' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 32, chords: 24 },
        leadOptions: [21, 23, 73, 74, 75, 65, 66, 64, 114, 115],
        bassOptions: [32, 33, 34, 35, 36, 37, 38, 39],
        chordsOptions: [24, 25, 26, 16, 17, 18, 19, 20, 21, 22, 23]
    },
    {
        name: 'Calypso',
        scale: 'major',
        root: 'G',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'calypso' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 33, chords: 24 },
        leadOptions: [114, 113, 115, 75, 76, 77, 21, 22, 23, 73],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [24, 25, 26, 16, 17, 18, 19, 20, 21, 22, 23]
    },
    {
        name: 'Gagaku',
        scale: 'pentatonic',
        root: 'D',
        bpm: 60,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [3, 4] },
            chords: { oct: [4, 5] },
            drums: { kit: 'gagaku' }
        },
        wave: 'sine',
        instruments: { lead: 77, bass: 43, chords: 107 },
        leadOptions: [77, 78, 79, 106, 107, 108, 73, 74, 75, 76],
        bassOptions: [43, 32, 33, 34, 35, 36, 37, 38],
        chordsOptions: [107, 106, 77, 78, 79, 73, 74, 75, 76, 13, 14]
    },
	  {
        name: 'Griot',
        scale: 'pentatonic',
        root: 'F',
        bpm: 95,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'griot' }
        },
        wave: 'sine',
        instruments: { lead: 108, bass: 32, chords: 106 },
        leadOptions: [108, 104, 105, 107, 77, 78, 73, 74, 110, 111],
        bassOptions: [32, 33, 34, 35, 36, 43, 108, 107],
        chordsOptions: [106, 107, 108, 104, 105, 24, 25, 26, 16, 17]
    },
    {
        name: 'Qawwali',
        scale: 'phrygian',
        root: 'C',
        bpm: 85,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'qawwali' }
        },
        wave: 'sine',
        instruments: { lead: 105, bass: 43, chords: 52 },
        leadOptions: [105, 104, 111, 53, 54, 52, 21, 22, 73, 74],
        bassOptions: [43, 32, 33, 34, 35, 36, 105, 104],
        chordsOptions: [52, 53, 54, 105, 104, 16, 17, 18, 19, 20]
    },
    {
        name: 'Fado',
        scale: 'harmonic_minor',
        root: 'D',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'fado' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 24 },
        leadOptions: [24, 25, 40, 41, 42, 68, 69, 71, 73, 74],
        bassOptions: [32, 33, 34, 35, 36, 43, 24, 25],
        chordsOptions: [24, 25, 40, 41, 42, 16, 17, 18, 19, 20]
    },
    {
        name: 'Andean',
        scale: 'pentatonic',
        root: 'G',
        bpm: 110,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'andean' }
        },
        wave: 'triangle',
        instruments: { lead: 79, bass: 32, chords: 24 },
        leadOptions: [79, 75, 76, 77, 78, 73, 74, 21, 22, 23],
        bassOptions: [32, 33, 34, 35, 36, 43, 79, 75],
        chordsOptions: [24, 25, 79, 75, 76, 16, 17, 18, 19, 20]
    },
    {
        name: 'Gregorian Chant',
        scale: 'dorian',
        root: 'D',
        bpm: 60,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [1, 2] },
            chords: { oct: [2, 3] },
            drums: { kit: 'chant' }
        },
        wave: 'sine',
        instruments: { lead: 52, bass: 43, chords: 52 },
        leadOptions: [52, 53, 54, 19, 20, 91, 92, 48, 49, 50],
        bassOptions: [43, 32, 33, 34, 35, 36, 52, 53],
        chordsOptions: [52, 53, 54, 19, 20, 91, 92, 48, 49, 50]
    },
    {
        name: 'Boogie Woogie',
        scale: 'blues',
        root: 'C',
        bpm: 160,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'boogie' }
        },
        wave: 'triangle',
        instruments: { lead: 4, bass: 33, chords: 4 },
        leadOptions: [4, 5, 16, 17, 18, 7, 6, 2, 3, 1],
        bassOptions: [33, 34, 35, 36, 37, 4, 5, 16],
        chordsOptions: [4, 5, 16, 17, 18, 7, 6, 2, 3, 1]
    },
    {
        name: 'Motown',
        scale: 'major',
        root: 'Eb',
        bpm: 112,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'motown' }
        },
        wave: 'sine',
        instruments: { lead: 53, bass: 33, chords: 5 },
        leadOptions: [53, 52, 54, 5, 4, 27, 28, 65, 66, 56],
        bassOptions: [33, 34, 35, 36, 37, 53, 52, 5],
        chordsOptions: [5, 4, 53, 52, 54, 27, 28, 65, 66, 16]
    },
    {
        name: 'Disco',
        scale: 'major',
        root: 'F',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'disco' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 36, chords: 17 },
        leadOptions: [81, 80, 82, 83, 84, 85, 55, 56, 57, 27],
        bassOptions: [36, 37, 33, 34, 35, 81, 80, 17],
        chordsOptions: [17, 16, 81, 80, 82, 55, 56, 57, 27, 28]
    },
    {
        name: 'New Wave',
        scale: 'minor',
        root: 'D',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'newwave' }
        },
        wave: 'square',
        instruments: { lead: 82, bass: 39, chords: 90 },
        leadOptions: [82, 81, 83, 84, 85, 86, 87, 88, 89, 5],
        bassOptions: [39, 38, 37, 36, 35, 82, 81, 90],
        chordsOptions: [90, 88, 89, 82, 81, 83, 84, 85, 86, 87]
    },
    {
        name: 'Grunge',
        scale: 'minor',
        root: 'E',
        bpm: 110,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'grunge' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 29, 31, 27, 28, 25, 26, 17, 18, 19],
        bassOptions: [34, 33, 35, 32, 36, 37, 30, 29],
        chordsOptions: [30, 29, 31, 27, 28, 25, 26, 17, 18, 19]
    },
    {
        name: 'Trip Hop',
        scale: 'minor',
        root: 'G',
        bpm: 90,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'triphop' }
        },
        wave: 'sine',
        instruments: { lead: 91, bass: 39, chords: 89 },
        leadOptions: [91, 90, 92, 93, 94, 95, 54, 53, 52, 102],
        bassOptions: [39, 38, 37, 36, 35, 91, 90, 89],
        chordsOptions: [89, 88, 90, 91, 92, 93, 94, 95, 54, 53]
    },
    {
        name: 'Dub',
        scale: 'minor',
        root: 'C',
        bpm: 85,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'dub' }
        },
        wave: 'sine',
        instruments: { lead: 102, bass: 39, chords: 97 },
        leadOptions: [102, 103, 99, 100, 101, 98, 96, 95, 94, 118],
        bassOptions: [39, 38, 37, 36, 35, 102, 103, 97],
        chordsOptions: [97, 96, 98, 102, 103, 99, 100, 101, 95, 94]
    },
    {
        name: 'Psychedelic Rock',
        scale: 'mixolydian',
        root: 'A',
        bpm: 115,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'psych' }
        },
        wave: 'sawtooth',
        instruments: { lead: 27, bass: 34, chords: 17 },
        leadOptions: [27, 28, 29, 30, 31, 16, 17, 18, 19, 20],
        bassOptions: [34, 33, 35, 32, 36, 37, 27, 28],
        chordsOptions: [17, 16, 18, 27, 28, 29, 30, 31, 19, 20]
    },
    {
        name: 'Baroque',
        scale: 'major',
        root: 'D',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'baroque' }
        },
        wave: 'sine',
        instruments: { lead: 6, bass: 43, chords: 6 },
        leadOptions: [6, 7, 0, 1, 2, 46, 47, 40, 41, 42],
        bassOptions: [43, 32, 33, 34, 35, 36, 6, 7],
        chordsOptions: [6, 7, 0, 1, 2, 46, 47, 40, 41, 42]
    },
    {
        name: 'Renaissance',
        scale: 'dorian',
        root: 'G',
        bpm: 90,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'renaissance' }
        },
        wave: 'sine',
        instruments: { lead: 74, bass: 43, chords: 46 },
        leadOptions: [74, 73, 75, 76, 77, 6, 7, 46, 47, 13],
        bassOptions: [43, 32, 33, 34, 35, 36, 74, 73],
        chordsOptions: [46, 47, 74, 73, 75, 6, 7, 76, 77, 13]
    },
    {
        name: 'Minimalism',
        scale: 'chromatic',
        root: 'C',
        bpm: 70,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'minimal' }
        },
        wave: 'sine',
        instruments: { lead: 11, bass: 43, chords: 11 },
        leadOptions: [11, 12, 13, 14, 8, 9, 10, 0, 1, 2],
        bassOptions: [43, 32, 33, 34, 35, 36, 11, 12],
        chordsOptions: [11, 12, 13, 14, 8, 9, 10, 0, 1, 2]
    },
    {
        name: 'Post Rock',
        scale: 'minor',
        root: 'F',
        bpm: 95,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'postrock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 92, bass: 34, chords: 92 },
        leadOptions: [92, 93, 94, 95, 48, 49, 50, 51, 40, 41],
        bassOptions: [34, 33, 35, 32, 36, 37, 92, 93],
        chordsOptions: [92, 93, 94, 95, 48, 49, 50, 51, 40, 41]
    },
    {
        name: 'Shoegaze',
        scale: 'major',
        root: 'E',
        bpm: 105,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'shoegaze' }
        },
        wave: 'sawtooth',
        instruments: { lead: 94, bass: 34, chords: 94 },
        leadOptions: [94, 95, 92, 93, 90, 91, 88, 89, 102, 103],
        bassOptions: [34, 33, 35, 32, 36, 37, 94, 95],
        chordsOptions: [94, 95, 92, 93, 90, 91, 88, 89, 102, 103]
    },
    {
        name: 'Noise',
        scale: 'chromatic',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [3, 4, 5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [2, 3, 4] },
            drums: { kit: 'noise' }
        },
        wave: 'square',
        instruments: { lead: 118, bass: 39, chords: 119 },
        leadOptions: [118, 119, 120, 121, 122, 123, 124, 125, 126, 127],
        bassOptions: [39, 38, 37, 36, 35, 118, 119, 120],
        chordsOptions: [119, 118, 120, 121, 122, 123, 124, 125, 126, 127]
    },
    {
        name: 'Drone',
        scale: 'chromatic',
        root: 'D',
        bpm: 60,
        roles: {
            lead: { oct: [2, 3] },
            bass: { oct: [1, 2] },
            chords: { oct: [2, 3] },
            drums: { kit: 'drone' }
        },
        wave: 'sine',
        instruments: { lead: 93, bass: 43, chords: 93 },
        leadOptions: [93, 94, 95, 92, 91, 90, 89, 88, 48, 49],
        bassOptions: [43, 32, 33, 34, 35, 36, 93, 94],
        chordsOptions: [93, 94, 95, 92, 91, 90, 89, 88, 48, 49]
    },
    {
        name: 'Waltz',
        scale: 'major',
        root: 'C',
        bpm: 180,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'waltz' }
        },
        wave: 'sine',
        instruments: { lead: 48, bass: 43, chords: 0 },
        leadOptions: [48, 49, 0, 1, 2, 40, 41, 42, 46, 47],
        bassOptions: [43, 32, 33, 34, 35, 36, 48, 49],
        chordsOptions: [0, 1, 2, 48, 49, 40, 41, 42, 46, 47]
    },
    {
        name: 'March',
        scale: 'major',
        root: 'G',
        bpm: 120,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'march' }
        },
        wave: 'square',
        instruments: { lead: 56, bass: 58, chords: 61 },
        leadOptions: [56, 57, 59, 60, 61, 62, 63, 47, 48, 49],
        bassOptions: [58, 43, 44, 45, 46, 47, 56, 57],
        chordsOptions: [61, 62, 63, 56, 57, 59, 60, 47, 48, 49]
    },
    {
        name: 'Sea Shanty',
        scale: 'mixolydian',
        root: 'D',
        bpm: 130,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'shanty' }
        },
        wave: 'sine',
        instruments: { lead: 21, bass: 32, chords: 21 },
        leadOptions: [21, 22, 23, 16, 17, 18, 19, 20, 73, 74],
        bassOptions: [32, 33, 34, 35, 36, 43, 21, 22],
        chordsOptions: [21, 22, 23, 16, 17, 18, 19, 20, 73, 74]
    },
	
    {
        name: 'Swing',
        scale: 'major',
        root: 'Bb',
        bpm: 180,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'swing' }
        },
        wave: 'triangle',
        instruments: { lead: 57, bass: 32, chords: 0 },
        leadOptions: [57, 56, 65, 66, 4, 5, 27, 28, 48, 49],
        bassOptions: [32, 33, 34, 35, 36, 43, 57, 56],
        chordsOptions: [0, 4, 5, 16, 17, 27, 28, 48, 49, 57]
    },
    {
        name: 'Bebop',
        scale: 'chromatic',
        root: 'F',
        bpm: 220,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'bebop' }
        },
        wave: 'sawtooth',
        instruments: { lead: 65, bass: 32, chords: 0 },
        leadOptions: [65, 66, 64, 56, 57, 4, 5, 27, 28, 11],
        bassOptions: [32, 33, 34, 35, 36, 43, 65, 66],
        chordsOptions: [0, 4, 5, 16, 17, 27, 28, 56, 57, 65]
    },
    {
        name: 'Cool Jazz',
        scale: 'dorian',
        root: 'D',
        bpm: 120,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'cooljazz' }
        },
        wave: 'sine',
        instruments: { lead: 73, bass: 32, chords: 5 },
        leadOptions: [73, 74, 65, 66, 4, 5, 11, 12, 48, 49],
        bassOptions: [32, 33, 34, 35, 36, 43, 73, 74],
        chordsOptions: [5, 4, 16, 17, 48, 49, 73, 74, 11, 12]
    },
    {
        name: 'Hard Bop',
        scale: 'blues',
        root: 'Eb',
        bpm: 200,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'hardbop' }
        },
        wave: 'sawtooth',
        instruments: { lead: 66, bass: 33, chords: 17 },
        leadOptions: [66, 65, 56, 57, 27, 28, 4, 5, 34, 35],
        bassOptions: [33, 34, 32, 35, 36, 43, 66, 65],
        chordsOptions: [17, 16, 27, 28, 4, 5, 34, 35, 56, 57]
    },
    {
        name: 'Free Jazz',
        scale: 'chromatic',
        root: 'C',
        bpm: 160,
        roles: {
            lead: { oct: [3, 4, 5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [2, 3, 4] },
            drums: { kit: 'freejazz' }
        },
        wave: 'square',
        instruments: { lead: 62, bass: 39, chords: 97 },
        leadOptions: [62, 63, 87, 86, 85, 118, 119, 102, 103, 55],
        bassOptions: [39, 38, 37, 36, 35, 62, 63, 87],
        chordsOptions: [97, 102, 103, 62, 63, 87, 86, 118, 119, 55]
    },
    {
        name: 'Modal Jazz',
        scale: 'dorian',
        root: 'D',
        bpm: 110,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'modaljazz' }
        },
        wave: 'sine',
        instruments: { lead: 71, bass: 32, chords: 5 },
        leadOptions: [71, 65, 66, 73, 74, 4, 5, 11, 12, 48],
        bassOptions: [32, 33, 34, 35, 36, 43, 71, 65],
        chordsOptions: [5, 4, 16, 17, 48, 49, 71, 65, 11, 12]
    },
    {
        name: 'Jazz Fusion',
        scale: 'chromatic',
        root: 'A',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'fusion' }
        },
        wave: 'sawtooth',
        instruments: { lead: 87, bass: 39, chords: 90 },
        leadOptions: [87, 81, 62, 63, 86, 85, 84, 27, 28, 65],
        bassOptions: [39, 38, 37, 36, 35, 87, 81, 62],
        chordsOptions: [90, 88, 89, 87, 81, 62, 63, 27, 28, 65]
    },
    {
        name: 'Smooth Jazz',
        scale: 'major',
        root: 'F',
        bpm: 95,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'smoothjazz' }
        },
        wave: 'sine',
        instruments: { lead: 66, bass: 33, chords: 5 },
        leadOptions: [66, 65, 73, 74, 4, 5, 27, 28, 48, 49],
        bassOptions: [33, 34, 32, 35, 36, 43, 66, 65],
        chordsOptions: [5, 4, 16, 17, 48, 49, 66, 65, 27, 28]
    },
    {
        name: 'J-Pop',
        scale: 'major',
        root: 'C',
        bpm: 128,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'jpop' }
        },
        wave: 'triangle',
        instruments: { lead: 81, bass: 33, chords: 5 },
        leadOptions: [81, 80, 82, 83, 84, 85, 48, 49, 27, 28],
        bassOptions: [33, 34, 32, 35, 36, 43, 81, 80],
        chordsOptions: [5, 4, 16, 17, 48, 49, 81, 80, 27, 28]
    },
    {
        name: 'K-Pop',
        scale: 'minor',
        root: 'G',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'kpop' }
        },
        wave: 'sawtooth',
        instruments: { lead: 87, bass: 39, chords: 90 },
        leadOptions: [87, 81, 82, 83, 84, 85, 48, 49, 27, 28],
        bassOptions: [39, 38, 37, 36, 35, 87, 81, 82],
        chordsOptions: [90, 88, 89, 87, 81, 82, 48, 49, 27, 28]
    },
    {
        name: 'City Pop',
        scale: 'major',
        root: 'F',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'citypop' }
        },
        wave: 'triangle',
        instruments: { lead: 86, bass: 36, chords: 5 },
        leadOptions: [86, 81, 82, 83, 84, 85, 48, 49, 27, 28],
        bassOptions: [36, 37, 33, 34, 35, 86, 81, 82],
        chordsOptions: [5, 4, 16, 17, 48, 49, 86, 81, 27, 28]
    },
    {
        name: 'Vaporwave',
        scale: 'major',
        root: 'Eb',
        bpm: 85,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'vaporwave' }
        },
        wave: 'sine',
        instruments: { lead: 90, bass: 39, chords: 5 },
        leadOptions: [90, 88, 89, 91, 92, 93, 94, 95, 48, 49],
        bassOptions: [39, 38, 37, 36, 35, 90, 88, 89],
        chordsOptions: [5, 4, 90, 88, 89, 91, 92, 48, 49, 16]
    },
    {
        name: 'Future Bass',
        scale: 'minor',
        root: 'F',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'futurebass' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [87, 39, 38, 86, 85, 84, 83, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Witch House',
        scale: 'minor',
        root: 'D',
        bpm: 110,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'witchhouse' }
        },
        wave: 'square',
        instruments: { lead: 102, bass: 39, chords: 97 },
        leadOptions: [102, 103, 99, 100, 101, 98, 96, 95, 94, 118],
        bassOptions: [39, 38, 37, 36, 35, 102, 103, 99],
        chordsOptions: [97, 96, 98, 102, 103, 99, 100, 101, 95, 94]
    },
    {
        name: 'Synthpop',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'synthpop' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [39, 38, 37, 36, 35, 81, 80, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Italo Disco',
        scale: 'major',
        root: 'F',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'italo' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [39, 38, 37, 36, 35, 81, 80, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Eurodance',
        scale: 'major',
        root: 'G',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'eurodance' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [39, 38, 37, 36, 35, 81, 80, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Hardstyle',
        scale: 'minor',
        root: 'A',
        bpm: 150,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'hardstyle' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [87, 39, 38, 86, 85, 84, 83, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Gabber',
        scale: 'chromatic',
        root: 'C',
        bpm: 200,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1] },
            chords: { oct: [4] },
            drums: { kit: 'gabber' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 87, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [87, 39, 38, 86, 85, 84, 83, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Psytrance',
        scale: 'minor',
        root: 'D',
        bpm: 145,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'psytrance' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [87, 39, 38, 86, 85, 84, 83, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Goa Trance',
        scale: 'phrygian',
        root: 'E',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'goa' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [87, 39, 38, 86, 85, 84, 83, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Progressive House',
        scale: 'minor',
        root: 'F',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'proghouse' }
        },
        wave: 'sawtooth',
        instruments: { lead: 90, bass: 39, chords: 88 },
        leadOptions: [90, 88, 89, 91, 92, 93, 94, 95, 81, 82],
        bassOptions: [39, 38, 37, 36, 35, 90, 88, 89],
        chordsOptions: [88, 89, 90, 91, 92, 93, 94, 95, 81, 82]
    },
    {
        name: 'Deep House',
        scale: 'minor',
        root: 'G',
        bpm: 120,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'deephouse' }
        },
        wave: 'sine',
        instruments: { lead: 89, bass: 33, chords: 5 },
        leadOptions: [89, 88, 90, 91, 92, 93, 94, 95, 73, 74],
        bassOptions: [33, 34, 32, 35, 36, 43, 89, 88],
        chordsOptions: [5, 4, 89, 88, 90, 91, 73, 74, 16, 17]
    },
    {
        name: 'UK Garage',
        scale: 'minor',
        root: 'F',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'ukgarage' }
        },
        wave: 'triangle',
        instruments: { lead: 81, bass: 39, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [39, 38, 37, 36, 35, 81, 80, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Footwork',
        scale: 'chromatic',
        root: 'C',
        bpm: 160,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'footwork' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 87, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [87, 39, 38, 86, 85, 84, 83, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
    {
        name: 'Jungle',
        scale: 'minor',
        root: 'B',
        bpm: 170,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'jungle' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 90 },
        leadOptions: [81, 80, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [87, 39, 38, 86, 85, 84, 83, 82],
        chordsOptions: [90, 88, 89, 81, 80, 82, 83, 84, 85, 86]
    },
	    {
        name: 'Gypsy Jazz',
        scale: 'harmonic_minor',
        root: 'D',
        bpm: 200,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'gypsy' }
        },
        wave: 'triangle',
        instruments: { lead: 25, bass: 32, chords: 25 },
        leadOptions: [25, 26, 21, 22, 40, 41, 65, 66, 73, 74],
        bassOptions: [32, 33, 34, 35, 36, 43, 25, 26],
        chordsOptions: [25, 26, 21, 22, 16, 17, 18, 19, 20, 24]
    },
    {
        name: 'Mambo',
        scale: 'major',
        root: 'C',
        bpm: 200,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'mambo' }
        },
        wave: 'sawtooth',
        instruments: { lead: 56, bass: 33, chords: 17 },
        leadOptions: [56, 57, 65, 66, 21, 22, 114, 115, 73, 74],
        bassOptions: [33, 34, 32, 35, 36, 43, 56, 57],
        chordsOptions: [17, 16, 21, 22, 114, 115, 24, 25, 26, 27]
    },
    {
        name: 'Merengue',
        scale: 'major',
        root: 'A',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'merengue' }
        },
        wave: 'triangle',
        instruments: { lead: 114, bass: 33, chords: 17 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 56, 57, 65],
        bassOptions: [33, 34, 32, 35, 36, 43, 114, 113],
        chordsOptions: [17, 16, 21, 22, 114, 113, 24, 25, 26, 27]
    },
    {
        name: 'Bachata',
        scale: 'minor',
        root: 'A',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'bachata' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 24 },
        leadOptions: [24, 25, 21, 22, 73, 74, 114, 115, 65, 66],
        bassOptions: [32, 33, 34, 35, 36, 43, 24, 25],
        chordsOptions: [24, 25, 21, 22, 16, 17, 18, 19, 20, 27]
    },
    {
        name: 'Son Cubano',
        scale: 'major',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'son' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 32, chords: 24 },
        leadOptions: [21, 22, 114, 115, 73, 74, 56, 57, 65, 66],
        bassOptions: [32, 33, 34, 35, 36, 43, 21, 22],
        chordsOptions: [24, 25, 21, 22, 16, 17, 18, 19, 20, 27]
    },
    {
        name: 'Rumba',
        scale: 'phrygian',
        root: 'E',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'rumba' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 32, chords: 24 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 108, 109, 110],
        bassOptions: [32, 33, 34, 35, 36, 43, 114, 113],
        chordsOptions: [24, 25, 114, 113, 16, 17, 18, 19, 20, 21]
    },
    {
        name: 'Guaracha',
        scale: 'major',
        root: 'G',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'guaracha' }
        },
        wave: 'sawtooth',
        instruments: { lead: 56, bass: 33, chords: 17 },
        leadOptions: [56, 57, 21, 22, 114, 115, 73, 74, 65, 66],
        bassOptions: [33, 34, 32, 35, 36, 43, 56, 57],
        chordsOptions: [17, 16, 21, 22, 114, 115, 24, 25, 26, 27]
    },
    {
        name: 'Cha Cha Cha',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'chacha' }
        },
        wave: 'triangle',
        instruments: { lead: 114, bass: 33, chords: 17 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 56, 57, 65],
        bassOptions: [33, 34, 32, 35, 36, 43, 114, 113],
        chordsOptions: [17, 16, 21, 22, 114, 113, 24, 25, 26, 27]
    },
    {
        name: 'Danzón',
        scale: 'major',
        root: 'G',
        bpm: 90,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'danzon' }
        },
        wave: 'sine',
        instruments: { lead: 73, bass: 32, chords: 0 },
        leadOptions: [73, 74, 21, 22, 56, 57, 65, 66, 40, 41],
        bassOptions: [32, 33, 34, 35, 36, 43, 73, 74],
        chordsOptions: [0, 4, 21, 22, 16, 17, 18, 19, 20, 48]
    },
    {
        name: 'Bolero',
        scale: 'minor',
        root: 'D',
        bpm: 80,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'bolero' }
        },
        wave: 'sine',
        instruments: { lead: 40, bass: 32, chords: 24 },
        leadOptions: [40, 41, 73, 74, 21, 22, 56, 57, 65, 66],
        bassOptions: [32, 33, 34, 35, 36, 43, 40, 41],
        chordsOptions: [24, 25, 40, 41, 16, 17, 18, 19, 20, 48]
    },
    {
        name: 'Pachanga',
        scale: 'major',
        root: 'F',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'pachanga' }
        },
        wave: 'sawtooth',
        instruments: { lead: 56, bass: 33, chords: 17 },
        leadOptions: [56, 57, 21, 22, 114, 115, 73, 74, 65, 66],
        bassOptions: [33, 34, 32, 35, 36, 43, 56, 57],
        chordsOptions: [17, 16, 21, 22, 114, 115, 24, 25, 26, 27]
    },
    {
        name: 'Timba',
        scale: 'chromatic',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'timba' }
        },
        wave: 'sawtooth',
        instruments: { lead: 62, bass: 39, chords: 17 },
        leadOptions: [62, 63, 56, 57, 21, 22, 114, 115, 73, 74],
        bassOptions: [39, 38, 33, 34, 35, 36, 62, 63],
        chordsOptions: [17, 16, 62, 63, 21, 22, 114, 115, 24, 25]
    },
    {
        name: 'Charanga',
        scale: 'major',
        root: 'D',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'charanga' }
        },
        wave: 'sine',
        instruments: { lead: 73, bass: 32, chords: 24 },
        leadOptions: [73, 74, 40, 41, 21, 22, 56, 57, 65, 66],
        bassOptions: [32, 33, 34, 35, 36, 43, 73, 74],
        chordsOptions: [24, 25, 73, 74, 16, 17, 18, 19, 20, 40]
    },
    {
        name: 'Mozambique',
        scale: 'major',
        root: 'F',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'mozambique' }
        },
        wave: 'triangle',
        instruments: { lead: 114, bass: 33, chords: 17 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 56, 57, 65],
        bassOptions: [33, 34, 32, 35, 36, 43, 114, 113],
        chordsOptions: [17, 16, 21, 22, 114, 113, 24, 25, 26, 27]
    },
    {
        name: 'Conga',
        scale: 'major',
        root: 'G',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'conga' }
        },
        wave: 'sawtooth',
        instruments: { lead: 114, bass: 33, chords: 17 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 56, 57, 65],
        bassOptions: [33, 34, 32, 35, 36, 43, 114, 113],
        chordsOptions: [17, 16, 21, 22, 114, 113, 24, 25, 26, 27]
    },
    {
        name: 'Bomba',
        scale: 'phrygian',
        root: 'E',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'bomba' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 32, chords: 24 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 108, 109, 110],
        bassOptions: [32, 33, 34, 35, 36, 43, 114, 113],
        chordsOptions: [24, 25, 114, 113, 16, 17, 18, 19, 20, 21]
    },
    {
        name: 'Plena',
        scale: 'major',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'plena' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 32, chords: 24 },
        leadOptions: [21, 22, 114, 115, 73, 74, 56, 57, 65, 66],
        bassOptions: [32, 33, 34, 35, 36, 43, 21, 22],
        chordsOptions: [24, 25, 21, 22, 16, 17, 18, 19, 20, 27]
    },
    {
        name: 'Guajira',
        scale: 'major',
        root: 'A',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'guajira' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 24 },
        leadOptions: [24, 25, 21, 22, 73, 74, 114, 115, 65, 66],
        bassOptions: [32, 33, 34, 35, 36, 43, 24, 25],
        chordsOptions: [24, 25, 21, 22, 16, 17, 18, 19, 20, 27]
    },
    {
        name: 'Son Montuno',
        scale: 'major',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'montuno' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 32, chords: 24 },
        leadOptions: [21, 22, 114, 115, 73, 74, 56, 57, 65, 66],
        bassOptions: [32, 33, 34, 35, 36, 43, 21, 22],
        chordsOptions: [24, 25, 21, 22, 16, 17, 18, 19, 20, 27]
    },
    {
        name: 'Guaguancó',
        scale: 'phrygian',
        root: 'E',
        bpm: 105,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'guaguanco' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 32, chords: 24 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 108, 109, 110],
        bassOptions: [32, 33, 34, 35, 36, 43, 114, 113],
        chordsOptions: [24, 25, 114, 113, 16, 17, 18, 19, 20, 21]
    },
    {
        name: 'Colombia',
        scale: 'minor',
        root: 'A',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'colombia' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 32, chords: 24 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 108, 109, 110],
        bassOptions: [32, 33, 34, 35, 36, 43, 114, 113],
        chordsOptions: [24, 25, 114, 113, 16, 17, 18, 19, 20, 21]
    },
    {
        name: 'Yambú',
        scale: 'phrygian',
        root: 'D',
        bpm: 85,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'yambu' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 32, chords: 24 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 108, 109, 110],
        bassOptions: [32, 33, 34, 35, 36, 43, 114, 113],
        chordsOptions: [24, 25, 114, 113, 16, 17, 18, 19, 20, 21]
    },
    {
        name: 'Guarapachangueo',
        scale: 'chromatic',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'guarapachangueo' }
        },
        wave: 'sawtooth',
        instruments: { lead: 114, bass: 39, chords: 17 },
        leadOptions: [114, 113, 115, 21, 22, 73, 74, 108, 109, 110],
        bassOptions: [39, 38, 33, 34, 35, 36, 114, 113],
        chordsOptions: [17, 16, 114, 113, 21, 22, 24, 25, 26, 27]
    },
    {
        name: 'Batá',
        scale: 'pentatonic',
        root: 'D',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'bata' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 32, chords: 24 },
        leadOptions: [114, 113, 115, 108, 109, 110, 73, 74, 21, 22],
        bassOptions: [32, 33, 34, 35, 36, 43, 114, 113],
        chordsOptions: [24, 25, 114, 113, 16, 17, 18, 19, 20, 21]
    },
    {
        name: 'Iyesá',
        scale: 'phrygian',
        root: 'E',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'iyesa' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 32, chords: 24 },
        leadOptions: [114, 113, 115, 108, 109, 110, 73, 74, 21, 22],
        bassOptions: [32, 33, 34, 35, 36, 43, 114, 113],
        chordsOptions: [24, 25, 114, 113, 16, 17, 18, 19, 20, 21]
    },
    {
        name: 'Makuta',
        scale: 'pentatonic',
        root: 'F',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'makuta' }
        },
        wave: 'triangle',
        instruments: { lead: 114, bass: 32, chords: 24 },
        leadOptions: [114, 113, 115, 108, 109, 110, 73, 74, 21, 22],
        bassOptions: [32, 33, 34, 35, 36, 43, 114, 113],
        chordsOptions: [24, 25, 114, 113, 16, 17, 18, 19, 20, 21]
    },
    {
        name: 'Villancico',
        scale: 'major',
        root: 'G',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'villancico' }
        },
        wave: 'sine',
        instruments: { lead: 73, bass: 32, chords: 24 },
        leadOptions: [73, 74, 21, 22, 40, 41, 48, 49, 52, 53],
        bassOptions: [32, 33, 34, 35, 36, 43, 73, 74],
        chordsOptions: [24, 25, 73, 74, 16, 17, 18, 19, 20, 40]
    },
    {
        name: 'Punto Cubano',
        scale: 'major',
        root: 'C',
        bpm: 90,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'punto' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 24 },
        leadOptions: [24, 25, 21, 22, 73, 74, 40, 41, 65, 66],
        bassOptions: [32, 33, 34, 35, 36, 43, 24, 25],
        chordsOptions: [24, 25, 21, 22, 16, 17, 18, 19, 20, 40]
    },
    {
        name: 'Tonada',
        scale: 'minor',
        root: 'A',
        bpm: 85,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'tonada' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 24 },
        leadOptions: [24, 25, 21, 22, 73, 74, 40, 41, 65, 66],
        bassOptions: [32, 33, 34, 35, 36, 43, 24, 25],
        chordsOptions: [24, 25, 21, 22, 16, 17, 18, 19, 20, 40]
    },
	{
        name: 'Chaabi',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2, 3] },
            chords: { oct: [3, 4] },
            drums: { kit: 'darbuka' }
        },
        wave: 'sawtooth',
        instruments: { lead: 73, bass: 35, chords: 25 },
        leadOptions: [73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86],
        bassOptions: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48],
        chordsOptions: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]
    },
    {
        name: 'Rai',
        scale: 'minor',
        root: 'D',
        bpm: 130,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'darbuka' }
        },
        wave: 'square',
        instruments: { lead: 74, bass: 36, chords: 26 },
        leadOptions: [74, 73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61],
        bassOptions: [36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49],
        chordsOptions: [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },
    {
        name: 'Gnawa',
        scale: 'pentatonic',
        root: 'G',
        bpm: 105,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'taarija' }
        },
        wave: 'triangle',
        instruments: { lead: 73, bass: 35, chords: 25 },
        leadOptions: [73, 72, 71, 70, 69, 68, 67, 66, 65, 64, 63, 62, 61, 60],
        bassOptions: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48],
        chordsOptions: [25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12]
    },
    {
        name: 'Andalusisch',
        scale: 'maqam_bayati',
        root: 'D',
        bpm: 90,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2, 3] },
            chords: { oct: [3, 4] },
            drums: { kit: 'bendir' }
        },
        wave: 'sine',
        instruments: { lead: 49, bass: 33, chords: 25 },
        leadOptions: [49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62],
        bassOptions: [33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46],
        chordsOptions: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]
    },
    {
        name: 'Malhoun',
        scale: 'major',
        root: 'F',
        bpm: 100,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'daf' }
        },
        wave: 'sawtooth',
        instruments: { lead: 68, bass: 40, chords: 28 },
        leadOptions: [68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81],
        bassOptions: [40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53],
        chordsOptions: [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41]
    },
    {
        name: 'Kabyle',
        scale: 'dorian',
        root: 'A',
        bpm: 115,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [3] },
            chords: { oct: [4] },
            drums: { kit: 'bendir' }
        },
        wave: 'square',
        instruments: { lead: 72, bass: 38, chords: 26 },
        leadOptions: [72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85],
        bassOptions: [38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51],
        chordsOptions: [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },
    {
        name: 'Tuareg',
        scale: 'pentatonic',
        root: 'E',
        bpm: 95,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'darbuka' }
        },
        wave: 'sawtooth',
        instruments: { lead: 73, bass: 35, chords: 25 },
        leadOptions: [73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86],
        bassOptions: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48],
        chordsOptions: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]
    },
    {
        name: 'Desert Blues',
        scale: 'blues',
        root: 'G',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'darbuka' }
        },
        wave: 'sawtooth',
        instruments: { lead: 27, bass: 35, chords: 26 },
        leadOptions: [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40],
        bassOptions: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48],
        chordsOptions: [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },
    {
        name: 'Shaabi',
        scale: 'minor',
        root: 'C',
        bpm: 125,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'darbuka' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 38, chords: 29 },
        leadOptions: [81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94],
        bassOptions: [38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51],
        chordsOptions: [29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42]
    },
    {
        name: 'Mahraganat',
        scale: 'minor',
        root: 'F',
        bpm: 140,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'electronic' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 40, chords: 30 },
        leadOptions: [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100],
        bassOptions: [40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53],
        chordsOptions: [30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43]
    },
    {
        name: 'Tarab',
        scale: 'maqam_rast',
        root: 'C',
        bpm: 80,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'riqq' }
        },
        wave: 'sine',
        instruments: { lead: 50, bass: 34, chords: 26 },
        leadOptions: [50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63],
        bassOptions: [34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47],
        chordsOptions: [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },
    {
        name: 'Dabke',
        scale: 'major',
        root: 'G',
        bpm: 120,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'darbuka' }
        },
        wave: 'sawtooth',
        instruments: { lead: 65, bass: 37, chords: 28 },
        leadOptions: [65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78],
        bassOptions: [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50],
        chordsOptions: [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41]
    },
    {
        name: 'Khaliji',
        scale: 'major',
        root: 'D',
        bpm: 110,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [3] },
            chords: { oct: [4] },
            drums: { kit: 'tabla' }
        },
        wave: 'sine',
        instruments: { lead: 76, bass: 39, chords: 27 },
        leadOptions: [76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52],
        chordsOptions: [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40]
    },
    {
        name: 'Mugham',
        scale: 'maqam_shur',
        root: 'E',
        bpm: 70,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'daf' }
        },
        wave: 'sine',
        instruments: { lead: 52, bass: 36, chords: 24 },
        leadOptions: [52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65],
        bassOptions: [36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49],
        chordsOptions: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37]
    },
    {
        name: 'Persian Pop',
        scale: 'minor',
        root: 'B',
        bpm: 128,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'rockkit' }
        },
        wave: 'sawtooth',
        instruments: { lead: 73, bass: 36, chords: 25 },
        leadOptions: [73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86],
        bassOptions: [36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49],
        chordsOptions: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]
    },
    {
        name: 'Arabesk',
        scale: 'minor',
        root: 'A',
        bpm: 100,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'darbuka' }
        },
        wave: 'square',
        instruments: { lead: 70, bass: 38, chords: 26 },
        leadOptions: [70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83],
        bassOptions: [38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51],
        chordsOptions: [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },
    {
        name: 'Fasi',
        scale: 'maqam_saba',
        root: 'F',
        bpm: 85,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2, 3] },
            chords: { oct: [3, 4] },
            drums: { kit: 'bendir' }
        },
        wave: 'sine',
        instruments: { lead: 55, bass: 32, chords: 24 },
        leadOptions: [55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68],
        bassOptions: [32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45],
        chordsOptions: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37]
    },
    {
        name: 'Hawzi',
        scale: 'major',
        root: 'C',
        bpm: 95,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [3] },
            chords: { oct: [4] },
            drums: { kit: 'daf' }
        },
        wave: 'sawtooth',
        instruments: { lead: 67, bass: 35, chords: 25 },
        leadOptions: [67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80],
        bassOptions: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48],
        chordsOptions: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]
    },
    {
        name: 'Mezwed',
        scale: 'major',
        root: 'G',
        bpm: 135,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'darbuka' }
        },
        wave: 'square',
        instruments: { lead: 71, bass: 37, chords: 26 },
        leadOptions: [71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84],
        bassOptions: [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50],
        chordsOptions: [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },
    {
        name: 'Musique Orientale',
        scale: 'maqam_hijaz',
        root: 'D',
        bpm: 90,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'riqq' }
        },
        wave: 'sine',
        instruments: { lead: 53, bass: 34, chords: 25 },
        leadOptions: [53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66],
        bassOptions: [34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47],
        chordsOptions: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]
    },
    {
        name: 'Saharan Rock',
        scale: 'minor',
        root: 'E',
        bpm: 110,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'rockkit' }
        },
        wave: 'sawtooth',
        instruments: { lead: 29, bass: 36, chords: 27 },
        leadOptions: [29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42],
        bassOptions: [36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49],
        chordsOptions: [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40]
    },
    {
        name: 'Moorish Rock',
        scale: 'phrygian',
        root: 'A',
        bpm: 115,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'rockkit' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 37, chords: 26 },
        leadOptions: [30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43],
        bassOptions: [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50],
        chordsOptions: [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },
    {
        name: 'Izran',
        scale: 'pentatonic',
        root: 'G',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [3] },
            chords: { oct: [4] },
            drums: { kit: 'bendir' }
        },
        wave: 'sine',
        instruments: { lead: 72, bass: 35, chords: 24 },
        leadOptions: [72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85],
        bassOptions: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48],
        chordsOptions: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37]
    },
    {
        name: 'Amazigh Rock',
        scale: 'mixolydian',
        root: 'D',
        bpm: 120,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'rockkit' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 36, chords: 27 },
        leadOptions: [30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43],
        bassOptions: [36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49],
        chordsOptions: [27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40]
    },
    {
        name: 'Ahidous',
        scale: 'dorian',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'bendir' }
        },
        wave: 'square',
        instruments: { lead: 74, bass: 38, chords: 26 },
        leadOptions: [74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87],
        bassOptions: [38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51],
        chordsOptions: [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39]
    },
    {
        name: 'Ahwash',
        scale: 'pentatonic',
        root: 'A',
        bpm: 125,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'bendir' }
        },
        wave: 'triangle',
        instruments: { lead: 73, bass: 35, chords: 25 },
        leadOptions: [73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86],
        bassOptions: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48],
        chordsOptions: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]
    },
    {
        name: 'Rwayes',
        scale: 'phrygian',
        root: 'E',
        bpm: 95,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'taarija' }
        },
        wave: 'sine',
        instruments: { lead: 70, bass: 34, chords: 24 },
        leadOptions: [70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83],
        bassOptions: [34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47],
        chordsOptions: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37]
    },
    {
        name: 'Tagnawit',
        scale: 'pentatonic',
        root: 'G',
        bpm: 100,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'taarija' }
        },
        wave: 'triangle',
        instruments: { lead: 73, bass: 35, chords: 25 },
        leadOptions: [73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86],
        bassOptions: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48],
        chordsOptions: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]
    },
    {
        name: 'Taqtoqa',
        scale: 'major',
        root: 'F',
        bpm: 140,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [3] },
            chords: { oct: [4] },
            drums: { kit: 'darbuka' }
        },
        wave: 'square',
        instruments: { lead: 76, bass: 39, chords: 28 },
        leadOptions: [76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89],
        bassOptions: [39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52],
        chordsOptions: [28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41]
    },
    {
        name: 'Tindé',
        scale: 'pentatonic',
        root: 'D',
        bpm: 85,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'daf' }
        },
        wave: 'triangle',
        instruments: { lead: 71, bass: 35, chords: 24 },
        leadOptions: [71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84],
        bassOptions: [35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48],
        chordsOptions: [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37]
    },
	
	    {
        name: 'Classical',
        scale: 'major',
        root: 'C',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'orchestral' }
        },
        wave: 'sine',
        instruments: { lead: 40, bass: 43, chords: 48 },
        leadOptions: [40, 41, 42, 44, 45, 46, 48, 49, 50, 51, 60, 68, 70, 71, 73],
        bassOptions: [43, 42, 32, 33, 35, 41, 45, 58, 70],
        chordsOptions: [48, 49, 50, 51, 0, 1, 6, 7, 14, 15, 19, 20, 21]
    },
    {
        name: 'Jazz',
        scale: 'dorian',
        root: 'G',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 65, bass: 32, chords: 26 },
        leadOptions: [65, 66, 56, 4, 11, 12, 13, 64, 67, 71, 73, 74, 75, 76, 77],
        bassOptions: [32, 35, 43, 33, 34, 36, 37, 38, 39, 40, 41, 42, 44, 45],
        chordsOptions: [26, 4, 16, 5, 0, 1, 2, 6, 7, 17, 18, 19, 20, 21, 22]
    },
    {
        name: 'Blues',
        scale: 'pentatonic',
        root: 'E',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'blues' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 33, chords: 26 },
        leadOptions: [30, 29, 27, 26, 25, 28, 31, 22, 18, 19, 56, 57, 65, 66],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [26, 25, 27, 18, 17, 0, 1, 4, 19, 20]
    },
    {
        name: 'Rock',
        scale: 'minor',
        root: 'E',
        bpm: 124,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 29, 31, 27, 28, 26, 25, 80, 81, 18, 19, 20],
        bassOptions: [34, 33, 35, 36, 37, 38, 39],
        chordsOptions: [30, 29, 31, 18, 19, 17, 16, 0, 1]
    },
    {
        name: 'Metal',
        scale: 'phrygian',
        root: 'E',
        bpm: 160,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [3] },
            drums: { kit: 'metal' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 39, chords: 30 },
        leadOptions: [30, 31, 29, 81, 82, 85, 87, 18, 19],
        bassOptions: [39, 38, 34, 33, 35, 36, 37],
        chordsOptions: [30, 29, 31, 18, 19]
    },
    {
        name: 'Pop',
        scale: 'major',
        root: 'C',
        bpm: 118,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'pop' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 33, chords: 88 },
        leadOptions: [81, 82, 80, 89, 90, 4, 5, 2, 73, 74, 56, 61, 62],
        bassOptions: [33, 34, 38, 39, 32, 35, 81],
        chordsOptions: [88, 89, 90, 91, 0, 1, 4, 5, 12, 13]
    },
    {
        name: 'R&B',
        scale: 'minor',
        root: 'Bb',
        bpm: 85,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 4, bass: 33, chords: 95 },
        leadOptions: [4, 5, 88, 89, 73, 74, 11, 12, 56, 57, 65, 66],
        bassOptions: [33, 34, 32, 35, 38, 39],
        chordsOptions: [95, 94, 5, 4, 0, 1, 17, 18, 88, 89]
    },
    {
        name: 'Soul',
        scale: 'major',
        root: 'G',
        bpm: 95,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'funk' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 33, chords: 4 },
        leadOptions: [56, 57, 65, 66, 61, 62, 58, 4, 5, 17, 18],
        bassOptions: [33, 32, 34, 35, 36, 37],
        chordsOptions: [4, 5, 17, 18, 0, 1, 19, 20, 26, 27]
    },
    {
        name: 'Funk',
        scale: 'dorian',
        root: 'D',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'funk' }
        },
        wave: 'triangle',
        instruments: { lead: 57, bass: 36, chords: 26 },
        leadOptions: [57, 56, 61, 62, 65, 66, 81, 80, 84, 11, 12],
        bassOptions: [36, 37, 34, 33, 32, 35, 38, 39],
        chordsOptions: [26, 27, 17, 18, 4, 5, 0, 1]
    },
    {
        name: 'Disco',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'disco' }
        },
        wave: 'sawtooth',
        instruments: { lead: 61, bass: 33, chords: 52 },
        leadOptions: [61, 62, 56, 57, 81, 80, 48, 49, 11, 12],
        bassOptions: [33, 32, 38, 39, 34, 35],
        chordsOptions: [52, 53, 54, 55, 48, 49, 0, 1, 4, 5]
    },
    {
        name: 'Reggae',
        scale: 'major',
        root: 'C',
        bpm: 74,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'reggae' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 33, chords: 26 },
        leadOptions: [56, 57, 65, 66, 61, 62, 11, 12, 13, 22],
        bassOptions: [33, 32, 34, 35, 38, 39],
        chordsOptions: [26, 27, 24, 25, 4, 5, 17, 18]
    },
    {
        name: 'Country',
        scale: 'major',
        root: 'G',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'country' }
        },
        wave: 'triangle',
        instruments: { lead: 105, bass: 32, chords: 25 },
        leadOptions: [105, 106, 107, 26, 27, 25, 24, 40, 41, 65, 66],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [25, 24, 26, 0, 1, 2, 3, 27, 28]
    },
    {
        name: 'Electronic',
        scale: 'minor',
        root: 'C',
        bpm: 128,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'electro' }
        },
        wave: 'square',
        instruments: { lead: 80, bass: 38, chords: 90 },
        leadOptions: [80, 81, 82, 83, 84, 85, 86, 87, 62, 63],
        bassOptions: [38, 39, 81, 87, 33, 34],
        chordsOptions: [90, 88, 89, 91, 92, 62, 63, 81]
    },
    {
        name: 'Folk',
        scale: 'major',
        root: 'D',
        bpm: 105,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'folk' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 25 },
        leadOptions: [24, 25, 105, 109, 110, 73, 74, 40, 41, 26],
        bassOptions: [32, 33, 43, 42],
        chordsOptions: [25, 24, 26, 0, 1, 105]
    },
    {
        name: 'Punk',
        scale: 'minor',
        root: 'A',
        bpm: 165,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'punk' }
        },
        wave: 'sawtooth',
        instruments: { lead: 29, bass: 34, chords: 29 },
        leadOptions: [29, 30, 31, 27, 28, 26],
        bassOptions: [34, 33, 35, 39],
        chordsOptions: [29, 30, 31, 27, 28]
    },
    {
        name: 'Indie',
        scale: 'major',
        root: 'E',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'indie' }
        },
        wave: 'sine',
        instruments: { lead: 27, bass: 34, chords: 26 },
        leadOptions: [27, 28, 26, 25, 24, 81, 80, 73],
        bassOptions: [34, 33, 32, 35],
        chordsOptions: [26, 27, 25, 0, 1, 4, 88]
    },
    {
        name: 'Alternative',
        scale: 'minor',
        root: 'G',
        bpm: 122,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 27 },
        leadOptions: [30, 29, 27, 28, 81, 80, 90],
        bassOptions: [34, 33, 35, 38, 39],
        chordsOptions: [27, 28, 30, 29, 26, 18, 19]
    },
    {
        name: 'Ambient',
        scale: 'lydian',
        root: 'C',
        bpm: 60,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 99, bass: 95, chords: 92 },
        leadOptions: [99, 100, 101, 102, 91, 95, 96, 97],
        bassOptions: [95, 94, 93, 33, 34],
        chordsOptions: [92, 91, 90, 89, 48, 49, 101]
    },
    {
        name: 'Techno',
        scale: 'chromatic',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 38, chords: 62 },
        leadOptions: [81, 80, 87, 86, 62, 63, 38, 39],
        bassOptions: [38, 39, 87, 86, 81],
        chordsOptions: [62, 63, 64, 80, 81, 87]
    },
    {
        name: 'House',
        scale: 'minor',
        root: 'F',
        bpm: 124,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 88 },
        leadOptions: [81, 80, 88, 89, 17, 18, 5, 2, 73],
        bassOptions: [38, 39, 33, 34, 81],
        chordsOptions: [88, 89, 90, 17, 18, 4, 5, 0]
    },
    {
        name: 'Dubstep',
        scale: 'phrygian',
        root: 'E',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 39, chords: 118 },
        leadOptions: [87, 81, 80, 62, 63, 30, 31],
        bassOptions: [39, 38, 87, 86, 118],
        chordsOptions: [118, 97, 62, 63, 81]
    },
    {
        name: 'Drum and Bass',
        scale: 'minor',
        root: 'F',
        bpm: 172,
        roles: {
            lead: { oct: [6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'amen' }
        },
        wave: 'sine',
        instruments: { lead: 62, bass: 87, chords: 50 },
        leadOptions: [62, 81, 80, 73, 5, 11, 30],
        bassOptions: [87, 39, 38, 33, 34],
        chordsOptions: [50, 51, 90, 89, 95]
    },
    {
        name: 'Trap',
        scale: 'minor',
        root: 'G',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'triangle',
        instruments: { lead: 81, bass: 87, chords: 88 },
        leadOptions: [81, 80, 87, 56, 11, 10, 22, 2],
        bassOptions: [87, 39, 38, 33, 34],
        chordsOptions: [88, 90, 81, 80, 4, 5]
    },
    {
        name: 'Lo-fi',
        scale: 'minor',
        root: 'G',
        bpm: 80,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'lofi' }
        },
        wave: 'sine',
        instruments: { lead: 4, bass: 33, chords: 89 },
        leadOptions: [4, 5, 89, 73, 74, 11, 12, 66, 65, 24],
        bassOptions: [33, 32, 39, 38, 34],
        chordsOptions: [89, 4, 5, 0, 1, 17, 18, 95]
    },
    {
        name: 'Synth-pop',
        scale: 'major',
        root: 'A',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'electro' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 82, 80, 62, 63, 51, 52, 90],
        bassOptions: [38, 39, 81, 82, 33, 34],
        chordsOptions: [90, 89, 88, 81, 80, 50, 51]
    },
    {
        name: 'Electropop',
        scale: 'major',
        root: 'C',
        bpm: 122,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'pop' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 82, 80, 89, 90, 62, 63, 73],
        bassOptions: [38, 39, 33, 34, 81, 82],
        chordsOptions: [90, 89, 88, 81, 80, 4, 5]
    },
    {
        name: 'New Wave',
        scale: 'minor',
        root: 'D',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: '80s' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 38, chords: 26 },
        leadOptions: [81, 80, 62, 63, 27, 28, 73, 74],
        bassOptions: [38, 39, 34, 33, 32],
        chordsOptions: [26, 27, 25, 90, 89, 88, 50]
    },
    {
        name: 'Post-punk',
        scale: 'minor',
        root: 'A',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'punk' }
        },
        wave: 'sawtooth',
        instruments: { lead: 29, bass: 34, chords: 27 },
        leadOptions: [29, 30, 27, 28, 81, 80, 90],
        bassOptions: [34, 33, 32, 35, 38, 39],
        chordsOptions: [27, 28, 29, 26, 30, 18, 19]
    },
    {
        name: 'Grunge',
        scale: 'minor',
        root: 'E',
        bpm: 95,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 29, 31, 27, 28, 26, 25],
        bassOptions: [34, 33, 35, 39],
        chordsOptions: [30, 29, 31, 18, 19, 17, 16]
    },
    {
        name: 'Emo',
        scale: 'minor',
        root: 'G#',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 29, bass: 34, chords: 27 },
        leadOptions: [29, 30, 27, 28, 26, 25, 80],
        bassOptions: [34, 33, 35, 39],
        chordsOptions: [27, 28, 29, 30, 26, 18, 19]
    },
    {
        name: 'Progressive Rock',
        scale: 'mixolydian',
        root: 'E',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'prog' }
        },
        wave: 'sawtooth',
        instruments: { lead: 19, bass: 35, chords: 30 },
        leadOptions: [19, 20, 30, 29, 81, 80, 56, 61, 62, 73, 74],
        bassOptions: [35, 34, 33, 32, 36, 37, 38, 39],
        chordsOptions: [30, 29, 18, 19, 17, 16, 0, 1, 4, 5]
    },

    {
        name: 'Psychedelic Rock',
        scale: 'mixolydian',
        root: 'A',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 29, bass: 34, chords: 91 },
        leadOptions: [29, 30, 31, 27, 102, 103, 91, 95, 96, 56, 18],
        bassOptions: [34, 33, 35, 36, 38, 39],
        chordsOptions: [91, 95, 90, 89, 18, 19, 0, 1, 26, 27]
    },
    {
        name: 'Hard Rock',
        scale: 'minor',
        root: 'E',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 29, 31, 27, 28, 81, 80],
        bassOptions: [34, 33, 35, 39, 38],
        chordsOptions: [30, 29, 31, 18, 19, 17, 16]
    },
    {
        name: 'Heavy Metal',
        scale: 'phrygian',
        root: 'E',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [3] },
            drums: { kit: 'metal' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 31, 29, 18, 19, 81, 82],
        bassOptions: [34, 39, 38, 33, 35],
        chordsOptions: [30, 29, 31, 18, 19]
    },
    {
        name: 'Death Metal',
        scale: 'locrian',
        root: 'D',
        bpm: 180,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1] },
            chords: { oct: [2, 3] },
            drums: { kit: 'metal' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 39, chords: 30 },
        leadOptions: [30, 31, 81, 87, 18, 19, 118],
        bassOptions: [39, 38, 34, 35],
        chordsOptions: [30, 31, 18, 19]
    },
    {
        name: 'Black Metal',
        scale: 'minor',
        root: 'E',
        bpm: 170,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'metal' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 39, chords: 30 },
        leadOptions: [30, 31, 18, 19, 52, 53, 48, 49],
        bassOptions: [39, 38, 34, 35],
        chordsOptions: [30, 31, 18, 19, 48, 49]
    },
    {
        name: 'Thrash Metal',
        scale: 'chromatic',
        root: 'E',
        bpm: 190,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3] },
            drums: { kit: 'metal' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 31, 29, 18, 19, 81, 80],
        bassOptions: [34, 33, 35, 39, 38],
        chordsOptions: [30, 29, 31]
    },
    {
        name: 'Power Metal',
        scale: 'major',
        root: 'D',
        bpm: 165,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'metal' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 48 },
        leadOptions: [30, 31, 56, 57, 60, 61, 81, 18, 19],
        bassOptions: [34, 33, 35, 38, 39],
        chordsOptions: [48, 49, 50, 51, 30, 31, 19, 20]
    },
    {
        name: 'Gothic Metal',
        scale: 'minor',
        root: 'B',
        bpm: 90,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 19 },
        leadOptions: [30, 31, 40, 41, 42, 48, 49, 52, 53, 19, 20],
        bassOptions: [34, 33, 35, 39, 38],
        chordsOptions: [19, 20, 48, 49, 52, 53, 30, 31]
    },
    {
        name: 'Industrial',
        scale: 'chromatic',
        root: 'C',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'industrial' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 38, chords: 118 },
        leadOptions: [87, 81, 80, 62, 30, 31, 102, 103, 118],
        bassOptions: [38, 39, 87, 86, 33, 34],
        chordsOptions: [118, 102, 103, 81, 80, 30, 31]
    },
    {
        name: 'Hardcore',
        scale: 'minor',
        root: 'A',
        bpm: 180,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'punk' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 31, 29, 28, 27, 81],
        bassOptions: [34, 33, 35, 39],
        chordsOptions: [30, 31, 29, 28, 27]
    },
    {
        name: 'Ska',
        scale: 'major',
        root: 'G',
        bpm: 135,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'ska' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 26 },
        leadOptions: [56, 57, 58, 61, 62, 65, 66, 67, 11, 12],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [26, 27, 25, 24, 4, 5, 0, 1, 17, 18]
    },
    {
        name: 'Reggaeton',
        scale: 'minor',
        root: 'F#',
        bpm: 95,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 87, chords: 24 },
        leadOptions: [81, 80, 82, 62, 63, 56, 11, 2, 73, 74],
        bassOptions: [87, 39, 38, 33, 34],
        chordsOptions: [24, 25, 4, 5, 88, 89, 90]
    },
    {
        name: 'Salsa',
        scale: 'mixolydian',
        root: 'C',
        bpm: 180,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 0 },
        leadOptions: [56, 57, 58, 61, 62, 65, 66, 0, 1, 11, 12],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [0, 1, 4, 5, 17, 18, 56, 57, 11, 12]
    },
    {
        name: 'Bachata',
        scale: 'major',
        root: 'A',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 33, chords: 24 },
        leadOptions: [24, 25, 26, 27, 105, 106, 0, 1, 4, 5],
        bassOptions: [33, 34, 32, 35, 38, 39],
        chordsOptions: [24, 25, 26, 27, 0, 1, 4, 5]
    },
    {
        name: 'Merengue',
        scale: 'major',
        root: 'C',
        bpm: 150,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 0 },
        leadOptions: [56, 57, 58, 61, 62, 21, 22, 0, 1, 11, 12],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [0, 1, 2, 4, 5, 21, 22, 56, 57]
    },
    {
        name: 'Cumbia',
        scale: 'minor',
        root: 'G',
        bpm: 95,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'latin' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 32, chords: 0 },
        leadOptions: [21, 22, 56, 57, 73, 74, 24, 25, 11, 12, 0, 1],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [0, 1, 2, 4, 5, 21, 22, 24, 25]
    },
    {
        name: 'Tango',
        scale: 'harmonicMinor',
        root: 'D',
        bpm: 120,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'tango' }
        },
        wave: 'sine',
        instruments: { lead: 21, bass: 32, chords: 40 },
        leadOptions: [21, 22, 40, 41, 0, 1, 73, 74, 110],
        bassOptions: [32, 33, 43, 42, 35],
        chordsOptions: [40, 41, 48, 49, 0, 1, 21, 22]
    },
    {
        name: 'Bossa Nova',
        scale: 'major',
        root: 'F',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'bossa' }
        },
        wave: 'sine',
        instruments: { lead: 66, bass: 32, chords: 24 },
        leadOptions: [66, 65, 73, 74, 56, 57, 11, 12, 0, 1, 4, 5, 24],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [24, 25, 4, 5, 0, 1, 17, 18, 88, 89]
    },
    {
        name: 'Samba',
        scale: 'major',
        root: 'G',
        bpm: 130,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'samba' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 24 },
        leadOptions: [56, 57, 58, 61, 62, 11, 12, 0, 1, 24, 25, 26],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [24, 25, 0, 1, 4, 5, 56, 57, 11, 12]
    },
    {
        name: 'AfrobeatInMeasure',
        scale: 'dorian',
        root: 'A',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'afro' }
        },
        wave: 'triangle',
        instruments: { lead: 56, bass: 33, chords: 26 },
        leadOptions: [56, 57, 58, 61, 62, 65, 66, 81, 80, 11, 12, 17, 18],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [26, 27, 24, 25, 17, 18, 4, 5, 0, 1]
    },
    {
        name: 'Highlife',
        scale: 'major',
        root: 'F',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'afro' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 26 },
        leadOptions: [56, 57, 61, 62, 11, 12, 26, 27, 24, 25, 0, 1],
        bassOptions: [32, 33, 34, 35, 36, 37],
        chordsOptions: [26, 27, 24, 25, 0, 1, 4, 5, 17, 18]
    },
    {
        name: 'K-pop',
        scale: 'major',
        root: 'C',
        bpm: 128,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'pop' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 38, chords: 88 },
        leadOptions: [81, 80, 82, 89, 90, 62, 63, 73, 74, 56, 61, 2],
        bassOptions: [38, 39, 33, 34, 87, 81, 82],
        chordsOptions: [88, 89, 90, 91, 0, 1, 4, 5, 81, 80, 50, 51]
    },
    {
        name: 'J-pop',
        scale: 'major',
        root: 'D',
        bpm: 135,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'pop' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 82, 80, 89, 90, 62, 63, 30, 31, 27, 28, 73],
        bassOptions: [38, 39, 33, 34, 35, 81, 82],
        chordsOptions: [90, 88, 89, 81, 80, 0, 1, 30, 31, 48, 49]
    },
    {
        name: 'C-pop',
        scale: 'major',
        root: 'C',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'pop' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 33, chords: 0 },
        leadOptions: [81, 80, 89, 90, 0, 1, 4, 5, 73, 74, 107],
        bassOptions: [33, 34, 32, 35, 38, 39],
        chordsOptions: [0, 1, 4, 5, 88, 89, 48, 49, 12, 13]
    },
    {
        name: 'Mandopop',
        scale: 'major',
        root: 'G',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 0, bass: 33, chords: 48 },
        leadOptions: [0, 1, 4, 5, 73, 74, 88, 89, 40, 41, 107],
        bassOptions: [33, 34, 32, 35, 38, 39, 43],
        chordsOptions: [48, 49, 0, 1, 4, 5, 88, 89, 52, 53]
    },
    {
        name: 'Cantopop',
        scale: 'major',
        root: 'Ab',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 0, bass: 33, chords: 48 },
        leadOptions: [0, 1, 4, 5, 73, 74, 11, 12, 88, 89, 107],
        bassOptions: [33, 34, 32, 35, 43, 42],
        chordsOptions: [48, 49, 0, 1, 4, 5, 52, 53, 88, 89]
    },
    {
        name: 'Britpop',
        scale: 'major',
        root: 'E',
        bpm: 122,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sine',
        instruments: { lead: 27, bass: 34, chords: 26 },
        leadOptions: [27, 28, 29, 30, 26, 25, 24, 0, 1, 18, 19, 73],
        bassOptions: [34, 33, 35, 32],
        chordsOptions: [26, 27, 25, 24, 0, 1, 4, 5, 17, 18]
    },
    {
        name: 'Europop',
        scale: 'major',
        root: 'C',
        bpm: 124,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'pop' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 80, 82, 89, 90, 62, 63, 51, 52, 11, 12],
        bassOptions: [38, 39, 33, 34, 81, 82],
        chordsOptions: [90, 89, 88, 81, 80, 50, 51, 0, 1, 4, 5]
    },
    {
        name: 'Schlager',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'disco' }
        },
        wave: 'sine',
        instruments: { lead: 21, bass: 32, chords: 0 },
        leadOptions: [21, 22, 56, 57, 11, 12, 0, 1, 4, 5, 61, 62],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [0, 1, 4, 5, 21, 22, 48, 49, 88, 89]
    },
    {
        name: 'Chanson',
        scale: 'minor',
        root: 'A',
        bpm: 110,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 21, bass: 32, chords: 0 },
        leadOptions: [21, 22, 24, 25, 40, 41, 73, 74, 0, 1, 66, 65],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [0, 1, 4, 5, 24, 25, 40, 41, 48, 49]
    },
    {
        name: 'Fado',
        scale: 'harmonicMinor',
        root: 'D',
        bpm: 80,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'folk' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 24 },
        leadOptions: [24, 25, 26, 27, 40, 41, 105],
        bassOptions: [32, 33, 43, 42, 35],
        chordsOptions: [24, 25, 26, 27, 0, 1, 4, 5]
    },
    {
        name: 'Bluegrass',
        scale: 'major',
        root: 'G',
        bpm: 145,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'folk' }
        },
        wave: 'triangle',
        instruments: { lead: 105, bass: 32, chords: 25 },
        leadOptions: [105, 106, 107, 40, 41, 24, 25, 26, 27],
        bassOptions: [32, 33, 43, 42],
        chordsOptions: [25, 24, 26, 27, 105, 106, 0, 1]
    },
    {
        name: 'Zydeco',
        scale: 'major',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'zydeco' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 32, chords: 25 },
        leadOptions: [21, 22, 23, 56, 57, 115, 24, 25],
        bassOptions: [32, 33, 34, 35, 38],
        chordsOptions: [25, 24, 21, 22, 0, 1, 4, 5]
    },
    {
        name: 'Cajun',
        scale: 'major',
        root: 'G',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'folk' }
        },
        wave: 'sine',
        instruments: { lead: 110, bass: 32, chords: 21 },
        leadOptions: [110, 40, 41, 21, 22, 24, 25],
        bassOptions: [32, 33, 43, 42],
        chordsOptions: [21, 22, 24, 25, 0, 1]
    },
    {
        name: 'Gospel',
        scale: 'major',
        root: 'Eb',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'funk' }
        },
        wave: 'sine',
        instruments: { lead: 19, bass: 33, chords: 0 },
        leadOptions: [19, 20, 52, 53, 54, 56, 57, 4, 5, 17, 18],
        bassOptions: [33, 34, 32, 35, 36, 37],
        chordsOptions: [0, 1, 4, 5, 19, 20, 17, 18, 52, 53]
    },
    {
        name: 'Spirituals',
        scale: 'major',
        root: 'F',
        bpm: 80,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 52, bass: 32, chords: 19 },
        leadOptions: [52, 53, 54, 19, 20, 0, 1],
        bassOptions: [32, 33, 34, 35],
        chordsOptions: [19, 20, 0, 1, 52, 53]
    },
    {
        name: 'Hymns',
        scale: 'major',
        root: 'C',
        bpm: 70,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 19, bass: 32, chords: 19 },
        leadOptions: [19, 20, 52, 53, 48, 49, 0, 1],
        bassOptions: [32, 33, 35, 43, 42],
        chordsOptions: [19, 20, 48, 49, 0, 1, 52, 53]
    },
    {
        name: 'New Age',
        scale: 'lydian',
        root: 'C',
        bpm: 65,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 99, bass: 95, chords: 91 },
        leadOptions: [99, 100, 46, 73, 74, 11, 12, 88, 89],
        bassOptions: [95, 94, 93, 33, 34, 32],
        chordsOptions: [91, 92, 95, 88, 89, 48, 49, 100]
    },
    {
        name: 'World',
        scale: 'mixolydian',
        root: 'G',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'world' }
        },
        wave: 'triangle',
        instruments: { lead: 104, bass: 32, chords: 104 },
        leadOptions: [104, 105, 110, 111, 73, 74, 21, 22, 108, 109],
        bassOptions: [32, 33, 35, 38, 39],
        chordsOptions: [104, 105, 111, 24, 25, 0, 1, 4, 5]
    },
    {
        name: 'Latin',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 0 },
        leadOptions: [56, 57, 61, 62, 24, 25, 0, 1, 11, 12],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [0, 1, 4, 5, 24, 25, 56, 57, 11, 12]
    },
    {
        name: 'Celtic',
        scale: 'dorian',
        root: 'D',
        bpm: 115,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'world' }
        },
        wave: 'triangle',
        instruments: { lead: 109, bass: 32, chords: 105 },
        leadOptions: [109, 110, 40, 41, 73, 74, 24, 25, 105, 106],
        bassOptions: [32, 33, 35, 43, 42],
        chordsOptions: [105, 106, 25, 24, 0, 1, 26, 27]
    },
    {
        name: 'Klezmer',
        scale: 'phrygianDominant',
        root: 'G',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'world' }
        },
        wave: 'sine',
        instruments: { lead: 71, bass: 32, chords: 21 },
        leadOptions: [71, 72, 56, 57, 58, 21, 22, 40, 41, 110],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [21, 22, 0, 1, 4, 5, 110]
    },
    {
        name: 'Gregorian',
        scale: 'aeolian',
        root: 'C',
        bpm: 50,
        roles: {
            lead: { oct: [4] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 52, bass: 52, chords: 52 },
        leadOptions: [52, 53, 54, 19, 20],
        bassOptions: [52, 53, 54, 19, 20],
        chordsOptions: [52, 53, 54, 19, 20]
    },
    {
        name: 'Opera',
        scale: 'minor',
        root: 'C',
        bpm: 90,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'orchestral' }
        },
        wave: 'sine',
        instruments: { lead: 40, bass: 43, chords: 48 },
        leadOptions: [40, 41, 42, 52, 53, 54, 68, 69, 70, 71, 73],
        bassOptions: [43, 42, 32, 33, 35, 58],
        chordsOptions: [48, 49, 50, 51, 0, 1, 6, 7, 14, 15]
    },
    {
        name: 'Orchestral',
        scale: 'major',
        root: 'D',
        bpm: 100,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'orchestral' }
        },
        wave: 'sine',
        instruments: { lead: 48, bass: 43, chords: 48 },
        leadOptions: [48, 49, 50, 51, 40, 41, 42, 56, 57, 60, 68, 70, 73],
        bassOptions: [43, 42, 58, 70, 32, 33, 35],
        chordsOptions: [48, 49, 50, 51, 0, 1, 6, 7, 19, 20]
    },
    {
        name: 'Film Score',
        scale: 'minor',
        root: 'E',
        bpm: 80,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sine',
        instruments: { lead: 48, bass: 43, chords: 95 },
        leadOptions: [48, 49, 40, 41, 60, 61, 95, 96, 99, 100],
        bassOptions: [43, 42, 58, 38, 39, 95],
        chordsOptions: [95, 96, 48, 49, 50, 51, 91, 92, 0, 1]
    },
    {
        name: 'Video Game',
        scale: 'minor',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'square',
        instruments: { lead: 80, bass: 38, chords: 81 },
        leadOptions: [80, 81, 82, 62, 63, 118, 51, 50],
        bassOptions: [38, 39, 81, 80, 87, 86, 33, 34],
        chordsOptions: [81, 80, 62, 63, 90, 89, 50, 51]
    },
    {
        name: 'Musical Theatre',
        scale: 'major',
        root: 'Bb',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 0, bass: 32, chords: 48 },
        leadOptions: [0, 1, 56, 57, 65, 66, 40, 41, 61, 62],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [48, 49, 0, 1, 4, 5, 6, 7, 21, 22]
    },
    {
        name: 'Broadway',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 48 },
        leadOptions: [56, 57, 58, 61, 62, 65, 66, 0, 1, 11, 12],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [48, 49, 0, 1, 4, 5, 56, 57, 6, 7]
    },
    {
        name: 'Easy Listening',
        scale: 'major',
        root: 'G',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 65, bass: 32, chords: 0 },
        leadOptions: [65, 66, 73, 74, 11, 12, 4, 5, 0, 1, 24, 25],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [0, 1, 4, 5, 48, 49, 17, 18, 88, 89]
    },
    {
        name: 'Lounge',
        scale: 'major',
        root: 'C',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 4, bass: 33, chords: 88 },
        leadOptions: [4, 5, 66, 65, 73, 74, 11, 12, 17, 18, 56],
        bassOptions: [33, 32, 34, 35, 38, 39],
        chordsOptions: [88, 89, 4, 5, 17, 18, 0, 1, 95, 96]
    },
    {
        name: 'Chill-out',
        scale: 'major',
        root: 'F',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 99, bass: 33, chords: 95 },
        leadOptions: [99, 100, 73, 74, 11, 12, 88, 89, 4, 5, 101],
        bassOptions: [33, 32, 38, 39, 34, 35, 95],
        chordsOptions: [95, 96, 88, 89, 4, 5, 0, 1, 91, 92]
    },
    {
        name: 'Downtempo',
        scale: 'minor',
        root: 'G',
        bpm: 85,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sine',
        instruments: { lead: 73, bass: 33, chords: 95 },
        leadOptions: [73, 74, 99, 100, 4, 5, 11, 12, 62, 63, 89, 90],
        bassOptions: [33, 32, 38, 39, 34, 35, 87, 95],
        chordsOptions: [95, 96, 91, 92, 88, 89, 4, 5, 0, 1]
    },
    {
        name: 'Trip Hop',
        scale: 'minor',
        root: 'C',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'lofi' }
        },
        wave: 'triangle',
        instruments: { lead: 73, bass: 39, chords: 90 },
        leadOptions: [73, 74, 11, 12, 62, 63, 81, 80, 56, 4, 5, 30, 31],
        bassOptions: [39, 38, 87, 86, 33, 34, 35],
        chordsOptions: [90, 89, 95, 96, 4, 5, 0, 1, 17, 18, 30, 31]
    },
    {
        name: 'BreakbeatInMeasure',
        scale: 'minor',
        root: 'F',
        bpm: 135,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'break' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 87 },
        leadOptions: [81, 80, 62, 63, 87, 86, 11, 12, 22, 2],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [87, 86, 81, 80, 62, 63, 90, 89]
    },
    {
        name: 'Big Beat',
        scale: 'minor',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 30 },
        leadOptions: [81, 80, 30, 31, 87, 86, 118, 62, 63, 11, 12],
        bassOptions: [39, 38, 87, 86, 33, 34, 30, 31],
        chordsOptions: [30, 31, 81, 80, 118, 87, 18, 19]
    },
    {
        name: 'Acid Jazz',
        scale: 'dorian',
        root: 'G',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'funk' }
        },
        wave: 'sine',
        instruments: { lead: 66, bass: 33, chords: 17 },
        leadOptions: [66, 65, 56, 57, 61, 62, 4, 5, 11, 12, 17, 18],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [17, 18, 4, 5, 0, 1, 88, 89, 26, 27]
    },
    {
        name: 'Nu Jazz',
        scale: 'dorian',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 66, bass: 38, chords: 88 },
        leadOptions: [66, 65, 73, 74, 81, 80, 11, 12, 4, 5, 62, 63],
        bassOptions: [38, 39, 33, 34, 32, 35, 81],
        chordsOptions: [88, 89, 90, 4, 5, 17, 18, 0, 1, 95, 96]
    },
    {
        name: 'Smooth Jazz',
        scale: 'major',
        root: 'F',
        bpm: 95,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 65, bass: 33, chords: 4 },
        leadOptions: [65, 66, 4, 5, 73, 74, 11, 12, 56, 57, 24, 25],
        bassOptions: [33, 32, 34, 35, 43, 42],
        chordsOptions: [4, 5, 0, 1, 17, 18, 88, 89, 95, 96]
    },
    {
        name: 'Bebop',
        scale: 'chromatic',
        root: 'C',
        bpm: 180,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 66, bass: 32, chords: 0 },
        leadOptions: [66, 65, 56, 57, 58, 61, 62, 67, 71, 72, 11, 12],
        bassOptions: [32, 33, 35, 43, 42],
        chordsOptions: [0, 1, 4, 5, 6, 7, 17, 18, 19, 20]
    },
    {
        name: 'Swing',
        scale: 'major',
        root: 'G',
        bpm: 160,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 0 },
        leadOptions: [56, 57, 58, 61, 62, 65, 66, 67, 11, 12, 0, 1],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [0, 1, 4, 5, 6, 7, 17, 18, 56, 57, 11, 12]
    },
    {
        name: 'Ragtime',
        scale: 'major',
        root: 'C',
        bpm: 170,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 0, bass: 0, chords: 0 },
        leadOptions: [0, 1, 2, 3, 4, 5],
        bassOptions: [0, 1, 2, 3],
        chordsOptions: [0, 1, 2, 3, 4, 5]
    },
    {
        name: 'Boogie-woogie',
        scale: 'major',
        root: 'G',
        bpm: 160,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 0, bass: 32, chords: 0 },
        leadOptions: [0, 1, 2, 3, 4, 5, 30, 31, 11, 12],
        bassOptions: [32, 33, 34, 35, 0, 1],
        chordsOptions: [0, 1, 4, 5, 17, 18, 30, 31]
    },
    {
        name: 'Dixieland',
        scale: 'major',
        root: 'C',
        bpm: 150,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 57, bass: 58, chords: 11 },
        leadOptions: [57, 56, 65, 66, 58, 59, 71, 72, 11, 12, 0, 1],
        bassOptions: [58, 59, 43, 42, 32, 33],
        chordsOptions: [11, 12, 13, 0, 1, 4, 5, 56, 57]
    },
    {
        name: 'Drone',
        scale: 'minor',
        root: 'C',
        bpm: 40,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [1] },
            chords: { oct: [2, 3] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 97, bass: 95, chords: 91 },
        leadOptions: [97, 98, 91, 95, 87, 86, 52, 53, 101, 102],
        bassOptions: [95, 94, 93, 39, 38, 87],
        chordsOptions: [91, 90, 89, 48, 49, 95, 96, 101]
    },
    {
        name: 'Glitch',
        scale: 'chromatic',
        root: 'C',
        bpm: 100,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'glitch' }
        },
        wave: 'square',
        instruments: { lead: 118, bass: 39, chords: 115 },
        leadOptions: [118, 115, 120, 121, 125, 81, 80, 87, 86],
        bassOptions: [39, 38, 118, 115, 87, 86],
        chordsOptions: [115, 118, 117, 81, 80, 120, 121]
    },
    {
        name: 'Vaporwave',
        scale: 'major',
        root: 'A',
        bpm: 75,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: '80s' }
        },
        wave: 'sine',
        instruments: { lead: 4, bass: 33, chords: 95 },
        leadOptions: [4, 5, 88, 89, 73, 74, 11, 12, 17, 18, 99, 100],
        bassOptions: [33, 34, 38, 39, 32, 35, 95],
        chordsOptions: [95, 96, 88, 89, 4, 5, 17, 18, 0, 1]
    },
    {
        name: 'Synthwave',
        scale: 'minor',
        root: 'E',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '80s' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 82, 80, 62, 63, 50, 51, 89, 90],
        bassOptions: [38, 39, 33, 34, 81, 82, 87],
        chordsOptions: [90, 88, 89, 81, 80, 50, 51, 62, 63]
    },
    {
        name: 'Darkwave',
        scale: 'phrygian',
        root: 'B',
        bpm: 105,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'electro' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 91 },
        leadOptions: [81, 80, 48, 49, 19, 20, 87, 86, 101, 102],
        bassOptions: [38, 39, 87, 86, 33, 34, 35],
        chordsOptions: [91, 95, 96, 48, 49, 19, 20, 81, 80]
    },
    {
        name: 'Chillwave',
        scale: 'major',
        root: 'C',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'lofi' }
        },
        wave: 'sine',
        instruments: { lead: 99, bass: 33, chords: 88 },
        leadOptions: [99, 100, 89, 90, 4, 5, 73, 74, 11, 12, 101],
        bassOptions: [33, 32, 38, 39, 34, 35, 95],
        chordsOptions: [88, 89, 95, 96, 4, 5, 0, 1, 91, 92]
    },
    {
        name: 'Outrun',
        scale: 'minor',
        root: 'D',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '80s' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 80, 82, 62, 63, 30, 31, 89, 90],
        bassOptions: [38, 39, 81, 87, 33, 34, 35],
        chordsOptions: [90, 89, 81, 80, 50, 51, 62, 63]
    },
    {
        name: 'EBM',
        scale: 'chromatic',
        root: 'C',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'industrial' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 38, chords: 62 },
        leadOptions: [87, 86, 81, 80, 62, 38, 39, 118, 30, 31],
        bassOptions: [38, 39, 87, 86, 33, 34, 118],
        chordsOptions: [62, 63, 87, 86, 81, 80, 30, 31]
    },
    {
        name: 'Future Bass',
        scale: 'major',
        root: 'G',
        bpm: 150,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 90 },
        leadOptions: [81, 80, 82, 89, 90, 62, 63, 73, 74, 56, 11],
        bassOptions: [87, 39, 38, 33, 34, 81],
        chordsOptions: [90, 89, 88, 81, 80, 62, 63, 4, 5]
    },
    {
        name: 'Grime',
        scale: 'phrygian',
        root: 'F',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'grime' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 38, chords: 118 },
        leadOptions: [87, 86, 81, 80, 62, 63, 11, 2, 73],
        bassOptions: [38, 39, 87, 86, 33, 34, 118],
        chordsOptions: [118, 87, 81, 80, 62, 63]
    },
    {
        name: 'Garage',
        scale: 'minor',
        root: 'A',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sine',
        instruments: { lead: 88, bass: 39, chords: 88 },
        leadOptions: [88, 89, 17, 18, 4, 5, 81, 80, 11, 2, 73],
        bassOptions: [39, 38, 33, 34, 87, 81],
        chordsOptions: [88, 89, 90, 17, 18, 4, 5, 0, 1]
    },
    {
        name: 'Dub',
        scale: 'minor',
        root: 'C',
        bpm: 70,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3] },
            drums: { kit: 'reggae' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 33, chords: 26 },
        leadOptions: [56, 57, 61, 62, 65, 66, 11, 12, 13, 22, 102],
        bassOptions: [33, 34, 32, 35, 38, 39],
        chordsOptions: [26, 27, 24, 25, 4, 5, 17, 18, 102, 103]
    },
    {
        name: 'Dancehall',
        scale: 'minor',
        root: 'G',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 39, chords: 24 },
        leadOptions: [81, 80, 62, 63, 56, 11, 12, 2, 73, 74],
        bassOptions: [39, 38, 87, 86, 33, 34, 35],
        chordsOptions: [24, 25, 88, 89, 4, 5, 17, 18]
    },
    {
        name: 'Soca',
        scale: 'major',
        root: 'C',
        bpm: 155,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'soca' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 32, chords: 114 },
        leadOptions: [114, 115, 56, 57, 61, 62, 11, 12, 0, 1],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [114, 115, 0, 1, 4, 5, 56, 57, 11, 12]
    },
    {
        name: 'Calypso',
        scale: 'major',
        root: 'G',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soca' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 32, chords: 24 },
        leadOptions: [114, 115, 56, 57, 61, 62, 11, 12, 0, 1, 24, 25],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [24, 25, 114, 115, 0, 1, 4, 5]
    },
    {
        name: 'Flamenco',
        scale: 'phrygianDominant',
        root: 'E',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'latin' }
        },
        wave: 'triangle',
        instruments: { lead: 24, bass: 32, chords: 24 },
        leadOptions: [24, 25, 26, 27, 40, 41, 0, 1],
        bassOptions: [32, 33, 35, 43, 42],
        chordsOptions: [24, 25, 26, 27, 0, 1, 4, 5]
    },
    {
        name: 'Folk Rock',
        scale: 'major',
        root: 'D',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sine',
        instruments: { lead: 25, bass: 34, chords: 24 },
        leadOptions: [25, 24, 26, 27, 28, 73, 74, 110, 0, 1],
        bassOptions: [34, 33, 32, 35],
        chordsOptions: [24, 25, 26, 0, 1, 4, 5, 17, 18]
    },
    {
        name: 'Country Rock',
        scale: 'major',
        root: 'G',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 26, bass: 34, chords: 25 },
        leadOptions: [26, 27, 28, 25, 24, 105, 106, 110, 40, 41],
        bassOptions: [34, 33, 32, 35, 43, 42],
        chordsOptions: [25, 24, 26, 27, 0, 1, 4, 5, 28, 29]
    },
    {
        name: 'Southern Rock',
        scale: 'mixolydian',
        root: 'E',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 29, 31, 28, 27, 26, 25, 18, 19],
        bassOptions: [34, 33, 32, 35, 36, 37],
        chordsOptions: [30, 29, 31, 18, 19, 17, 16, 0, 1]
    },
    {
        name: 'Jam Band',
        scale: 'mixolydian',
        root: 'A',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'funk' }
        },
        wave: 'sawtooth',
        instruments: { lead: 27, bass: 34, chords: 17 },
        leadOptions: [27, 28, 29, 30, 17, 18, 56, 57, 19, 20],
        bassOptions: [34, 33, 32, 35, 36, 37, 38, 39],
        chordsOptions: [17, 18, 19, 20, 26, 27, 0, 1, 4, 5]
    },
    {
        name: 'Psychedelic Trance',
        scale: 'phrygian',
        root: 'E',
        bpm: 145,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 87 },
        leadOptions: [81, 80, 87, 86, 62, 63, 11, 2, 102, 103],
        bassOptions: [39, 38, 87, 86, 81],
        chordsOptions: [87, 86, 81, 80, 62, 63, 102, 103]
    },
    {
        name: 'Goa Trance',
        scale: 'phrygian',
        root: 'F#',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 62 },
        leadOptions: [81, 80, 87, 86, 62, 63, 11, 2, 56],
        bassOptions: [39, 38, 87, 86, 81],
        chordsOptions: [62, 63, 81, 80, 87, 86]
    },
    {
        name: 'Eurodance',
        scale: 'minor',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 80, 82, 89, 90, 62, 63, 50, 51, 11, 12],
        bassOptions: [38, 39, 33, 34, 81, 82],
        chordsOptions: [90, 89, 88, 81, 80, 50, 51, 0, 1]
    },
    {
        name: 'Happy Hardcore',
        scale: 'major',
        root: 'G',
        bpm: 170,
        roles: {
            lead: { oct: [6] },
            bass: { oct: [2] },
            chords: { oct: [4, 5] },
            drums: { kit: '909' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 80, 82, 62, 63, 50, 51, 11, 12, 2],
        bassOptions: [38, 39, 33, 34, 81, 87],
        chordsOptions: [90, 89, 88, 81, 80, 50, 51, 0, 1, 4, 5]
    },
    {
        name: 'Hardstyle',
        scale: 'minor',
        root: 'F',
        bpm: 150,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 50, 51, 30, 31],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 30, 31]
    },
    {
        name: 'Jumpstyle',
        scale: 'minor',
        root: 'C',
        bpm: 145,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 30, 31, 11, 12],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63]
    },
    {
        name: 'Gabber',
        scale: 'chromatic',
        root: 'E',
        bpm: 180,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 118 },
        leadOptions: [81, 80, 87, 86, 30, 31, 118, 62, 63],
        bassOptions: [39, 38, 87, 86, 118, 33, 34],
        chordsOptions: [118, 81, 80, 87, 86, 30, 31]
    },
    {
        name: 'Hardcore Techno',
        scale: 'chromatic',
        root: 'C',
        bpm: 160,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 81 },
        leadOptions: [81, 80, 87, 86, 30, 31, 62, 63],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 30, 31]
    },
    {
        name: 'Breakcore',
        scale: 'chromatic',
        root: 'D',
        bpm: 190,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'break' }
        },
        wave: 'square',
        instruments: { lead: 118, bass: 39, chords: 81 },
        leadOptions: [118, 81, 80, 87, 86, 62, 63, 30, 31, 120],
        bassOptions: [39, 38, 118, 87, 86, 33, 34],
        chordsOptions: [81, 80, 118, 87, 86, 62, 63, 30, 31]
    },
    {
        name: 'IDM',
        scale: 'chromatic',
        root: 'C',
        bpm: 105,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'glitch' }
        },
        wave: 'sine',
        instruments: { lead: 99, bass: 38, chords: 95 },
        leadOptions: [99, 100, 118, 115, 81, 80, 62, 63, 73, 74, 11],
        bassOptions: [38, 39, 87, 86, 33, 34, 95],
        chordsOptions: [95, 96, 91, 92, 88, 89, 81, 80, 115]
    },
    {
        name: 'Ambient Techno',
        scale: 'minor',
        root: 'G',
        bpm: 120,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: '909' }
        },
        wave: 'sine',
        instruments: { lead: 99, bass: 38, chords: 91 },
        leadOptions: [99, 100, 81, 80, 95, 96, 73, 74, 11, 12],
        bassOptions: [38, 39, 95, 94, 33, 34, 87],
        chordsOptions: [91, 92, 95, 96, 88, 89, 48, 49, 81, 80]
    },
    {
        name: 'Minimal Techno',
        scale: 'chromatic',
        root: 'C',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 38, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 11, 2, 115],
        bassOptions: [38, 39, 87, 86, 33, 34],
        chordsOptions: [81, 80, 87, 86, 62, 63]
    },
    {
        name: 'Dub Techno',
        scale: 'minor',
        root: 'C',
        bpm: 124,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 95, bass: 38, chords: 88 },
        leadOptions: [95, 96, 81, 80, 73, 74, 102, 103, 11, 12],
        bassOptions: [38, 39, 33, 34, 87, 86, 95],
        chordsOptions: [88, 89, 95, 96, 81, 80, 17, 18, 4, 5]
    },
    {
        name: 'Deep House',
        scale: 'minor7',
        root: 'G',
        bpm: 122,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sine',
        instruments: { lead: 4, bass: 33, chords: 88 },
        leadOptions: [4, 5, 17, 18, 66, 65, 73, 74, 11, 12, 81],
        bassOptions: [33, 34, 38, 39, 32, 35, 87],
        chordsOptions: [88, 89, 4, 5, 17, 18, 0, 1, 95, 96]
    },
    {
        name: 'Tech House',
        scale: 'minor',
        root: 'C',
        bpm: 126,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 11, 2, 88, 89],
        bassOptions: [38, 39, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 88, 89]
    },
    {
        name: 'Progressive House',
        scale: 'minor',
        root: 'E',
        bpm: 128,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 82, 80, 89, 90, 62, 63, 50, 51, 11],
        bassOptions: [38, 39, 33, 34, 87, 81, 82],
        chordsOptions: [90, 89, 88, 81, 80, 50, 51, 62, 63]
    },
    {
        name: 'Electro House',
        scale: 'minor',
        root: 'A',
        bpm: 128,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 30, 31, 118],
        bassOptions: [39, 38, 87, 86, 33, 34, 81, 80],
        chordsOptions: [81, 80, 87, 86, 62, 63, 30, 31]
    },
    {
        name: 'Big Room House',
        scale: 'phrygian',
        root: 'F',
        bpm: 128,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 30, 31, 50, 51],
        bassOptions: [87, 86, 39, 38, 81, 33, 34],
        chordsOptions: [81, 80, 87, 86, 62, 63, 30, 31]
    },
    {
        name: 'Future House',
        scale: 'minor',
        root: 'G',
        bpm: 126,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 38, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 88, 89, 11, 2],
        bassOptions: [38, 39, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 88, 89, 62, 63]
    },
    {
        name: 'Tropical House',
        scale: 'major',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 33, chords: 4 },
        leadOptions: [114, 115, 73, 74, 11, 12, 66, 65, 4, 5, 0, 1],
        bassOptions: [33, 32, 34, 35, 38, 39, 43],
        chordsOptions: [4, 5, 0, 1, 88, 89, 17, 18, 95, 96]
    },
    {
        name: 'G-House',
        scale: 'phrygian',
        root: 'C',
        bpm: 124,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 38, chords: 87 },
        leadOptions: [87, 86, 81, 80, 62, 63, 11, 2, 118],
        bassOptions: [38, 39, 87, 86, 33, 34, 81],
        chordsOptions: [87, 86, 81, 80, 62, 63]
    },
    {
        name: 'Bass House',
        scale: 'minor',
        root: 'F',
        bpm: 126,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 118, 11, 2],
        bassOptions: [87, 86, 39, 38, 33, 34, 118, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 118]
    },
    {
        name: 'Funky House',
        scale: 'major',
        root: 'G',
        bpm: 126,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'disco' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 33, chords: 17 },
        leadOptions: [56, 57, 61, 62, 17, 18, 4, 5, 0, 1, 11, 12, 66],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [17, 18, 4, 5, 0, 1, 88, 89, 56, 57]
    },
    {
        name: 'Soulful House',
        scale: 'major7',
        root: 'C',
        bpm: 124,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sine',
        instruments: { lead: 17, bass: 33, chords: 88 },
        leadOptions: [17, 18, 4, 5, 0, 1, 66, 65, 73, 74, 52, 53],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [88, 89, 4, 5, 17, 18, 0, 1, 95, 96]
    },
    {
        name: 'French House',
        scale: 'major',
        root: 'F',
        bpm: 126,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'disco' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 33, chords: 17 },
        leadOptions: [81, 80, 17, 18, 4, 5, 56, 57, 61, 62, 0, 1],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39, 81],
        chordsOptions: [17, 18, 4, 5, 0, 1, 88, 89, 90, 81]
    },
    {
        name: 'Italo Disco',
        scale: 'major',
        root: 'A',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'disco' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 82, 80, 89, 90, 62, 63, 50, 51, 11],
        bassOptions: [38, 39, 33, 34, 81, 82],
        chordsOptions: [90, 88, 89, 81, 80, 50, 51, 0, 1]
    },
    {
        name: 'Hi-NRG',
        scale: 'major',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'disco' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 81 },
        leadOptions: [81, 80, 82, 89, 90, 62, 63, 50, 51, 2],
        bassOptions: [38, 39, 33, 34, 81, 82, 87],
        chordsOptions: [81, 80, 90, 89, 88, 50, 51, 0, 1]
    },
    {
        name: 'Nu-Disco',
        scale: 'major',
        root: 'G',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'disco' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 33, chords: 17 },
        leadOptions: [81, 80, 17, 18, 4, 5, 56, 57, 0, 1, 88, 89],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39, 81],
        chordsOptions: [17, 18, 4, 5, 0, 1, 88, 89, 95, 96, 81]
    },
    {
        name: 'Hard Trance',
        scale: 'minor',
        root: 'E',
        bpm: 145,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 50, 51, 30, 31],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 30, 31]
    },
    {
        name: 'Progressive Trance',
        scale: 'minor',
        root: 'A',
        bpm: 135,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 80, 82, 89, 90, 62, 63, 95, 96, 11],
        bassOptions: [38, 39, 33, 34, 87, 81, 95],
        chordsOptions: [90, 89, 88, 81, 80, 95, 96, 50, 51]
    },
    {
        name: 'Uplifting Trance',
        scale: 'major',
        root: 'C',
        bpm: 138,
        roles: {
            lead: { oct: [6] },
            bass: { oct: [2] },
            chords: { oct: [4, 5] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 48 },
        leadOptions: [81, 82, 80, 89, 90, 62, 63, 48, 49, 11],
        bassOptions: [38, 39, 33, 34, 81, 82, 87],
        chordsOptions: [48, 49, 50, 51, 90, 89, 88, 81, 80]
    },
    {
        name: 'Vocal Trance',
        scale: 'minor',
        root: 'G',
        bpm: 135,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 52, bass: 38, chords: 90 },
        leadOptions: [52, 53, 54, 81, 80, 89, 90, 62, 63, 11, 2],
        bassOptions: [38, 39, 33, 34, 87, 81, 82],
        chordsOptions: [90, 89, 88, 81, 80, 48, 49, 50, 51]
    },
    {
        name: 'Acid Techno',
        scale: 'phrygian',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 87, bass: 39, chords: 87 },
        leadOptions: [87, 86, 81, 80, 62, 63, 11, 2, 38, 39],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [87, 86, 81, 80, 62, 63]
    },
    {
        name: 'Industrial Techno',
        scale: 'chromatic',
        root: 'C',
        bpm: 135,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'industrial' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 38, chords: 118 },
        leadOptions: [87, 86, 81, 80, 62, 63, 118, 30, 31, 102],
        bassOptions: [38, 39, 87, 86, 118, 33, 34, 30],
        chordsOptions: [118, 87, 86, 81, 80, 30, 31, 102]
    },
    {
        name: 'Detroit Techno',
        scale: 'minor',
        root: 'C',
        bpm: 128,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 88 },
        leadOptions: [81, 80, 62, 63, 89, 90, 73, 74, 11, 12, 17],
        bassOptions: [38, 39, 33, 34, 87, 81, 82],
        chordsOptions: [88, 89, 90, 81, 80, 17, 18, 4, 5, 0, 1]
    },
    {
        name: 'Berlin Techno',
        scale: 'chromatic',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 38, chords: 81 },
        leadOptions: [87, 86, 81, 80, 62, 63, 11, 2, 115, 118],
        bassOptions: [38, 39, 87, 86, 33, 34, 115],
        chordsOptions: [81, 80, 87, 86, 62, 63, 115, 118]
    },
    {
        name: 'Hard Techno',
        scale: 'chromatic',
        root: 'C',
        bpm: 145,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 30, 31, 118, 11],
        bassOptions: [39, 38, 87, 86, 33, 34, 118, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 30, 31, 118]
    },
    {
        name: 'Dubstep',
        scale: 'phrygian',
        root: 'E',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 39, chords: 87 },
        leadOptions: [87, 86, 81, 80, 62, 63, 118, 11, 2, 73],
        bassOptions: [39, 38, 87, 86, 33, 34, 118, 81],
        chordsOptions: [87, 86, 81, 80, 62, 63, 118]
    },
    {
        name: 'Brostep',
        scale: 'chromatic',
        root: 'F',
        bpm: 145,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 118, 30, 31, 11],
        bassOptions: [87, 86, 39, 38, 33, 34, 118, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 118, 30, 31]
    },
    {
        name: 'Melodic Dubstep',
        scale: 'major',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 90 },
        leadOptions: [81, 80, 89, 90, 62, 63, 48, 49, 11, 2, 73],
        bassOptions: [87, 39, 38, 33, 34, 81, 82],
        chordsOptions: [90, 89, 88, 81, 80, 62, 63, 48, 49, 0, 1]
    },
    {
        name: 'Riddim',
        scale: 'chromatic',
        root: 'G',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 39, chords: 87 },
        leadOptions: [87, 86, 81, 80, 62, 63, 118, 11, 2],
        bassOptions: [39, 38, 87, 86, 33, 34, 118, 81],
        chordsOptions: [87, 86, 81, 80, 62, 63, 118]
    },
    {
        name: 'Trap',
        scale: 'minor',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 87, chords: 24 },
        leadOptions: [81, 80, 62, 63, 11, 12, 13, 2, 73, 74, 56],
        bassOptions: [87, 39, 38, 33, 34, 81],
        chordsOptions: [24, 25, 88, 89, 4, 5, 17, 18, 81, 80]
    },
    {
        name: 'Phonk',
        scale: 'minor',
        root: 'F#',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 87, chords: 95 },
        leadOptions: [81, 80, 11, 2, 118, 62, 63, 73, 74, 102],
        bassOptions: [87, 39, 38, 33, 34, 118, 81],
        chordsOptions: [95, 96, 88, 89, 4, 5, 17, 18, 0, 1]
    },
    {
        name: 'Moombahton',
        scale: 'minor',
        root: 'C',
        bpm: 108,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 39, chords: 24 },
        leadOptions: [81, 80, 62, 63, 56, 57, 11, 12, 2, 73, 74],
        bassOptions: [39, 38, 87, 86, 33, 34, 35],
        chordsOptions: [24, 25, 88, 89, 4, 5, 17, 18, 81, 80]
    },
    {
        name: 'Jungle',
        scale: 'minor',
        root: 'C',
        bpm: 160,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'break' }
        },
        wave: 'sine',
        instruments: { lead: 11, bass: 39, chords: 95 },
        leadOptions: [11, 12, 13, 81, 80, 56, 57, 102, 103, 2, 73],
        bassOptions: [39, 38, 87, 86, 33, 34, 35],
        chordsOptions: [95, 96, 88, 89, 4, 5, 17, 18, 102, 103]
    },
    {
        name: 'Drum and Bass',
        scale: 'minor',
        root: 'F',
        bpm: 174,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'break' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 87 },
        leadOptions: [81, 80, 87, 86, 62, 63, 11, 2, 50, 51],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [87, 86, 81, 80, 95, 96, 62, 63]
    },
    {
        name: 'Liquid Funk',
        scale: 'major',
        root: 'Bb',
        bpm: 172,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'break' }
        },
        wave: 'sine',
        instruments: { lead: 66, bass: 33, chords: 88 },
        leadOptions: [66, 65, 73, 74, 11, 12, 4, 5, 0, 1, 17, 18],
        bassOptions: [33, 32, 38, 39, 34, 35, 95],
        chordsOptions: [88, 89, 4, 5, 17, 18, 0, 1, 95, 96]
    },
    {
        name: 'Neurofunk',
        scale: 'chromatic',
        root: 'C',
        bpm: 175,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 87, bass: 38, chords: 118 },
        leadOptions: [87, 86, 81, 80, 62, 63, 118, 11, 2],
        bassOptions: [38, 39, 87, 86, 118, 33, 34, 81],
        chordsOptions: [118, 87, 86, 81, 80, 62, 63]
    },
    {
        name: 'Jump-up',
        scale: 'minor',
        root: 'G',
        bpm: 175,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 11, 2, 38, 39],
        bassOptions: [39, 38, 87, 86, 81, 33, 34],
        chordsOptions: [81, 80, 87, 86, 62, 63]
    },
    {
        name: 'Atmospheric DnB',
        scale: 'major',
        root: 'Eb',
        bpm: 170,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'break' }
        },
        wave: 'sine',
        instruments: { lead: 99, bass: 33, chords: 95 },
        leadOptions: [99, 100, 73, 74, 11, 12, 88, 89, 4, 5, 101],
        bassOptions: [33, 32, 38, 39, 34, 35, 95],
        chordsOptions: [95, 96, 88, 89, 91, 92, 4, 5, 0, 1]
    },
    {
        name: 'Step',
        scale: 'minor',
        root: 'C',
        bpm: 172,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 39, chords: 87 },
        leadOptions: [87, 86, 81, 80, 62, 63, 11, 2],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [87, 86, 81, 80, 62, 63]
    },
    {
        name: 'Darkstep',
        scale: 'phrygian',
        root: 'D',
        bpm: 175,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 39, chords: 118 },
        leadOptions: [81, 80, 87, 86, 118, 30, 31, 19, 20],
        bassOptions: [39, 38, 87, 86, 118, 33, 34],
        chordsOptions: [118, 81, 80, 87, 86, 30, 31]
    },
    {
        name: '2-step',
        scale: 'minor',
        root: 'A',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'garage' }
        },
        wave: 'sine',
        instruments: { lead: 88, bass: 39, chords: 88 },
        leadOptions: [88, 89, 17, 18, 4, 5, 73, 74, 11, 12, 81],
        bassOptions: [39, 38, 33, 34, 87, 81],
        chordsOptions: [88, 89, 17, 18, 4, 5, 0, 1, 95, 96]
    },
    {
        name: 'Speed Garage',
        scale: 'minor',
        root: 'G',
        bpm: 135,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'garage' }
        },
        wave: 'square',
        instruments: { lead: 11, bass: 39, chords: 81 },
        leadOptions: [11, 12, 13, 81, 80, 2, 73, 56, 57],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 88, 89, 4, 5]
    },
    {
        name: 'UK Funky',
        scale: 'major',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'afro' }
        },
        wave: 'sine',
        instruments: { lead: 114, bass: 33, chords: 17 },
        leadOptions: [114, 115, 56, 57, 11, 12, 17, 18, 4, 5, 0],
        bassOptions: [33, 34, 32, 35, 38, 39],
        chordsOptions: [17, 18, 4, 5, 0, 1, 114, 115, 88, 89]
    },
    {
        name: 'Future Garage',
        scale: 'minor',
        root: 'F',
        bpm: 130,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'lofi' }
        },
        wave: 'sine',
        instruments: { lead: 73, bass: 33, chords: 95 },
        leadOptions: [73, 74, 99, 100, 11, 12, 4, 5, 88, 89, 101],
        bassOptions: [33, 32, 38, 39, 34, 35, 95],
        chordsOptions: [95, 96, 88, 89, 4, 5, 0, 1, 91, 92]
    },
    {
        name: 'Grimestep',
        scale: 'phrygian',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'grime' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 38, chords: 118 },
        leadOptions: [87, 86, 81, 80, 62, 63, 11, 2],
        bassOptions: [38, 39, 87, 86, 118, 33, 34, 81],
        chordsOptions: [118, 87, 81, 80, 62, 63]
    },
    {
        name: 'Wonky',
        scale: 'chromatic',
        root: 'C',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 90 },
        leadOptions: [81, 80, 62, 63, 89, 90, 11, 2, 73, 74],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [90, 89, 88, 4, 5, 17, 18, 0, 1]
    },
    {
        name: 'Footwork',
        scale: 'chromatic',
        root: 'C',
        bpm: 160,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sine',
        instruments: { lead: 11, bass: 87, chords: 11 },
        leadOptions: [11, 12, 13, 81, 80, 62, 63, 115, 2],
        bassOptions: [87, 39, 38, 33, 34, 81],
        chordsOptions: [11, 12, 81, 80, 88, 89, 4, 5]
    },
    {
        name: 'Juke',
        scale: 'minor',
        root: 'G',
        bpm: 155,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 81 },
        leadOptions: [81, 80, 11, 12, 13, 62, 63, 2, 73],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 88, 89, 4, 5, 17, 18]
    },
    {
        name: 'Electroclash',
        scale: 'minor',
        root: 'A',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 30, 31, 11],
        bassOptions: [38, 39, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 30, 31]
    },
    {
        name: 'Synthpop',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '80s' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 80, 82, 89, 90, 62, 63, 50, 51, 11, 12],
        bassOptions: [38, 39, 33, 34, 81, 82, 87],
        chordsOptions: [90, 89, 88, 81, 80, 50, 51, 0, 1, 4, 5]
    },
    {
        name: 'New Romantic',
        scale: 'major',
        root: 'D',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: '80s' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 38, chords: 48 },
        leadOptions: [81, 80, 48, 49, 73, 74, 11, 12, 56, 57, 0, 1],
        bassOptions: [38, 39, 33, 34, 35, 81],
        chordsOptions: [48, 49, 50, 51, 0, 1, 4, 5, 88, 89, 90]
    },
    {
        name: 'Electro',
        scale: 'minor',
        root: 'C',
        bpm: 125,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 38, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 11, 2, 118, 120],
        bassOptions: [38, 39, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 118]
    },
    {
        name: 'Freestyle',
        scale: 'minor',
        root: 'A',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 80, 89, 90, 62, 63, 56, 57, 11, 12, 2],
        bassOptions: [38, 39, 33, 34, 81, 87],
        chordsOptions: [90, 89, 88, 81, 80, 4, 5, 0, 1]
    },
    {
        name: 'Eletro Funk',
        scale: 'minor',
        root: 'G',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 39, chords: 81 },
        leadOptions: [81, 80, 87, 86, 62, 63, 56, 57, 11, 12, 2],
        bassOptions: [39, 38, 87, 86, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 17, 18, 4, 5, 0, 1]
    },
    {
        name: 'Miami Bass',
        scale: 'minor',
        root: 'C',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 87, chords: 81 },
        leadOptions: [81, 80, 62, 63, 11, 2, 118, 87, 86],
        bassOptions: [87, 39, 38, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63]
    },
    {
        name: 'Post-punk',
        scale: 'minor',
        root: 'E',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 27, bass: 34, chords: 29 },
        leadOptions: [27, 28, 29, 30, 26, 25, 81, 80, 18, 19],
        bassOptions: [34, 33, 35, 38, 39, 32],
        chordsOptions: [29, 30, 31, 18, 19, 27, 26, 0, 1]
    },
    {
        name: 'Goth Rock',
        scale: 'minor',
        root: 'B',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'electro' }
        },
        wave: 'sawtooth',
        instruments: { lead: 27, bass: 34, chords: 19 },
        leadOptions: [27, 28, 29, 30, 19, 20, 48, 49, 81, 80, 52],
        bassOptions: [34, 33, 35, 38, 39, 32],
        chordsOptions: [19, 20, 48, 49, 18, 17, 30, 31, 0, 1]
    },
    {
        name: 'Shoegaze',
        scale: 'major',
        root: 'A',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 29, bass: 34, chords: 30 },
        leadOptions: [29, 30, 31, 27, 28, 91, 95, 102, 103, 19, 20],
        bassOptions: [34, 33, 35, 32, 38, 39],
        chordsOptions: [30, 29, 31, 91, 95, 102, 103, 48, 49, 0, 1]
    },
    {
        name: 'Dream Pop',
        scale: 'major',
        root: 'C',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 99, bass: 33, chords: 95 },
        leadOptions: [99, 100, 73, 74, 11, 12, 88, 89, 4, 5, 0, 1],
        bassOptions: [33, 32, 34, 35, 38, 39, 95],
        chordsOptions: [95, 96, 88, 89, 4, 5, 0, 1, 91, 92, 48, 49]
    },
    {
        name: 'No Wave',
        scale: 'chromatic',
        root: 'C',
        bpm: 135,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'punk' }
        },
        wave: 'square',
        instruments: { lead: 30, bass: 39, chords: 30 },
        leadOptions: [30, 31, 118, 87, 86, 120, 125, 2],
        bassOptions: [39, 38, 34, 35, 87, 86],
        chordsOptions: [30, 31, 118, 87, 86, 18, 19]
    },
    {
        name: 'Noise Rock',
        scale: 'chromatic',
        root: 'E',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 39, chords: 30 },
        leadOptions: [30, 31, 118, 81, 80, 87, 86, 18, 19],
        bassOptions: [39, 38, 34, 35, 87, 86, 118],
        chordsOptions: [30, 31, 118, 18, 19, 87, 86]
    },
    {
        name: 'Experimental Rock',
        scale: 'chromatic',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 91 },
        leadOptions: [30, 31, 29, 27, 81, 80, 118, 102, 103, 18, 19],
        bassOptions: [34, 33, 35, 38, 39, 87, 86],
        chordsOptions: [91, 95, 102, 103, 30, 31, 18, 19, 0, 1]
    },
    {
        name: 'Art Rock',
        scale: 'major',
        root: 'G',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sine',
        instruments: { lead: 0, bass: 34, chords: 48 },
        leadOptions: [0, 1, 4, 5, 56, 57, 65, 66, 73, 74, 11, 12, 19, 20],
        bassOptions: [34, 33, 32, 35, 43, 42],
        chordsOptions: [48, 49, 0, 1, 4, 5, 17, 18, 19, 20]
    },
    {
        name: 'Math Rock',
        scale: 'major',
        root: 'D',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 27, bass: 34, chords: 27 },
        leadOptions: [27, 28, 26, 25, 24, 0, 1, 4, 5, 17, 18],
        bassOptions: [34, 33, 32, 35, 36, 37],
        chordsOptions: [27, 26, 25, 24, 0, 1, 4, 5, 17, 18]
    },
	{
        name: 'Indie Rock',
        scale: 'major',
        root: 'G',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 27, bass: 34, chords: 26 },
        leadOptions: [27, 28, 29, 30, 0, 1, 11, 12, 17, 18],
        bassOptions: [34, 33, 35, 38, 39],
        chordsOptions: [26, 27, 25, 0, 1, 4, 5, 17, 18]
    },
    {
        name: 'Indie Pop',
        scale: 'major',
        root: 'C',
        bpm: 118,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 11, bass: 33, chords: 4 },
        leadOptions: [11, 12, 73, 74, 99, 100, 4, 5, 0, 1, 66],
        bassOptions: [33, 34, 32, 35, 38, 39, 95],
        chordsOptions: [4, 5, 0, 1, 17, 18, 88, 89, 95, 96]
    },
    {
        name: 'Britpop',
        scale: 'major',
        root: 'A',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 29, bass: 34, chords: 26 },
        leadOptions: [29, 30, 27, 28, 0, 1, 17, 18, 19, 20],
        bassOptions: [34, 33, 35, 32, 36, 37],
        chordsOptions: [26, 27, 25, 0, 1, 17, 18, 19, 20]
    },
    {
        name: 'Garage Rock',
        scale: 'mixolydian',
        root: 'E',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3] },
            drums: { kit: 'punk' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 29, 31, 18, 19, 27, 28],
        bassOptions: [34, 33, 35, 32],
        chordsOptions: [30, 31, 29, 18, 19, 17, 16]
    },
    {
        name: 'Lo-Fi Indie',
        scale: 'major',
        root: 'G',
        bpm: 95,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'lofi' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 4 },
        leadOptions: [24, 25, 99, 100, 73, 74, 11, 12, 4, 5],
        bassOptions: [32, 33, 38, 39, 34, 35, 95],
        chordsOptions: [4, 5, 17, 18, 0, 1, 95, 96, 24, 25]
    },
    {
        name: 'AfrobeatInMeasure',
        scale: 'mixolydian',
        root: 'C',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'afro' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 33, chords: 17 },
        leadOptions: [56, 57, 61, 62, 60, 114, 11, 12, 26, 27],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [17, 18, 4, 5, 0, 1, 26, 27, 114, 115]
    },
    {
        name: 'Highlife',
        scale: 'major',
        root: 'F',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'afro' }
        },
        wave: 'sine',
        instruments: { lead: 26, bass: 32, chords: 24 },
        leadOptions: [26, 27, 56, 57, 11, 12, 0, 1, 4, 5],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [24, 25, 0, 1, 4, 5, 17, 18, 56, 57]
    },
    {
        name: 'Kwaito',
        scale: 'minor',
        root: 'G',
        bpm: 110,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'square',
        instruments: { lead: 87, bass: 38, chords: 88 },
        leadOptions: [87, 86, 11, 12, 17, 18, 81, 80, 73, 74],
        bassOptions: [38, 39, 33, 34, 87, 86, 95],
        chordsOptions: [88, 89, 4, 5, 17, 18, 95, 96, 81, 80]
    },
    {
        name: 'Amapiano',
        scale: 'minor7',
        root: 'C',
        bpm: 113,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'afro' }
        },
        wave: 'sine',
        instruments: { lead: 4, bass: 38, chords: 88 },
        leadOptions: [4, 5, 11, 12, 17, 18, 81, 80, 73, 74, 56, 57],
        bassOptions: [38, 39, 33, 34, 87, 86, 95],
        chordsOptions: [88, 89, 4, 5, 17, 18, 0, 1, 95, 96]
    },
    {
        name: 'Bossa Nova',
        scale: 'major7',
        root: 'F',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 73, bass: 32, chords: 24 },
        leadOptions: [73, 74, 66, 65, 11, 12, 0, 1, 4, 5, 52, 53],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [24, 25, 0, 1, 4, 5, 17, 18, 88, 89]
    },
    {
        name: 'Samba',
        scale: 'major',
        root: 'G',
        bpm: 100,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 24 },
        leadOptions: [56, 57, 61, 62, 11, 12, 0, 1, 73, 74, 114],
        bassOptions: [32, 33, 34, 35, 38, 39, 43],
        chordsOptions: [24, 25, 0, 1, 4, 5, 114, 115, 17, 18]
    },
    {
        name: 'Cumbia',
        scale: 'minor',
        root: 'C',
        bpm: 95,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 21, bass: 32, chords: 24 },
        leadOptions: [21, 22, 56, 57, 11, 12, 73, 74, 114, 0, 1],
        bassOptions: [32, 33, 34, 35, 38, 39],
        chordsOptions: [24, 25, 0, 1, 4, 5, 17, 18, 21, 22]
    },
    {
        name: 'Reggaeton',
        scale: 'minor',
        root: 'G',
        bpm: 95,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 39, chords: 88 },
        leadOptions: [81, 80, 11, 12, 13, 62, 63, 2, 73, 74, 56],
        bassOptions: [39, 38, 87, 86, 33, 34, 35],
        chordsOptions: [88, 89, 4, 5, 17, 18, 24, 25, 0, 1]
    },
    {
        name: 'Merengue',
        scale: 'major',
        root: 'C',
        bpm: 160,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 32, chords: 0 },
        leadOptions: [56, 57, 61, 62, 11, 12, 0, 1, 114, 115, 65, 66],
        bassOptions: [32, 33, 34, 35, 38, 39, 43],
        chordsOptions: [0, 1, 4, 5, 17, 18, 24, 25, 56, 57]
    },
    {
        name: 'Bachata',
        scale: 'minor',
        root: 'B',
        bpm: 125,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 24, bass: 32, chords: 24 },
        leadOptions: [24, 25, 26, 27, 0, 1, 4, 5, 11, 12],
        bassOptions: [32, 33, 34, 35, 38, 39, 43],
        chordsOptions: [24, 25, 0, 1, 4, 5, 17, 18]
    },
    {
        name: 'Tango',
        scale: 'minor',
        root: 'D',
        bpm: 120,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'latin' }
        },
        wave: 'triangle',
        instruments: { lead: 21, bass: 32, chords: 0 },
        leadOptions: [21, 22, 23, 40, 41, 48, 49, 0, 1],
        bassOptions: [32, 33, 35, 43, 42, 38],
        chordsOptions: [0, 1, 4, 5, 17, 18, 21, 22, 48, 49]
    },
    {
        name: 'Mariachi',
        scale: 'major',
        root: 'G',
        bpm: 110,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'latin' }
        },
        wave: 'sine',
        instruments: { lead: 56, bass: 43, chords: 24 },
        leadOptions: [56, 57, 61, 62, 40, 41, 0, 1, 11, 12],
        bassOptions: [43, 42, 32, 33, 35],
        chordsOptions: [24, 25, 0, 1, 4, 5, 56, 57]
    },
    {
        name: 'K-pop',
        scale: 'major',
        root: 'C',
        bpm: 128,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 80, 89, 90, 62, 63, 50, 51, 11, 12, 2, 73],
        bassOptions: [38, 39, 33, 34, 87, 81, 82],
        chordsOptions: [90, 89, 88, 81, 80, 50, 51, 0, 1, 4, 5, 17, 18]
    },
    {
        name: 'J-pop',
        scale: 'major',
        root: 'A',
        bpm: 160,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 34, chords: 90 },
        leadOptions: [81, 80, 29, 30, 62, 63, 50, 51, 11, 12, 2],
        bassOptions: [34, 33, 35, 38, 39, 81, 82],
        chordsOptions: [90, 89, 88, 81, 80, 50, 51, 0, 1, 4, 5, 17, 18, 29, 30]
    },
    {
        name: 'City Pop',
        scale: 'major9',
        root: 'F',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'disco' }
        },
        wave: 'sine',
        instruments: { lead: 62, bass: 33, chords: 88 },
        leadOptions: [62, 63, 66, 65, 73, 74, 11, 12, 17, 18, 4, 5, 0, 1],
        bassOptions: [33, 34, 32, 35, 36, 37, 38, 39],
        chordsOptions: [88, 89, 4, 5, 17, 18, 0, 1, 95, 96, 62, 63]
    },
    {
        name: 'Enka',
        scale: 'minorPentatonic',
        root: 'E',
        bpm: 80,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 40, bass: 32, chords: 48 },
        leadOptions: [40, 41, 73, 74, 11, 12, 105, 106, 110, 0, 1],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [48, 49, 0, 1, 4, 5, 17, 18, 40, 41]
    },
    {
        name: 'Rai',
        scale: 'phrygian',
        root: 'G',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'afro' }
        },
        wave: 'sine',
        instruments: { lead: 21, bass: 38, chords: 88 },
        leadOptions: [21, 22, 56, 57, 11, 12, 81, 80, 2, 73, 74],
        bassOptions: [38, 39, 33, 34, 87, 86, 95],
        chordsOptions: [88, 89, 4, 5, 17, 18, 81, 80, 21, 22]
    },
    {
        name: 'Qawwali',
        scale: 'minor',
        root: 'D',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1] },
            chords: { oct: [3, 4] },
            drums: { kit: 'tabla' }
        },
        wave: 'sine',
        instruments: { lead: 52, bass: 95, chords: 20 },
        leadOptions: [52, 53, 54, 55, 11, 12, 73, 74, 21, 22, 102],
        bassOptions: [95, 94, 33, 34, 32, 35],
        chordsOptions: [20, 21, 22, 4, 5, 0, 1, 48, 49, 102, 103]
    },
    {
        name: 'Bhangra',
        scale: 'major',
        root: 'G',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'tabla' }
        },
        wave: 'sine',
        instruments: { lead: 104, bass: 39, chords: 81 },
        leadOptions: [104, 105, 106, 56, 57, 11, 12, 81, 80, 2, 73, 74],
        bassOptions: [39, 38, 87, 86, 33, 34, 35],
        chordsOptions: [81, 80, 88, 89, 4, 5, 17, 18, 0, 1]
    },
    {
        name: 'Carnatic',
        scale: 'major',
        root: 'C',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1] },
            chords: { oct: [4] },
            drums: { kit: 'tabla' }
        },
        wave: 'sine',
        instruments: { lead: 40, bass: 95, chords: 95 },
        leadOptions: [40, 41, 110, 111, 73, 74, 11, 12, 105, 52, 53],
        bassOptions: [95, 94, 33, 34, 32, 35],
        chordsOptions: [95, 96, 91, 92, 48, 49, 0, 1, 4, 5]
    },
    {
        name: 'Hindustani',
        scale: 'major',
        root: 'D',
        bpm: 80,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1] },
            chords: { oct: [4] },
            drums: { kit: 'tabla' }
        },
        wave: 'sine',
        instruments: { lead: 104, bass: 95, chords: 95 },
        leadOptions: [104, 105, 106, 11, 12, 73, 74, 40, 41, 52, 53],
        bassOptions: [95, 94, 33, 34, 32, 35],
        chordsOptions: [95, 96, 91, 92, 48, 49, 0, 1, 4, 5]
    },
    {
        name: 'Gamelan',
        scale: 'pentatonic',
        root: 'C',
        bpm: 100,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'perc' }
        },
        wave: 'sine',
        instruments: { lead: 112, bass: 112, chords: 112 },
        leadOptions: [112, 113, 114, 115, 10, 11, 12, 13, 14, 9, 8],
        bassOptions: [112, 113, 114, 115, 33, 34, 38, 39],
        chordsOptions: [112, 113, 114, 115, 10, 11, 12, 13, 14]
    },
    {
        name: 'Klezmer',
        scale: 'phrygianDominant',
        root: 'D',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'folk' }
        },
        wave: 'triangle',
        instruments: { lead: 71, bass: 32, chords: 20 },
        leadOptions: [71, 72, 68, 69, 56, 57, 11, 12, 40, 41, 0, 1],
        bassOptions: [32, 33, 34, 35, 43, 42, 38],
        chordsOptions: [20, 21, 22, 0, 1, 4, 5, 17, 18, 48, 49]
    },
    {
        name: 'Celtic',
        scale: 'mixolydian',
        root: 'D',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'folk' }
        },
        wave: 'sine',
        instruments: { lead: 73, bass: 33, chords: 24 },
        leadOptions: [73, 74, 109, 110, 111, 11, 12, 40, 41, 0, 1, 24, 25],
        bassOptions: [33, 34, 32, 35, 43, 42],
        chordsOptions: [24, 25, 0, 1, 4, 5, 17, 18, 105, 106]
    },
    {
        name: 'Bluegrass',
        scale: 'major',
        root: 'G',
        bpm: 145,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'folk' }
        },
        wave: 'sine',
        instruments: { lead: 105, bass: 32, chords: 105 },
        leadOptions: [105, 106, 26, 27, 24, 25, 110, 111, 0, 1, 40, 41],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [105, 106, 24, 25, 26, 27, 0, 1, 4, 5]
    },
    {
        name: 'Americana',
        scale: 'major',
        root: 'C',
        bpm: 105,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sine',
        instruments: { lead: 25, bass: 34, chords: 24 },
        leadOptions: [25, 24, 26, 27, 105, 106, 110, 111, 73, 74, 0, 1],
        bassOptions: [34, 33, 32, 35, 43, 42],
        chordsOptions: [24, 25, 26, 27, 0, 1, 4, 5, 17, 18]
    },
    {
        name: 'Alternative Country',
        scale: 'major',
        root: 'D',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'rock' }
        },
        wave: 'sawtooth',
        instruments: { lead: 26, bass: 34, chords: 25 },
        leadOptions: [26, 27, 28, 25, 24, 30, 31, 105, 106, 110, 0, 1],
        bassOptions: [34, 33, 32, 35, 38, 39],
        chordsOptions: [25, 24, 26, 27, 0, 1, 4, 5, 17, 18, 28, 29]
    },
    {
        name: 'Harsh Noise',
        scale: 'chromatic',
        root: 'C',
        bpm: 160,
        roles: {
            lead: { oct: [4, 5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'industrial' }
        },
        wave: 'square',
        instruments: { lead: 127, bass: 127, chords: 127 },
        leadOptions: [127, 126, 125, 120, 118, 30, 31],
        bassOptions: [127, 87, 86, 118, 39, 38],
        chordsOptions: [127, 126, 118, 87, 86, 30, 31]
    },
    {
        name: 'Power Electronics',
        scale: 'chromatic',
        root: 'C',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1] },
            chords: { oct: [3] },
            drums: { kit: 'industrial' }
        },
        wave: 'sawtooth',
        instruments: { lead: 118, bass: 87, chords: 118 },
        leadOptions: [118, 120, 127, 87, 86, 30, 31, 52, 53],
        bassOptions: [87, 86, 118, 38, 39, 30],
        chordsOptions: [118, 127, 87, 86, 30, 31]
    },
    {
        name: 'Dark Ambient',
        scale: 'minor',
        root: 'A',
        bpm: 60,
        roles: {
            lead: { oct: [3, 4] },
            bass: { oct: [1] },
            chords: { oct: [2, 3] },
            drums: { kit: 'soft' }
        },
        wave: 'sine',
        instruments: { lead: 95, bass: 95, chords: 91 },
        leadOptions: [95, 96, 102, 103, 11, 12, 118, 120, 125],
        bassOptions: [95, 94, 33, 34, 38, 39, 87],
        chordsOptions: [91, 92, 95, 96, 102, 103, 48, 49, 19, 20]
    },
    {
        name: 'Drone',
        scale: 'chromatic',
        root: 'C',
        bpm: 40,
        roles: {
            lead: { oct: [3] },
            bass: { oct: [1] },
            chords: { oct: [2] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 95, bass: 95, chords: 95 },
        leadOptions: [95, 102, 125, 48, 19, 91],
        bassOptions: [95, 94, 38, 39, 87, 86],
        chordsOptions: [95, 102, 48, 19, 91, 103]
    },
    {
        name: 'Avant-Garde Jazz',
        scale: 'chromatic',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 66, bass: 32, chords: 0 },
        leadOptions: [66, 65, 56, 57, 11, 12, 60, 61, 62, 73, 74, 1],
        bassOptions: [32, 33, 34, 35, 43, 42],
        chordsOptions: [0, 1, 4, 5, 17, 18, 11, 12, 88, 89]
    },
    {
        name: 'Free Improvisation',
        scale: 'chromatic',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [4, 5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'jazz' }
        },
        wave: 'sine',
        instruments: { lead: 0, bass: 32, chords: 0 },
        leadOptions: [0, 1, 11, 12, 66, 65, 56, 57, 102, 103, 118],
        bassOptions: [32, 33, 35, 43, 34, 38, 39],
        chordsOptions: [0, 1, 4, 5, 17, 18, 11, 12, 48, 49]
    },
    {
        name: 'Vaporwave',
        scale: 'major7',
        root: 'Eb',
        bpm: 85,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sine',
        instruments: { lead: 11, bass: 33, chords: 88 },
        leadOptions: [11, 12, 62, 63, 66, 65, 73, 74, 99, 100, 4, 5, 0, 1],
        bassOptions: [33, 32, 38, 39, 34, 35, 95],
        chordsOptions: [88, 89, 95, 96, 4, 5, 17, 18, 0, 1, 62, 63]
    },
    {
        name: 'Hyperpop',
        scale: 'major',
        root: 'C',
        bpm: 155,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 81, bass: 87, chords: 81 },
        leadOptions: [81, 80, 62, 63, 11, 12, 50, 51, 2, 73, 74, 118],
        bassOptions: [87, 86, 39, 38, 33, 34, 81],
        chordsOptions: [81, 80, 87, 86, 62, 63, 88, 89, 90]
    },
    {
        name: 'Symphonic Metal',
        scale: 'minor',
        root: 'E',
        bpm: 135,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 48 },
        leadOptions: [30, 29, 31, 81, 80, 48, 49, 52, 53, 54, 11, 2],
        bassOptions: [34, 33, 35, 38, 39, 87, 86],
        chordsOptions: [48, 49, 50, 51, 52, 53, 30, 31, 19, 20]
    },
    {
        name: 'Gothic Metal',
        scale: 'minor',
        root: 'B',
        bpm: 120,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 19 },
        leadOptions: [30, 31, 29, 19, 20, 48, 49, 52, 53, 81, 80],
        bassOptions: [34, 33, 35, 38, 39, 87],
        chordsOptions: [19, 20, 48, 49, 52, 53, 30, 31, 18, 17]
    },
    {
        name: 'Doom Metal',
        scale: 'minor',
        root: 'C',
        bpm: 70,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 30 },
        leadOptions: [30, 31, 29, 118, 87, 86, 18, 19, 48, 49],
        bassOptions: [34, 33, 35, 38, 39, 87, 86],
        chordsOptions: [30, 31, 118, 18, 19, 48, 49]
    },
    {
        name: 'Industrial Metal',
        scale: 'chromatic',
        root: 'E',
        bpm: 110,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3] },
            drums: { kit: 'industrial' }
        },
        wave: 'square',
        instruments: { lead: 30, bass: 38, chords: 118 },
        leadOptions: [30, 31, 118, 87, 86, 81, 80, 11, 2, 38, 39],
        bassOptions: [38, 39, 87, 86, 118, 33, 34, 30, 31],
        chordsOptions: [118, 30, 31, 87, 86, 81, 80]
    },
    {
        name: 'Folk Metal',
        scale: 'minor',
        root: 'A',
        bpm: 125,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 73, bass: 34, chords: 30 },
        leadOptions: [73, 74, 21, 22, 109, 110, 11, 12, 30, 31, 0, 1],
        bassOptions: [34, 33, 35, 38, 39, 87],
        chordsOptions: [30, 31, 21, 22, 0, 1, 4, 5, 17, 18, 48, 49]
    },
    {
        name: 'Viking Metal',
        scale: 'minor',
        root: 'E',
        bpm: 115,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 30, bass: 34, chords: 52 },
        leadOptions: [30, 31, 52, 53, 54, 48, 49, 19, 20, 11, 2],
        bassOptions: [34, 33, 35, 38, 39, 87, 86],
        chordsOptions: [52, 53, 48, 49, 30, 31, 19, 20, 54, 55]
    },
    {
        name: 'Pirate Metal',
        scale: 'minor',
        root: 'G',
        bpm: 140,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'heavy' }
        },
        wave: 'sawtooth',
        instruments: { lead: 21, bass: 34, chords: 30 },
        leadOptions: [21, 22, 11, 12, 30, 31, 56, 57, 61, 62, 0, 1],
        bassOptions: [34, 33, 35, 38, 39, 87, 86],
        chordsOptions: [30, 31, 21, 22, 0, 1, 4, 5, 17, 18]
    },
    {
        name: 'Soundtrack',
        scale: 'major',
        root: 'C',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 48, bass: 43, chords: 48 },
        leadOptions: [48, 49, 40, 41, 73, 74, 11, 12, 0, 1, 68, 69],
        bassOptions: [43, 42, 32, 33, 35, 95],
        chordsOptions: [48, 49, 50, 51, 52, 53, 0, 1, 4, 5, 91, 92]
    },
    {
        name: 'Film Score',
        scale: 'minor',
        root: 'D',
        bpm: 80,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 40, bass: 43, chords: 48 },
        leadOptions: [40, 41, 48, 49, 52, 53, 11, 12, 73, 74, 0, 1],
        bassOptions: [43, 42, 32, 33, 35, 95, 94],
        chordsOptions: [48, 49, 50, 51, 52, 53, 0, 1, 4, 5, 95, 96]
    },
    {
        name: 'Video Game Music',
        scale: 'major',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 38, chords: 81 },
        leadOptions: [81, 80, 11, 12, 2, 73, 74, 50, 51, 89, 90],
        bassOptions: [38, 39, 33, 34, 87, 81, 82],
        chordsOptions: [81, 80, 88, 89, 90, 4, 5, 0, 1, 17, 18]
    },
    {
        name: 'Chiptune',
        scale: 'major',
        root: 'C',
        bpm: 140,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'none' }
        },
        wave: 'square',
        instruments: { lead: 81, bass: 38, chords: 81 },
        leadOptions: [81, 80, 82, 62, 63, 11, 2],
        bassOptions: [38, 39, 33, 34, 81, 80],
        chordsOptions: [81, 80, 62, 63]
    },
    {
        name: '8-bit',
        scale: 'major',
        root: 'G',
        bpm: 150,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'none' }
        },
        wave: 'square',
        instruments: { lead: 80, bass: 38, chords: 80 },
        leadOptions: [80, 81, 62, 63, 11, 2],
        bassOptions: [38, 39, 80, 81],
        chordsOptions: [80, 81, 62, 63]
    },
    {
        name: '16-bit',
        scale: 'minor',
        root: 'C',
        bpm: 130,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '909' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 38, chords: 90 },
        leadOptions: [81, 80, 89, 90, 11, 12, 56, 57, 62, 63, 73, 74],
        bassOptions: [38, 39, 33, 34, 81, 87],
        chordsOptions: [90, 89, 88, 81, 80, 4, 5, 0, 1, 17, 18]
    },
    {
        name: 'Musique Concrète',
        scale: 'chromatic',
        root: 'C',
        bpm: 100,
        roles: {
            lead: { oct: [4, 5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'perc' }
        },
        wave: 'sine',
        instruments: { lead: 120, bass: 125, chords: 102 },
        leadOptions: [120, 121, 122, 123, 124, 125, 126, 127, 118, 115, 102, 103],
        bassOptions: [125, 124, 120, 121, 33, 34, 38, 39, 87, 86, 95],
        chordsOptions: [102, 103, 114, 115, 118, 120, 121, 9, 10, 11, 12]
    },
    {
        name: 'Electronic Art Music',
        scale: 'chromatic',
        root: 'C',
        bpm: 90,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 81, bass: 33, chords: 95 },
        leadOptions: [81, 80, 95, 96, 102, 103, 11, 12, 118, 120, 125],
        bassOptions: [33, 34, 38, 39, 87, 86, 95],
        chordsOptions: [95, 96, 91, 92, 102, 103, 48, 49, 118]
    },
    {
        name: 'Spectral Music',
        scale: 'chromatic',
        root: 'C',
        bpm: 60,
        roles: {
            lead: { oct: [4, 5] },
            bass: { oct: [1] },
            chords: { oct: [3, 4] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 95, bass: 95, chords: 95 },
        leadOptions: [95, 96, 102, 103, 91, 92, 120, 125],
        bassOptions: [95, 94, 33, 34, 38, 39, 87],
        chordsOptions: [95, 96, 91, 92, 102, 103, 48, 49, 0, 1]
    },
    {
        name: 'Electroacoustic',
        scale: 'chromatic',
        root: 'C',
        bpm: 100,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 95, bass: 33, chords: 91 },
        leadOptions: [95, 96, 102, 103, 11, 12, 118, 120, 125, 0, 1],
        bassOptions: [33, 34, 38, 39, 87, 86, 95],
        chordsOptions: [91, 92, 95, 96, 102, 103, 48, 49, 118, 0, 1]
    },
    {
        name: 'Sound Art',
        scale: 'chromatic',
        root: 'C',
        bpm: 80,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [3, 4] },
            drums: { kit: 'none' }
        },
        wave: 'sine',
        instruments: { lead: 125, bass: 125, chords: 125 },
        leadOptions: [125, 124, 123, 120, 118, 102, 103, 95, 96, 11, 12],
        bassOptions: [125, 124, 120, 118, 38, 39, 87, 86, 95, 94],
        chordsOptions: [125, 124, 120, 118, 102, 103, 95, 96, 91, 92, 48, 49]
    },
    {
        name: 'Glitch',
        scale: 'chromatic',
        root: 'C',
        bpm: 110,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: 'glitch' }
        },
        wave: 'square',
        instruments: { lead: 120, bass: 38, chords: 118 },
        leadOptions: [120, 125, 118, 115, 87, 86, 81, 80, 11, 2],
        bassOptions: [38, 39, 87, 86, 118, 33, 34, 115, 81],
        chordsOptions: [118, 120, 87, 86, 81, 80, 62, 63]
    },
    {
        name: 'Circuit Bending',
        scale: 'chromatic',
        root: 'C',
        bpm: 120,
        roles: {
            lead: { oct: [5, 6] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'glitch' }
        },
        wave: 'square',
        instruments: { lead: 120, bass: 38, chords: 118 },
        leadOptions: [120, 121, 125, 127, 81, 80, 11, 2, 118],
        bassOptions: [38, 39, 87, 86, 118, 33, 34, 115, 81],
        chordsOptions: [118, 120, 127, 81, 80, 87, 86]
    },
    {
        name: 'Plunderphonics',
        scale: 'major',
        root: 'C',
        bpm: 115,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [2] },
            chords: { oct: [4] },
            drums: { kit: '808' }
        },
        wave: 'sine',
        instruments: { lead: 0, bass: 33, chords: 0 },
        leadOptions: [0, 1, 11, 12, 17, 18, 4, 5, 56, 57, 65, 66, 73, 74, 118, 120],
        bassOptions: [33, 34, 38, 39, 32, 35, 87, 86, 95],
        chordsOptions: [0, 1, 4, 5, 17, 18, 48, 49, 88, 89, 95, 96, 118]
    },
    {
        name: 'Post-Industrial',
        scale: 'chromatic',
        root: 'C',
        bpm: 105,
        roles: {
            lead: { oct: [5] },
            bass: { oct: [1, 2] },
            chords: { oct: [4] },
            drums: { kit: 'industrial' }
        },
        wave: 'square',
        instruments: { lead: 118, bass: 38, chords: 118 },
        leadOptions: [118, 87, 86, 30, 31, 11, 2, 120, 125, 19, 20],
        bassOptions: [38, 39, 87, 86, 118, 33, 34, 30, 31, 95],
        chordsOptions: [118, 87, 86, 30, 31, 19, 20, 102, 103]
    }
	
	
	
];



const GenreRolesScales = [  ["Techno", [41,43,45,46,48], [34,36,38,40,42], [53,55,58,60]],
  ["Glitch Capitalism", [38,40,43,45,47,49,51], [32,34,37,39], [50,52,55,57,59,61]],
  ["House", [40,42,44,45,47,49], [35,36,38,39], [55,57,59]],
  ["Trance", [42,44,46,48,50,52], [36,38,41,43], [54,56,58]],
  ["Drum&Bass", [39,41,43,45], [33,35,37,39,41,43], [52,54,57,59,61]],
  ["Chiptune", [36,38,40,42,44,46,48,50], [34,36,38], [49,51,53]],
  ["Ambient", [40,43,46,49,52], [38,40,42,44,46,48], [55,58,61,64]],
  ["Pop", [41,43,45,47,49,51], [39,41,43,45], [53,55,57,59,61]],
  ["Jazz", [42,44,46,48,50,52,54], [35,37,39,41,43], [56,58,60,62]],
  ["Blues", [38,40,42,44,46], [36,38,40,42,44,46], [52,54,57,59]],
  ["Funk", [43,45,47,49,51,53], [37,39,41,43], [54,56,58,60,62]],
  ["Bossa Nova", [39,41,44,46,48,50], [34,36,39,41], [51,53,55,58,60]],
  ["Bluegrass", [40,42,44,45,47], [38,40,42], [53,55,57,59]],
  ["Dubstep", [37,39,41,43,45,47,49], [31,33,35,37,39,41], [50,52,54,57]],
  ["Experimental", [35,37,39,41,43,45], [33,36,39,42], [48,51,54,57,60]],
  ["Chinese Classical", [38,40,42,45,47,49], [36,38,41], [52,54,56]],
  ["Chinese Traditional", [37,39,41,43,46,48], [35,37,40,42], [50,53,55,57]],
  ["Lo-Fi", [41,43,45,47,49], [37,39,41,43,45], [54,56,58,60,62]],
  ["Rock", [42,44,46,48,50,52], [36,38,40,42,44], [55,57,59,61]],
  ["Metal", [39,41,43,45,47], [35,37,39,41,43,45], [53,55,58,60]],
  ["Trap", [40,42,44,46,48,50,52], [34,36,38,40], [51,53,55,57,59]],
  ["Cinematic", [38,41,44,47,50,53], [37,40,43,46], [54,57,60,63,66]],
  ["Indian Raga", [39,41,44,46,48,50], [36,38,41], [52,54,57]],
  ["Middle Eastern", [37,40,42,44,46,49], [34,36,39,41], [50,53,55,58]],
  ["Afrobeats", [42,44,46,48,50], [38,40,42,44,46], [55,57,59,61,63]],
  ["Salsa", [41,43,45,47,49,51,53], [35,37,39,41], [53,55,57,60]],
  ["Reggae", [39,41,43,45,47], [36,38,40,42,44,46], [52,54,57,59,61]],
  ["Klezmer", [38,41,43,46,48,50], [34,36,39], [51,53,55,58]],
  ["Ribab (Rwira)", [37,40,42,44,47,49], [33,35,38], [50,52,55,57]],
  ["Rai", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Oriental", [38,41,43,45,47,50], [34,37,39,41], [51,53,56,58,60]],
  ["Samba", [41,43,45,47,49,51], [37,39,41,43], [54,56,58,60]],
  ["Tango", [42,44,46,48,50,52], [36,38,40,42], [55,57,59,61,63]],
  ["Flamenco", [40,42,44,45,47], [34,36,38], [52,54,57,59]],
  ["Highlife", [41,43,45,47,49], [37,39,41,43,45], [54,56,58,60]],
  ["Soukous", [42,44,46,48,50,52,54], [38,40,42], [55,57,59,61]],
  ["Bhangra", [40,42,44,46,48], [35,37,39,41,43], [53,55,57,59,61,63]],
  ["Balkan Brass", [39,41,43,45,47,49,51], [33,36,39], [52,54,57,60]],
  ["Zydeco", [41,43,46,48,50], [37,39,41,43], [54,56,58]],
  ["Cumbia", [40,42,44,45,47,49], [35,38,40], [53,55,57,59]],
  ["Mariachi", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Polka", [41,43,45,47,49,51], [37,39,41], [54,56,58,60,62]],
  ["Gospel", [39,42,45,48,51], [35,38,41,44], [52,55,58,61,64]],
  ["Ska", [42,44,46,48,50,52], [36,38,40,42,44], [55,57,59,61]],
  ["Soca", [41,43,45,47,49], [37,39,41,43,45,47], [54,56,58,60]],
  ["Juju", [40,42,44,45,47], [34,36,38,40], [53,55,57,59,61]],
  ["Mbalax", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Forró", [41,43,45,47,49,51], [37,39,41], [54,56,58]],
  ["Calypso", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Gagaku", [38,40,42,44,46,49], [34,36,38,40], [50,53,55,57]],
  ["Griot", [39,41,44,46,48,50], [35,38,40], [52,54,57,59]],
  ["Qawwali", [40,42,45,47,49,51], [36,38,41,43], [54,56,59,61]],
  ["Fado", [42,44,46,48,50], [38,40,42], [55,57,59]],
  ["Andean", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Gregorian Chant", [38,40,42,44,46], [34,36,38], [50,52,54]],
  ["Boogie Woogie", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61,63]],
  ["Motown", [41,43,45,47,49], [37,39,41], [54,56,58,60]],
  ["Disco", [42,44,46,48,50], [38,40,42,44,46], [55,57,59,61]],
  ["New Wave", [40,42,44,45,47,49], [34,36,38], [53,55,57,59]],
  ["Grunge", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Trip Hop", [41,43,45,47,49,51], [37,39,41,43], [54,56,58,60,62]],
  ["Dub", [39,41,43,45,47], [33,35,37,39], [52,54,56,58]],
  ["Psychedelic Rock", [42,44,46,48,50,52,54], [38,40,42,44], [55,57,59,61]],
  ["Baroque", [38,41,44,47,50], [34,37,40,43], [52,55,58,61]],
  ["Renaissance", [39,41,44,46,48], [35,37,39,41], [53,55,57,59]],
  ["Minimalism", [40,42,44,45,47], [36,38,40,42], [54,56,58]],
  ["Post Rock", [41,43,45,47,49,51], [37,39,41], [55,57,59,61]],
  ["Shoegaze", [40,42,44,46,48,50], [34,36,38,40], [53,55,57,59,61]],
  ["Noise", [36,38,40,42,44,46], [32,34,36,38,40], [49,51,53,55,57]],
  ["Drone", [38,40,42,44,46,48], [36,38,40,42], [50,52,54,56]],
  ["Waltz", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["March", [41,43,45,47,49,51], [37,39,41,43], [54,56,58,60]],
  ["Sea Shanty", [40,42,44,45,47], [36,38,40], [53,55,57]],
  ["Swing", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61]],
  ["Bebop", [43,45,47,49,51,53,55], [35,37,39,41,43], [56,58,60,62]],
  ["Cool Jazz", [41,43,45,47,49], [37,39,41,43,45], [54,56,58,60]],
  ["Hard Bop", [42,44,46,48,50,52], [36,38,40,42], [55,57,59,61,63]],
  ["Free Jazz", [37,39,42,45,48,51], [33,36,39,42], [50,53,56,59,62]],
  ["Modal Jazz", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Jazz Fusion", [40,42,44,46,48,50], [34,36,38,40], [53,55,57,59,61]],
  ["Smooth Jazz", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["J-Pop", [41,43,45,47,49,51], [37,39,41], [54,56,58,60,62]],
  ["K-Pop", [40,42,44,46,48,50], [34,36,38,40], [53,55,57,59]],
  ["City Pop", [42,44,46,48,50], [38,40,42,44,46], [55,57,59,61]],
  ["Vaporwave", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Future Bass", [40,42,44,46,48,50,52], [34,36,38], [53,55,57,59,61]],
  ["Witch House", [39,41,43,45,47,49], [33,35,37,39], [52,54,56,58]],
  ["Synthpop", [41,43,45,47,49,51], [37,39,41,43], [54,56,58,60]],
  ["Italo Disco", [42,44,46,48,50], [38,40,42], [55,57,59,61,63]],
  ["Eurodance", [41,43,45,47,49], [37,39,41,43,45], [54,56,58,60]],
  ["Hardstyle", [40,42,44,46,48], [34,36,38,40,42], [53,55,57,59,61,63]],
  ["Gabber", [37,39,41,43,45,47], [31,33,35,37,39], [50,52,54,56,58]],
  ["Psytrance", [41,43,45,47,49,51], [37,39,41], [54,56,58,60,62]],
  ["Goa Trance", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61]],
  ["Progressive House", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Deep House", [40,42,44,46,48,50], [36,38,40,42], [53,55,57,59,61]],
  ["UK Garage", [39,41,43,45,47,49], [33,35,37,39,41], [52,54,56,58,60]],
  ["Footwork", [41,43,45,47,49,51,53], [37,39,41], [54,56,58,60]],
  ["Jungle", [40,42,44,46,48,50], [34,36,38,40,42], [53,55,57,59]],
  ["Gypsy Jazz", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Mambo", [41,43,45,47,49,51], [35,37,39,41], [54,56,58,60,62]],
  ["Merengue", [40,42,44,46,48], [36,38,40,42,44], [53,55,57,59]],
  ["Bachata", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Son Cubano", [41,43,45,47,49], [37,39,41], [54,56,58,60]],
  ["Rumba", [40,42,44,46,48,50], [36,38,40], [53,55,57,59,61]],
  ["Guaracha", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61]],
  ["Cha Cha Cha", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Danzón", [39,41,44,46,48,50], [35,37,40,42], [52,55,57,59]],
  ["Bolero", [40,42,44,45,47], [36,38,40], [53,55,57]],
  ["Pachanga", [42,44,46,48,50], [38,40,42,44,46], [55,57,59,61,63]],
  ["Timba", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Charanga", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Mozambique", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Conga", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Bomba", [40,42,44,46,48], [36,38,40], [53,55,57,59,61]],
  ["Plena", [42,44,46,48,50], [38,40,42,44], [55,57,59]],
  ["Guajira", [41,43,45,47,49,51], [37,39,41], [54,56,58,60,62]],
  ["Son Montuno", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Guaguancó", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Colombia", [39,41,44,46,48], [35,37,39,41], [52,54,56,58]],
  ["Yambú", [40,42,44,45,47], [36,38,40,42], [53,55,57,59]],
  ["Guarapachangueo", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Batá", [40,42,44,46,48], [36,38,40], [53,55,57,59,61]],
  ["Iyesá", [42,44,46,48,50], [38,40,42,44], [55,57,59]],
  ["Makuta", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Villancico", [39,41,44,46,48,50], [35,37,40,42], [52,55,57,59]],
  ["Punto Cubano", [40,42,44,45,47], [36,38,40], [53,55,57]],
  ["Tonada", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Chaabi", [41,43,45,47,49], [36,38,40], [54,56,58,60]],
  ["Gnawa", [40,42,44,46,48,50], [37,39,41,43], [53,55,57,59]],
  ["Andalusisch", [38,40,42,44,46], [33,35,37,39], [50,52,54,56]],
  ["Malhoun", [41,43,45,47,49,51], [36,38,40], [54,56,58,60,62]],
  ["Kabyle", [40,42,44,46,48], [37,39,41,43], [53,55,57,59]],
  ["Tuareg", [42,44,46,48,50,52], [36,38,40], [55,57,59,61]],
  ["DesertBlues", [41,43,45,47,49], [37,39,41,43,45], [54,56,58,60]],
  ["Shaabi", [40,42,44,46,48], [36,38,40], [53,55,57,59,61]],
  ["Mahraganat", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61]],
  ["Tarab", [38,40,42,44,46], [33,35,37,39], [50,52,54,56]],
  ["Dabke", [41,43,45,47,49,51], [37,39,41], [54,56,58,60,62]],
  ["Khaliji", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Mugham", [38,40,42,44,46,48], [33,35,37], [50,52,54,56]],
  ["PersianPop", [41,43,45,47,49,51], [37,39,41,43], [54,56,58,60]],
  ["Arabesk", [40,42,44,46,48], [36,38,40], [53,55,57,59,61]],
  ["Fasi", [38,40,42,44,46], [33,35,37,39], [50,52,54,56]],
  ["Hawzi", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Mezwed", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["MusiqueOrientale", [38,40,42,44,46], [33,35,37,39], [50,52,54,56]],
  ["SaharanRock", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["MoorishRock", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Izran", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["AmazighRock", [42,44,46,48,50], [38,40,42], [55,57,59,61]],
  ["Ahidous", [41,43,45,47,49,51], [37,39,41,43], [54,56,58,60,62]],
  ["Ahwash", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Rwayes", [38,40,42,44,46], [33,35,37,39], [50,52,54,56]],
  ["Tagnawit", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Taqtoqa", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Tindé", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Classical", [41,43,45,47,49,51], [35,37,39,41], [54,56,58,60]],
  ["R&B", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Soul", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Country", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Electronic", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61]],
  ["Folk", [41,43,45,47,49], [37,39,41], [54,56,58,60]],
  ["Punk", [40,42,44,46,48,50], [34,36,38,40], [53,55,57,59,61]],
  ["Indie", [42,44,46,48,50], [38,40,42,44], [55,57,59]],
  ["Alternative", [41,43,45,47,49,51], [37,39,41], [54,56,58,60,62]],
  ["Synth-pop", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Electropop", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Post-punk", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Emo", [40,42,44,46,48], [36,38,40], [53,55,57,59,61]],
  ["Progressive Rock", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61]],
  ["Hard Rock", [41,43,45,47,49], [37,39,41], [54,56,58,60]],
  ["Heavy Metal", [40,42,44,46,48,50], [34,36,38,40], [53,55,57,59]],
  ["Death Metal", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Black Metal", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Thrash Metal", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Power Metal", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Gothic Metal", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Industrial", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Hardcore", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61]],
  ["Reggaeton", [41,43,45,47,49], [37,39,41], [54,56,58,60]],
  ["Opera", [40,42,44,46,48,50], [36,38,40], [53,55,57,59,61]],
  ["Choral", [42,44,46,48,50], [38,40,42,44], [55,57,59]],
  ["Romantic", [41,43,45,47,49,51], [37,39,41], [54,56,58,60,62]],
  ["Modern Classical", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Avant-garde", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["IDM", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Glitch", [40,42,44,46,48], [36,38,40], [53,55,57,59,61]],
  ["Breakcore", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61]],
  ["Hard Trance", [41,43,45,47,49], [37,39,41], [54,56,58,60]],
  ["Dream Trance", [40,42,44,46,48,50], [36,38,40], [53,55,57,59]],
  ["Progressive Trance", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Tech House", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Acid House", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Tropical House", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Future House", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["G-House", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Electro House", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Big Room", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Hard Techno", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Minimal Techno", [42,44,46,48,50], [38,40,42], [55,57,59]],
  ["Dub Techno", [41,43,45,47,49,51], [37,39,41,43], [54,56,58,60,62]],
  ["Acid Techno", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Detroit Techno", [42,44,46,48,50,52], [38,40,42,44], [55,57,59,61]],
  ["Liquid Funk", [41,43,45,47,49], [37,39,41], [54,56,58,60]],
  ["Neurofunk", [40,42,44,46,48,50], [34,36,38,40], [53,55,57,59]],
  ["Jump Up", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Ragga Jungle", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["2-Step", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Grime", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Synthwave", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Chillwave", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Darkwave", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["EBM", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Futurepop", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Aggrotech", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Downtempo", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Psybient", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Illbient", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Ambient House", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Ambient Techno", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Dark Ambient", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["New Age", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Space Music", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["World Music", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["AfrobeatInMeasure", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Ethno Jazz", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Latin Jazz", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Big Band", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Ragtime", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Boogie-woogie", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Dixieland", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Delta Blues", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Chicago Blues", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Texas Blues", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Jump Blues", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Electric Blues", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Blues Rock", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Southern Rock", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Rock and Roll", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Rockabilly", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Surf Rock", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Garage Rock", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Glam Rock", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Soft Rock", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Hard Rock (Alternative)", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Arena Rock", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Gothic Rock", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Dream Pop", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Jangle Pop", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Power Pop", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Britpop", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Madchester", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Post-rock", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Math Rock", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Krautrock", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Space Rock", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Stoner Rock", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Desert Rock", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Sludge Metal", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Doom Metal", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Symphonic Metal", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Folk Metal", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Viking Metal", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Pirate Metal", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Nu Metal", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Metalcore", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Deathcore", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Grindcore", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Pop Punk", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Skate Punk", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Hardcore Punk", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Post-hardcore", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Screamo", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Crust Punk", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Anarcho-punk", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Psychobilly", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Horrorpunk", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Oi!", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Street Punk", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Ska Punk", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Reggae Rock", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Dancehall", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Lovers Rock", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Roots Reggae", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Ska (Second Wave)", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Rocksteady", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Americana", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Alt-country", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Honky-tonk", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Western Swing", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Outlaw Country", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Contemporary Country", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Celtic Folk", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Chanson", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Flamenco (Modern)", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Enka", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["C-pop", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["V-pop", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Cantopop", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Mandopop", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Latin Pop", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Reggaeton (Modern)", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Salsa (Modern)", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Bachata (Modern)", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Ranchera", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Bossanova (Modern)", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Samba (Modern)", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["MPB", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Tropicália", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Zouk", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Kizomba", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Kuduro", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Mbaqanga", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Gnawa (second)", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Hindustani", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Carnatic", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Thai Pop", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Luk Thung", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Dangdut", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["V-pop (Contemporary)", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["P-pop", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Anison", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]],
  ["Video Game Music", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Soundtrack", [41,43,45,47,49], [37,39,41,43], [54,56,58,60]],
  ["Film Score", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Production Music", [42,44,46,48,50], [38,40,42,44], [55,57,59,61,63]],
  ["Trailer Music", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Holiday Music", [40,42,44,46,48], [36,38,40,42], [53,55,57,59]],
  ["Christian Music", [42,44,46,48,50,52], [38,40,42], [55,57,59,61]],
  ["Contemporary Christian", [41,43,45,47,49], [37,39,41,43], [54,56,58,60,62]],
  ["Children's Music", [40,42,44,46,48], [36,38,40], [53,55,57,59]],
  ["Comedy Music", [42,44,46,48,50], [38,40,42,44], [55,57,59,61]],
  ["Novelty Music", [41,43,45,47,49,51], [37,39,41], [54,56,58,60]],
  ["Plunderphonics", [40,42,44,46,48], [36,38,40,42], [53,55,57,59,61]]
];




const GENRE_ECA_RULES = {
            'Techno': [110, 51, 102, 90],
    'Glitch Capitalism': [87, 39, 97, 118],
            'House': [110, 102, 60, 85],
            'Trance': [110, 51, 150, 94],
            'Drum&Bass': [94, 51, 102, 110],
            'Chiptune': [90, 51, 60, 73],
            'Ambient': [90, 60, 150, 45],
            'Pop': [60, 90, 150, 85],
            'Jazz': [150, 90, 60, 78],
            'Blues': [60, 90, 150, 75],
            'Funk': [90, 102, 60, 95],
            'Bossa Nova': [90, 150, 60, 70],
            'Bluegrass': [90, 60, 150, 80],
            'Dubstep': [30, 51, 94, 102],
            'Experimental': [30, 94, 110, 73],
            'Chinese Classical': [85, 110, 95, 50],
            'Chinese Traditional': [80, 105, 90, 65],
            'Lo-Fi': [94, 60, 102, 70],
            'Rock': [110, 90, 150, 105],
            'Metal': [94, 51, 110, 115],
            'Trap': [94, 51, 102, 96],
            'Cinematic': [73, 126, 150, 85],
            'Indian Raga': [73, 126, 102, 75],
            'Middle Eastern': [73, 126, 102, 82],
            'Afrobeats': [73, 90, 60, 95],
            'Salsa': [90, 60, 150, 98],
            'Reggae': [102, 90, 60, 80],
            'Klezmer': [73, 150, 60, 78],
            'Ribab (Rwira)': [73, 150, 60, 85],
            'Rai': [73, 90, 60, 90],
            'Oriental': [73, 126, 102, 80],
			    'Samba': [90, 102, 60, 110],
    'Tango': [110, 90, 150, 85],
    'Flamenco': [110, 51, 102, 90],
    'Highlife': [90, 60, 150, 95],
    'Soukous': [90, 102, 60, 98],
    'Bhangra': [102, 90, 60, 110],
    'Balkan Brass': [110, 51, 102, 120],
    'Zydeco': [90, 150, 60, 85],
    'Cumbia': [90, 60, 150, 80],
    'Mariachi': [110, 90, 150, 95],
    'Polka': [110, 90, 150, 100],
    'Gospel': [73, 126, 150, 85],
    'Ska': [110, 90, 150, 105],
    'Soca': [90, 102, 60, 100],
    'Juju': [90, 60, 150, 88],
    'Mbalax': [90, 102, 60, 95],
    'Forró': [90, 150, 60, 92],
    'Calypso': [90, 60, 150, 85],
    'Gagaku': [73, 126, 102, 65],
	    'Griot': [73, 126, 102, 80],
    'Qawwali': [73, 126, 150, 85],
    'Fado': [110, 90, 150, 78],
    'Andean': [90, 60, 150, 82],
    'Gregorian Chant': [73, 126, 102, 60],
    'Boogie Woogie': [110, 90, 150, 95],
    'Zydeco': [90, 150, 60, 85],
    'Ska': [110, 90, 150, 105],
    'Motown': [90, 102, 60, 88],
    'Disco': [90, 102, 60, 92],
    'New Wave': [94, 51, 102, 88],
    'Grunge': [110, 90, 150, 100],
    'Trip Hop': [94, 60, 102, 75],
    'Dub': [94, 51, 102, 70],
    'Psychedelic Rock': [110, 90, 150, 95],
    'Baroque': [73, 126, 150, 80],
    'Renaissance': [73, 126, 102, 75],
    'Minimalism': [90, 60, 150, 65],
    'Post Rock': [94, 60, 102, 85],
    'Shoegaze': [94, 51, 102, 90],
    'Noise': [30, 94, 110, 100],
    'Drone': [90, 60, 150, 55],
    'Waltz': [110, 90, 150, 85],
    'March': [110, 90, 150, 95],
    'Sea Shanty': [90, 150, 60, 80],
	    'Swing': [110, 90, 150, 95],
    'Bebop': [150, 90, 60, 100],
    'Cool Jazz': [90, 60, 150, 80],
    'Hard Bop': [110, 90, 150, 98],
    'Free Jazz': [30, 94, 110, 85],
    'Modal Jazz': [90, 60, 150, 82],
    'Jazz Fusion': [94, 51, 102, 92],
    'Smooth Jazz': [90, 60, 150, 78],
    'J-Pop': [90, 102, 60, 88],
    'K-Pop': [94, 51, 102, 90],
    'City Pop': [90, 102, 60, 85],
    'Vaporwave': [94, 60, 102, 70],
    'Future Bass': [94, 51, 102, 95],
    'Witch House': [94, 51, 102, 80],
    'Synthpop': [90, 102, 60, 88],
    'Italo Disco': [90, 102, 60, 90],
    'Eurodance': [90, 102, 60, 95],
    'Hardstyle': [94, 51, 102, 110],
    'Gabber': [30, 94, 110, 120],
    'Psytrance': [94, 51, 102, 100],
    'Goa Trance': [94, 51, 102, 98],
    'Progressive House': [90, 102, 60, 88],
    'Deep House': [90, 60, 150, 82],
    'UK Garage': [94, 51, 102, 90],
    'Footwork': [94, 51, 102, 105],
    'Jungle': [94, 51, 102, 108],
		    'Gypsy Jazz': [110, 90, 150, 95],
    'Mambo': [110, 51, 102, 100],
    'Merengue': [90, 102, 60, 95],
    'Bachata': [90, 60, 150, 85],
    'Son Cubano': [90, 150, 60, 88],
    'Rumba': [90, 60, 150, 82],
    'Guaracha': [110, 51, 102, 98],
    'Cha Cha Cha': [90, 102, 60, 92],
    'Danzón': [73, 126, 150, 80],
    'Bolero': [73, 126, 102, 75],
    'Pachanga': [110, 51, 102, 96],
    'Timba': [94, 51, 102, 95],
    'Charanga': [90, 150, 60, 85],
    'Mozambique': [90, 102, 60, 90],
    'Conga': [90, 102, 60, 92],
    'Bomba': [90, 60, 150, 85],
    'Plena': [90, 150, 60, 88],
    'Guajira': [90, 60, 150, 82],
    'Son Montuno': [90, 150, 60, 90],
    'Guaguancó': [90, 60, 150, 85],
    'Colombia': [73, 126, 102, 80],
    'Yambú': [73, 126, 150, 75],
    'Guarapachangueo': [94, 51, 102, 98],
    'Batá': [90, 60, 150, 85],
    'Iyesá': [90, 60, 150, 82],
    'Makuta': [90, 102, 60, 88],
    'Villancico': [73, 126, 150, 80],
    'Punto Cubano': [73, 126, 102, 75],
    'Tonada': [73, 126, 150, 78],
	 'Chaabi': [60, 73, 90, 110],
    'Rai': [45, 73, 60, 105],
    'Gnawa': [73, 60, 90, 110],
    'Andalusisch': [30, 54, 60, 73],
    'Malhoun': [90, 60, 73, 105],
    'Kabyle': [60, 90, 73, 110],
    'Tuareg': [110, 73, 60, 105],
    'DesertBlues': [105, 73, 90, 110],
    'Shaabi': [110, 60, 73, 105],
    'Mahraganat': [90, 73, 60, 110],
    'Tarab': [30, 54, 60, 73],
    'Dabke': [110, 73, 90, 105],
    'Khaliji': [90, 60, 73, 110],
    'Mugham': [54, 30, 60, 73],
    'PersianPop': [73, 90, 60, 110],
    'Arabesk': [60, 73, 90, 105],
    'Fasi': [30, 54, 60, 90],
    'Hawzi': [60, 73, 90, 105],
    'Mezwed': [110, 90, 73, 105],
    'MusiqueOrientale': [30, 60, 73, 90],
    'SaharanRock': [110, 73, 90, 105],
    'MoorishRock': [105, 73, 90, 110],
    'Izran': [60, 73, 90, 110],
    'AmazighRock': [110, 73, 90, 105],
    'Ahidous': [73, 90, 60, 110],
    'Ahwash': [90, 60, 73, 110],
    'Rwayes': [54, 30, 60, 73],
    'Tagnawit': [73, 90, 60, 110],
    'Taqtoqa': [110, 73, 90, 105],
    'Tindé': [60, 73, 90, 105],
	'Classical': [110, 51, 102, 90],
    'Jazz': [110, 102, 60, 85],
    'Blues': [110, 51, 150, 94],
    'Rock': [94, 51, 102, 110],
    'Metal': [90, 51, 60, 73],
    'Pop': [90, 60, 150, 45],
    'R&B': [110, 102, 60, 85],
    'Soul': [110, 51, 150, 94],
    'Funk': [94, 51, 102, 110],
    'Disco': [90, 51, 60, 73],
    'Reggae': [90, 60, 150, 45],
    'Country': [110, 51, 102, 90],
    'Electronic': [110, 102, 60, 85],
    'Folk': [110, 51, 150, 94],
    'Punk': [94, 51, 102, 110],
    'Indie': [90, 51, 60, 73],
    'Alternative': [90, 60, 150, 45],
    'Ambient': [110, 51, 102, 90],
    'Techno': [110, 102, 60, 85],
    'House': [110, 51, 150, 94],
    'Dubstep': [94, 51, 102, 110],
    'Drum and Bass': [90, 51, 60, 73],
    'Trap': [90, 60, 150, 45],
    'Lo-fi': [110, 51, 102, 90],
    'Synth-pop': [110, 102, 60, 85],
    'Electropop': [110, 51, 150, 94],
    'New Wave': [94, 51, 102, 110],
    'Post-punk': [90, 51, 60, 73],
    'Grunge': [90, 60, 150, 45],
    'Emo': [110, 51, 102, 90],
    'Progressive Rock': [110, 102, 60, 85],
    'Psychedelic Rock': [110, 51, 150, 94],
    'Hard Rock': [94, 51, 102, 110],
    'Heavy Metal': [90, 51, 60, 73],
    'Death Metal': [90, 60, 150, 45],
    'Black Metal': [110, 51, 102, 90],
    'Thrash Metal': [110, 102, 60, 85],
    'Power Metal': [110, 51, 150, 94],
    'Gothic Metal': [94, 51, 102, 110],
    'Industrial': [90, 51, 60, 73],
    'Hardcore': [90, 60, 150, 45],
    'Ska': [110, 51, 102, 90],
    'Reggaeton': [110, 102, 60, 85],
    'Salsa': [110, 51, 150, 94],
    'Bachata': [94, 51, 102, 110],
    'Flamenco': [90, 51, 60, 73],
    'Bossa Nova': [90, 60, 150, 45],
    'Samba': [110, 51, 102, 90],
    'Tango': [110, 102, 60, 85],
    'Opera': [110, 51, 150, 94],
    'Choral': [94, 51, 102, 110],
    'Baroque': [90, 51, 60, 73],
    'Romantic': [90, 60, 150, 45],
    'Modern Classical': [110, 51, 102, 90],
    'Minimalism': [110, 102, 60, 85],
    'Avant-garde': [110, 51, 150, 94],
    'Experimental': [94, 51, 102, 110],
    'Noise': [90, 51, 60, 73],
    'Drone': [90, 60, 150, 45],
    'IDM': [110, 51, 102, 90],
    'Glitch': [110, 102, 60, 85],
    'Breakcore': [110, 51, 150, 94],
    'Hardstyle': [94, 51, 102, 110],
	'Gabber': [90, 51, 60, 73],
    'Eurodance': [90, 60, 150, 45],
    'Trance': [110, 51, 102, 90],
    'Psytrance': [110, 102, 60, 85],
    'Hard Trance': [110, 51, 150, 94],
    'Goa Trance': [94, 51, 102, 110],
    'Dream Trance': [90, 51, 60, 73],
    'Progressive Trance': [90, 60, 150, 45],
    'Deep House': [110, 51, 102, 90],
    'Tech House': [110, 102, 60, 85],
    'Acid House': [110, 51, 150, 94],
    'Tropical House': [94, 51, 102, 110],
    'Future House': [90, 51, 60, 73],
    'G-House': [90, 60, 150, 45],
    'Electro House': [110, 51, 102, 90],
    'Big Room': [110, 102, 60, 85],
    'Hard Techno': [110, 51, 150, 94],
    'Minimal Techno': [94, 51, 102, 110],
    'Dub Techno': [90, 51, 60, 73],
    'Acid Techno': [90, 60, 150, 45],
    'Detroit Techno': [110, 51, 102, 90],
    'Liquid Funk': [110, 102, 60, 85],
    'Neurofunk': [110, 51, 150, 94],
    'Jump Up': [94, 51, 102, 110],
    'Jungle': [90, 51, 60, 73],
    'Ragga Jungle': [90, 60, 150, 45],
    'UK Garage': [110, 51, 102, 90],
    '2-Step': [110, 102, 60, 85],
    'Grime': [110, 51, 150, 94],
    'Future Bass': [94, 51, 102, 110],
    'Vaporwave': [90, 51, 60, 73],
    'Synthwave': [90, 60, 150, 45],
    'Chillwave': [110, 51, 102, 90],
    'Darkwave': [110, 102, 60, 85],
    'EBM': [110, 51, 150, 94],
    'Futurepop': [94, 51, 102, 110],
    'Aggrotech': [90, 51, 60, 73],
    'Downtempo': [90, 60, 150, 45],
    'Trip Hop': [110, 51, 102, 90],
    'Psybient': [110, 102, 60, 85],
    'Illbient': [110, 51, 150, 94],
    'Ambient House': [94, 51, 102, 110],
    'Ambient Techno': [90, 51, 60, 73],
    'Dark Ambient': [90, 60, 150, 45],
    'New Age': [110, 51, 102, 90],
    'Space Music': [110, 102, 60, 85],
    'World Music': [110, 51, 150, 94],
    'AfrobeatInMeasure': [94, 51, 102, 110],
    'Ethno Jazz': [90, 51, 60, 73],
    'Latin Jazz': [90, 60, 150, 45],
    'Cool Jazz': [110, 51, 102, 90],
    'Bebop': [110, 102, 60, 85],
    'Hard Bop': [110, 51, 150, 94],
    'Free Jazz': [94, 51, 102, 110],
    'Jazz Fusion': [90, 51, 60, 73],
    'Smooth Jazz': [90, 60, 150, 45],
    'Swing': [110, 51, 102, 90],
    'Big Band': [110, 102, 60, 85],
    'Ragtime': [110, 51, 150, 94],
    'Boogie-woogie': [94, 51, 102, 110],
    'Dixieland': [90, 51, 60, 73],
    'Delta Blues': [90, 60, 150, 45],
    'Chicago Blues': [110, 51, 102, 90],
    'Texas Blues': [110, 102, 60, 85],
	'Jump Blues': [110, 51, 150, 94],
    'Electric Blues': [94, 51, 102, 110],
    'Blues Rock': [90, 51, 60, 73],
    'Southern Rock': [90, 60, 150, 45],
    'Rock and Roll': [110, 51, 102, 90],
    'Rockabilly': [110, 102, 60, 85],
    'Surf Rock': [110, 51, 150, 94],
    'Garage Rock': [94, 51, 102, 110],
    'Glam Rock': [90, 51, 60, 73],
    'Soft Rock': [90, 60, 150, 45],
    'Hard Rock (Alternative)': [110, 51, 102, 90],
    'Arena Rock': [110, 102, 60, 85],
    'Gothic Rock': [110, 51, 150, 94],
    'Shoegaze': [94, 51, 102, 110],
    'Dream Pop': [90, 51, 60, 73],
    'Jangle Pop': [90, 60, 150, 45],
    'Power Pop': [110, 51, 102, 90],
    'Britpop': [110, 102, 60, 85],
    'Madchester': [110, 51, 150, 94],
    'Post-rock': [94, 51, 102, 110],
    'Math Rock': [90, 51, 60, 73],
    'Krautrock': [90, 60, 150, 45],
    'Space Rock': [110, 51, 102, 90],
    'Stoner Rock': [110, 102, 60, 85],
    'Desert Rock': [110, 51, 150, 94],
    'Sludge Metal': [94, 51, 102, 110],
    'Doom Metal': [90, 51, 60, 73],
    'Symphonic Metal': [90, 60, 150, 45],
    'Folk Metal': [110, 51, 102, 90],
    'Viking Metal': [110, 102, 60, 85],
    'Pirate Metal': [110, 51, 150, 94],
    'Nu Metal': [94, 51, 102, 110],
    'Metalcore': [90, 51, 60, 73],
    'Deathcore': [90, 60, 150, 45],
    'Grindcore': [110, 51, 102, 90],
    'Pop Punk': [110, 102, 60, 85],
    'Skate Punk': [110, 51, 150, 94],
    'Hardcore Punk': [94, 51, 102, 110],
    'Post-hardcore': [90, 51, 60, 73],
    'Screamo': [90, 60, 150, 45],
    'Crust Punk': [110, 51, 102, 90],
    'Anarcho-punk': [110, 102, 60, 85],
    'Psychobilly': [110, 51, 150, 94],
    'Horrorpunk': [94, 51, 102, 110],
    'Oi!': [90, 51, 60, 73],
    'Street Punk': [90, 60, 150, 45],
    'Ska Punk': [110, 51, 102, 90],
    'Reggae Rock': [110, 102, 60, 85],
    'Dancehall': [110, 51, 150, 94],
    'Dub': [94, 51, 102, 110],
    'Lovers Rock': [90, 51, 60, 73],
    'Roots Reggae': [90, 60, 150, 45],
    'Ska (Second Wave)': [110, 51, 102, 90],
    'Rocksteady': [110, 102, 60, 85],	
	'Bluegrass': [110, 51, 150, 94],
    'Americana': [94, 51, 102, 110],
    'Alt-country': [90, 51, 60, 73],
    'Honky-tonk': [90, 60, 150, 45],
    'Western Swing': [110, 51, 102, 90],
    'Outlaw Country': [110, 102, 60, 85],
    'Contemporary Country': [110, 51, 150, 94],
    'Celtic Folk': [94, 51, 102, 110],
    'Chanson': [90, 51, 60, 73],
    'Fado': [90, 60, 150, 45],
    'Flamenco (Modern)': [110, 51, 102, 90],
    'Enka': [110, 102, 60, 85],
    'K-pop': [110, 51, 150, 94],
    'J-pop': [94, 51, 102, 110],
    'C-pop': [90, 51, 60, 73],
    'V-pop': [90, 60, 150, 45],
    'Cantopop': [110, 51, 102, 90],
    'Mandopop': [110, 102, 60, 85],
    'Latin Pop': [110, 51, 150, 94],
    'Reggaeton (Modern)': [94, 51, 102, 110],
    'Salsa (Modern)': [90, 51, 60, 73],
    'Merengue': [90, 60, 150, 45],
    'Cumbia': [110, 51, 102, 90],
    'Bachata (Modern)': [110, 102, 60, 85],
    'Mariachi': [110, 51, 150, 94],
    'Ranchera': [94, 51, 102, 110],
    'Bolero': [90, 51, 60, 73],
    'Bossanova (Modern)': [90, 60, 150, 45],
    'Samba (Modern)': [110, 51, 102, 90],
    'MPB': [110, 102, 60, 85],
    'Tropicália': [110, 51, 150, 94],
    'Calypso': [94, 51, 102, 110],
    'Soca': [90, 51, 60, 73],
    'Zouk': [90, 60, 150, 45],
    'Kizomba': [110, 51, 102, 90],
    'Kuduro': [110, 102, 60, 85],
    'Mbaqanga': [110, 51, 150, 94],
    'Highlife': [94, 51, 102, 110],
    'Desert Blues': [90, 51, 60, 73],
    'Gnawa': [90, 60, 150, 45],
    'Rai': [110, 51, 102, 90],
    'Qawwali': [110, 102, 60, 85],
    'Hindustani': [110, 51, 150, 94],
    'Carnatic': [94, 51, 102, 110],
    'Thai Pop': [90, 51, 60, 73],
    'Luk Thung': [90, 60, 150, 45],
    'Dangdut': [110, 51, 102, 90],
    'V-pop (Contemporary)': [110, 102, 60, 85],
    'P-pop': [110, 51, 150, 94],
    'Anison': [94, 51, 102, 110],
    'Video Game Music': [90, 51, 60, 73],
    'Chiptune': [90, 60, 150, 45],
    'Soundtrack': [110, 51, 102, 90],
    'Film Score': [110, 102, 60, 85],
    'Production Music': [110, 51, 150, 94],
    'Trailer Music': [94, 51, 102, 110],
    'Holiday Music': [90, 51, 60, 73],
    'Christian Music': [90, 60, 150, 45],
    'Gospel': [110, 51, 102, 90],
    'Contemporary Christian': [110, 102, 60, 85],
    'Children\'s Music': [110, 51, 150, 94],
    'Comedy Music': [94, 51, 102, 110],
    'Novelty Music': [90, 51, 60, 73],
    'Plunderphonics': [90, 60, 150, 45]
	
        };

        const GENRE_PERCUSSION = {
            'none':[],
            'Glitch Capitalism': [35, 38, 42],
            'soft': [36, 40, 42],
            'orchestral': [35, 40, 42],
            'electro': [36, 39, 42],
            '909': [36, 38, 42],
            '707': [36, 40, 42],
            'amen': [36, 38, 42],
            'heavy': [35, 38, 42],
            'boom-bap': [36, 40, 42],
            '808': [36, 39, 42],
            'pop': [36, 38, 42],
            'rock': [35, 38, 42],
            'metal': [35, 38, 42],
            'jazz': [35, 40, 42],
            'blues': [36, 38, 42],
            'funk': [36, 39, 42],
            'reggae': [36, 38, 42],
            'afro': [36, 42, 54],
            'latin': [36, 42, 54],
            'bossa': [36, 38, 42],
            'folk': [35, 38, 42],
            'tabla': [66, 60, 62],
            'daf': [35, 60, 54],
            'lofi': [36, 38, 42],
            'glitch': [36, 38, 42],
            'chinese': [60, 62, 54],
            'chinese_traditional': [60, 62, 77],
            'chips': [36, 38, 42],			
    'samba': [36, 38, 54],
    'tango': [36, 40, 42],
    'flamenco': [36, 37, 39],
    'highlife': [36, 38, 42],
    'soukous': [36, 38, 42],
    'bhangra': [36, 42, 54],
    'balkan': [36, 38, 42],
    'zydeco': [36, 38, 42],
    'cumbia': [36, 38, 42],
    'mariachi': [36, 38, 42],
    'polka': [36, 38, 42],
    'gospel': [36, 38, 42],
    'ska': [36, 38, 42],
    'soca': [36, 38, 42],
    'juju': [36, 38, 54],
    'mbalax': [36, 38, 54],
    'forro': [36, 38, 42],
    'calypso': [36, 38, 42],
    'gagaku': [66, 60, 77],
	    'griot': [36, 54, 77],
    'qawwali': [66, 60, 62],
    'fado': [36, 38, 42],
    'andean': [36, 54, 115],
    'chant': [47, 55, 14],
    'boogie': [36, 38, 42],
    'zydeco': [36, 38, 42],
    'ska': [36, 38, 42],
    'motown': [36, 38, 42],
    'disco': [36, 38, 42],
    'newwave': [36, 38, 42],
    'grunge': [36, 38, 42],
    'triphop': [36, 38, 42],
    'dub': [36, 38, 42],
    'psych': [36, 38, 42],
    'baroque': [47, 46, 14],
    'renaissance': [47, 46, 13],
    'minimal': [36, 38, 42],
    'postrock': [36, 38, 42],
    'shoegaze': [36, 38, 42],
    'noise': [36, 38, 118],
    'drone': [47, 55, 14],
    'waltz': [36, 38, 42],
    'march': [36, 38, 47],
    'shanty': [36, 38, 42],
	    'swing': [36, 38, 42],
    'bebop': [36, 38, 42],
    'cooljazz': [36, 38, 42],
    'hardbop': [36, 38, 42],
    'freejazz': [36, 38, 42],
    'modaljazz': [36, 38, 42],
    'fusion': [36, 38, 42],
    'smoothjazz': [36, 38, 42],
    'jpop': [36, 38, 42],
    'kpop': [36, 38, 42],
    'citypop': [36, 38, 42],
    'vaporwave': [36, 38, 42],
    'futurebass': [36, 38, 42],
    'witchhouse': [36, 38, 42],
    'synthpop': [36, 38, 42],
    'italo': [36, 38, 42],
    'eurodance': [36, 38, 42],
    'hardstyle': [36, 38, 42],
    'gabber': [36, 38, 42],
    'psytrance': [36, 38, 42],
    'goa': [36, 38, 42],
    'proghouse': [36, 38, 42],
    'deephouse': [36, 38, 42],
    'ukgarage': [36, 38, 42],
    'footwork': [36, 38, 42],
    'jungle': [36, 38, 42],
	    'gypsy': [36, 38, 42],
    'mambo': [36, 42, 54],
    'merengue': [36, 38, 42],
    'bachata': [36, 38, 42],
    'son': [36, 38, 42],
    'rumba': [36, 42, 54],
    'guaracha': [36, 38, 42],
    'chacha': [36, 38, 42],
    'danzon': [36, 38, 42],
    'bolero': [36, 38, 42],
    'pachanga': [36, 38, 42],
    'timba': [36, 38, 42],
    'charanga': [36, 38, 42],
    'mozambique': [36, 42, 54],
    'conga': [36, 42, 54],
    'bomba': [36, 42, 54],
    'plena': [36, 38, 42],
    'guajira': [36, 38, 42],
    'montuno': [36, 38, 42],
    'guaguanco': [36, 42, 54],
    'colombia': [36, 42, 54],
    'yambu': [36, 42, 54],
    'guarapachangueo': [36, 42, 54],
    'bata': [36, 42, 54],
    'iyesa': [36, 42, 54],
    'makuta': [36, 42, 54],
    'villancico': [36, 38, 42],
    'punto': [36, 38, 42],
    'tonada': [36, 38, 42],
    'darbuka': [36, 38, 42],       
    'bendir': [54, 56, 60],   
    'daf': [54, 56, 60],          
    'taarija': [37, 39, 43],      
    'tabla': [60, 62, 64],           
    'riqq': [65, 66, 67],            
    'rockkit': [36, 38, 42],         
    'electronic': [80, 81, 82],     
    'tbel': [75, 76, 77],            
    'qraqeb': [70, 71, 72],         
    'ney': [73, 74, 75],              
    'oud': [25, 26, 27],            
    'kanun': [28, 29, 30],           
    'neyzan': [76, 77, 78],          
    'gasba': [79, 80, 81],           
    'guembri': [31, 32, 33],        
    'lotar': [34, 35, 36],           
    'zurna': [82, 83, 84],           
    'mizmar': [85, 86, 87],          
    'rabab': [37, 38, 39],            
    'violin': [40, 41, 42],          
    'accordion': [43, 44, 45],       
    'synthesizer': [88, 89, 90],    
    'chant': [91, 92, 93],          
    'handclap': [39, 40, 41],        
    'fingercymbals': [42, 43, 44],   
    'waterdrum': [45, 46, 47],       
    'windchimes': [94, 95, 96],      
    'thunder': [97, 98, 99],         
    'rain': [100, 101, 102],         
	'Classical': [35, 40, 42],
    'Jazz': [36, 40, 42],
    'Blues': [36, 38, 42],
    'Rock': [36, 38, 42],
    'Metal': [35, 38, 42],
    'Pop': [36, 40, 42],
    'R&B': [36, 40, 42],
    'Soul': [36, 38, 42],
    'Funk': [36, 38, 42],
    'Disco': [36, 38, 42],
    'Reggae': [36, 40, 42],
    'Country': [36, 38, 42],
    'Electronic': [36, 39, 42],
    'Folk': [36, 40, 42],
    'Punk': [36, 38, 42],
    'Indie': [36, 40, 42],
    'Alternative': [36, 38, 42],
    'Ambient': [36, 40, 42],
    'Techno': [36, 38, 42],
    'House': [36, 38, 42],
    'Dubstep': [35, 38, 42],
    'Drum and Bass': [36, 38, 42],
    'Trap': [36, 39, 42],
    'Lo-fi': [36, 40, 42],
    'Synth-pop': [36, 39, 42],
    'Electropop': [36, 40, 42],
    'New Wave': [36, 40, 42],
    'Post-punk': [36, 38, 42],
    'Grunge': [36, 38, 42],
    'Emo': [36, 38, 42],
    'Progressive Rock': [36, 38, 42],
    'Psychedelic Rock': [36, 38, 42],
    'Hard Rock': [35, 38, 42],
    'Heavy Metal': [35, 38, 42],
    'Death Metal': [35, 38, 42],
    'Black Metal': [35, 38, 42],
    'Thrash Metal': [35, 38, 42],
    'Power Metal': [35, 38, 42],
    'Gothic Metal': [35, 38, 42],
    'Industrial': [36, 38, 42],
    'Hardcore': [36, 38, 42],
    'Ska': [36, 38, 42],
    'Reggaeton': [36, 39, 42],
    'Salsa': [36, 40, 42],
    'Bachata': [36, 40, 42],
    'Flamenco': [36, 40, 42],
    'Bossa Nova': [36, 40, 42],
    'Samba': [36, 40, 42],
    'Tango': [36, 40, 42],
    'Opera': [35, 40, 42],
    'Choral': [35, 40, 42],
    'Baroque': [35, 40, 42],
    'Romantic': [35, 40, 42],
    'Modern Classical': [35, 40, 42],
    'Minimalism': [36, 40, 42],
    'Avant-garde': [36, 40, 42],
    'Experimental': [36, 40, 42],
    'Noise': [35, 38, 42],
    'Drone': [36, 40, 42],
    'IDM': [36, 39, 42],
    'Glitch': [36, 39, 42],
    'Breakcore': [36, 38, 42],
    'Hardstyle': [35, 38, 42],
	'Gabber': [35, 38, 42],
    'Eurodance': [36, 38, 42],
    'Trance': [36, 38, 42],
    'Psytrance': [36, 38, 42],
    'Hard Trance': [36, 38, 42],
    'Goa Trance': [36, 38, 42],
    'Dream Trance': [36, 40, 42],
    'Progressive Trance': [36, 38, 42],
    'Deep House': [36, 38, 42],
    'Tech House': [36, 38, 42],
    'Acid House': [36, 38, 42],
    'Tropical House': [36, 40, 42],
    'Future House': [36, 38, 42],
    'G-House': [36, 39, 42],
    'Electro House': [36, 39, 42],
    'Big Room': [35, 38, 42],
    'Hard Techno': [35, 38, 42],
    'Minimal Techno': [36, 38, 42],
    'Dub Techno': [36, 40, 42],
    'Acid Techno': [36, 38, 42],
    'Detroit Techno': [36, 38, 42],
    'Liquid Funk': [36, 40, 42],
    'Neurofunk': [36, 38, 42],
    'Jump Up': [36, 38, 42],
    'Jungle': [36, 38, 42],
    'Ragga Jungle': [36, 38, 42],
    'UK Garage': [36, 38, 42],
    '2-Step': [36, 38, 42],
    'Grime': [36, 39, 42],
    'Future Bass': [36, 39, 42],
    'Vaporwave': [36, 40, 42],
    'Synthwave': [36, 39, 42],
    'Chillwave': [36, 40, 42],
    'Darkwave': [36, 38, 42],
    'EBM': [36, 38, 42],
    'Futurepop': [36, 40, 42],
    'Aggrotech': [35, 38, 42],
    'Downtempo': [36, 40, 42],
    'Trip Hop': [36, 39, 42],
    'Psybient': [36, 40, 42],
    'Illbient': [36, 40, 42],
    'Ambient House': [36, 40, 42],
    'Ambient Techno': [36, 40, 42],
    'Dark Ambient': [36, 40, 42],
    'New Age': [36, 40, 42],
    'Space Music': [36, 40, 42],
    'World Music': [36, 40, 42],
    'AfrobeatInMeasure': [36, 38, 42],
    'Ethno Jazz': [36, 40, 42],
    'Latin Jazz': [36, 40, 42],
    'Cool Jazz': [36, 40, 42],
    'Bebop': [36, 38, 42],
    'Hard Bop': [36, 38, 42],
    'Free Jazz': [36, 40, 42],
    'Jazz Fusion': [36, 38, 42],
    'Smooth Jazz': [36, 40, 42],
    'Swing': [36, 40, 42],
    'Big Band': [36, 40, 42],
    'Ragtime': [36, 40, 42],
    'Boogie-woogie': [36, 38, 42],
    'Dixieland': [36, 40, 42],
    'Delta Blues': [36, 38, 42],
    'Chicago Blues': [36, 38, 42],
    'Texas Blues': [36, 38, 42],
	'Jump Blues': [36, 38, 42],
    'Electric Blues': [36, 38, 42],
    'Blues Rock': [36, 38, 42],
    'Southern Rock': [36, 38, 42],
    'Rock and Roll': [36, 38, 42],
    'Rockabilly': [36, 38, 42],
    'Surf Rock': [36, 38, 42],
    'Garage Rock': [36, 38, 42],
    'Glam Rock': [36, 38, 42],
    'Soft Rock': [36, 40, 42],
    'Hard Rock (Alternative)': [35, 38, 42],
    'Arena Rock': [36, 38, 42],
    'Gothic Rock': [36, 38, 42],
    'Shoegaze': [36, 40, 42],
    'Dream Pop': [36, 40, 42],
    'Jangle Pop': [36, 40, 42],
    'Power Pop': [36, 40, 42],
    'Britpop': [36, 40, 42],
    'Madchester': [36, 38, 42],
    'Post-rock': [36, 40, 42],
    'Math Rock': [36, 38, 42],
    'Krautrock': [36, 38, 42],
    'Space Rock': [36, 38, 42],
    'Stoner Rock': [35, 38, 42],
    'Desert Rock': [36, 38, 42],
    'Sludge Metal': [35, 38, 42],
    'Doom Metal': [35, 38, 42],
    'Symphonic Metal': [35, 38, 42],
    'Folk Metal': [35, 38, 42],
    'Viking Metal': [35, 38, 42],
    'Pirate Metal': [35, 38, 42],
    'Nu Metal': [35, 38, 42],
    'Metalcore': [35, 38, 42],
    'Deathcore': [35, 38, 42],
    'Grindcore': [35, 38, 42],
    'Pop Punk': [36, 38, 42],
    'Skate Punk': [36, 38, 42],
    'Hardcore Punk': [36, 38, 42],
    'Post-hardcore': [36, 38, 42],
    'Screamo': [36, 38, 42],
    'Crust Punk': [36, 38, 42],
    'Anarcho-punk': [36, 38, 42],
    'Psychobilly': [36, 38, 42],
    'Horrorpunk': [36, 38, 42],
    'Oi!': [36, 38, 42],
    'Street Punk': [36, 38, 42],
    'Ska Punk': [36, 38, 42],
    'Reggae Rock': [36, 40, 42],
    'Dancehall': [36, 39, 42],
    'Dub': [36, 40, 42],
    'Lovers Rock': [36, 40, 42],
    'Roots Reggae': [36, 40, 42],
    'Ska (Second Wave)': [36, 38, 42],
    'Rocksteady': [36, 40, 42],
	'Bluegrass': [36, 40, 42],
    'Americana': [36, 38, 42],
    'Alt-country': [36, 38, 42],
    'Honky-tonk': [36, 38, 42],
    'Western Swing': [36, 40, 42],
    'Outlaw Country': [36, 38, 42],
    'Contemporary Country': [36, 38, 42],
    'Celtic Folk': [36, 40, 42],
    'Chanson': [36, 40, 42],
    'Fado': [36, 40, 42],
    'Flamenco (Modern)': [36, 40, 42],
    'Enka': [36, 40, 42],
    'K-pop': [36, 39, 42],
    'J-pop': [36, 40, 42],
    'C-pop': [36, 40, 42],
    'V-pop': [36, 40, 42],
    'Cantopop': [36, 40, 42],
    'Mandopop': [36, 40, 42],
    'Latin Pop': [36, 40, 42],
    'Reggaeton (Modern)': [36, 39, 42],
    'Salsa (Modern)': [36, 40, 42],
    'Merengue': [36, 40, 42],
    'Cumbia': [36, 40, 42],
    'Bachata (Modern)': [36, 40, 42],
    'Mariachi': [36, 40, 42],
    'Ranchera': [36, 40, 42],
    'Bolero': [36, 40, 42],
    'Bossanova (Modern)': [36, 40, 42],
    'Samba (Modern)': [36, 40, 42],
    'MPB': [36, 40, 42],
    'Tropicália': [36, 38, 42],
    'Calypso': [36, 40, 42],
    'Soca': [36, 40, 42],
    'Zouk': [36, 40, 42],
    'Kizomba': [36, 40, 42],
    'Kuduro': [36, 39, 42],
    'Mbaqanga': [36, 38, 42],
    'Highlife': [36, 38, 42],
    'Desert Blues': [36, 38, 42],
    'Gnawa': [36, 40, 42],
    'Rai': [36, 38, 42],
    'Qawwali': [36, 40, 42],
    'Hindustani': [35, 40, 42],
    'Carnatic': [35, 40, 42],
    'Thai Pop': [36, 40, 42],
    'Luk Thung': [36, 40, 42],
    'Dangdut': [36, 38, 42],
    'V-pop (Contemporary)': [36, 40, 42],
    'P-pop': [36, 40, 42],
    'Anison': [36, 39, 42],
    'Video Game Music': [36, 39, 42],
    'Chiptune': [36, 39, 42],
    'Soundtrack': [35, 40, 42],
    'Film Score': [35, 40, 42],
    'Production Music': [36, 40, 42],
    'Trailer Music': [35, 38, 42],
    'Holiday Music': [36, 40, 42],
    'Christian Music': [36, 40, 42],
    'Gospel': [36, 38, 42],
    'Contemporary Christian': [36, 40, 42],
    'Children\'s Music': [36, 40, 42],
    'Comedy Music': [36, 40, 42],
    'Novelty Music': [36, 40, 42],
    'Plunderphonics': [36, 39, 42]
	
        };
		
		
		const GENRE_PERCUSSION_ONS = {
            'Glitch Capitalism': [
  [(beatInMeasure) => (beatInMeasure % 7 === 0 || beatInMeasure % 13 === 0), 0.8], 
  [(beatInMeasure) => (beatInMeasure % 2 !== 0), 0.4], 
  [(beatInMeasure) => (Math.random() < 0.2), 0.9] 
],
    'soft': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 4 === 2), 0.3],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.7]
    ],
    'orchestral': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0 || beatInMeasure % 16 === 8), 0.8]
    ],
    'electro': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.2],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 && Math.random() < 0.7), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 3 && Math.random() < 0.5)), 0.6]
    ],
    '909': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.25],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1), 0.75]
    ],
    '707': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'amen': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.15],
        [(beatInMeasure) => (beatInMeasure % 8 === 2 || beatInMeasure % 8 === 6), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.6]
    ],
    'heavy': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.8), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1 || beatInMeasure % 8 === 3), 0.9]
    ],
    'boom-bap': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.6), 0.35],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.65],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 1 && Math.random() < 0.4)), 0.8]
    ],
    '808': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.2],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || (beatInMeasure % 8 === 6 && Math.random() < 0.3)), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1 || (beatInMeasure % 16 === 11 && Math.random() < 0.5)), 0.9]
    ],
    'pop': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7]
    ],
    'rock': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 1 && Math.random() < 0.6)), 0.8]
    ],
    'metal': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0 && Math.random() < 0.7), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || (beatInMeasure % 4 === 1 && Math.random() < 0.5)), 0.9]
    ],
    'jazz': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.7), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 4 === 3), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 4), 0.7]
    ],
    'blues': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 4 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 1 && Math.random() < 0.3)), 0.7]
    ],
    'funk': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.8), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || (beatInMeasure % 8 === 4 && Math.random() < 0.5)), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1 || beatInMeasure % 8 === 3), 0.7]
    ],
    'reggae': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 3), 0.8]
    ],
    'afro': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.7]
    ],
    'latin': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3), 0.7]
    ],
    'bossa': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.25],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3), 0.6]
    ],
    'folk': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 4 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7]
    ],
    'tabla': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 4 || beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0 || beatInMeasure % 16 === 8 || beatInMeasure % 16 === 12), 0.8]
    ],
    'daf': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3), 0.7]
    ],
    'lofi': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.6), 0.25],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 && Math.random() < 0.8), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 && Math.random() < 0.9), 0.6]
    ],
    'glitch': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0 && Math.random() < 0.3), 0.2],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || (beatInMeasure % 8 === 5 && Math.random() < 0.4)), 0.4],
        [(beatInMeasure) => ((beatInMeasure % 3 === 0 || beatInMeasure % 5 === 0) && Math.random() < 0.6), 0.6]
    ],
    'chinese': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 4 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 6), 0.8]
    ],
    'chinese_traditional': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4 || beatInMeasure % 8 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 0 || beatInMeasure % 16 === 8), 0.9]
    ],
    'chips': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.2],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1), 0.6]
    ],
	 'samba': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9]
    ],
    'tango': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'flamenco': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 && Math.random() < 0.7), 0.4],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6],
        [(beatInMeasure) => ((beatInMeasure % 3 === 0 || beatInMeasure % 5 === 0) && Math.random() < 0.5), 0.8]
    ],
    'highlife': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3), 0.8]
    ],
    'soukous': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1 || beatInMeasure % 8 === 3), 0.7]
    ],
    'bhangra': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.8]
    ],
    'balkan': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0 && Math.random() < 0.8), 0.5],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 3 === 0 && Math.random() < 0.6)), 0.9]
    ],
    'zydeco': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1), 0.8]
    ],
    'cumbia': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3), 0.7]
    ],
    'mariachi': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1), 0.8]
    ],
    'polka': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9]
    ],
    'gospel': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.7), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 4), 0.8]
    ],
    'ska': [
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.4], 
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'soca': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1 || beatInMeasure % 8 === 3), 0.7]
    ],
    'juju': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3), 0.8]
    ],
    'mbalax': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.7]
    ],
    'forro': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1), 0.8]
    ],
    'calypso': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3), 0.7]
    ],
    'gagaku': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.9]
    ],
	    'griot': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.9]
    ],
    'qawwali': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.9]
    ],
    'fado': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'andean': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'chant': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.9]
    ],
    'boogie': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'disco': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.9]
    ],
    'newwave': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'triphop': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.6), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7]
    ],
    'baroque': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.9]
    ],
    'minimal': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.9]
    ],
    'waltz': [
        [(beatInMeasure) => (beatInMeasure % 3 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 6 === 3), 0.8],
        [(beatInMeasure) => (beatInMeasure % 12 === 0), 0.9]
    ],
    'march': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'shanty': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
	
	    'swing': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 1 && Math.random() < 0.3)), 0.8]
    ],
    'bebop': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0 && Math.random() < 0.7), 0.5],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 3 && Math.random() < 0.5)), 0.9]
    ],
    'cooljazz': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.6), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7]
    ],
    'hardbop': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 1 && Math.random() < 0.4)), 0.9]
    ],
    'freejazz': [
        [(beatInMeasure) => (Math.random() < 0.4), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || (beatInMeasure % 8 === 6 && Math.random() < 0.6)), 0.5],
        [(beatInMeasure) => ((beatInMeasure % 3 === 0 || beatInMeasure % 5 === 0) && Math.random() < 0.7), 0.7]
    ],
    'modaljazz': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 4 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.8]
    ],
    'fusion': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1), 0.8]
    ],
    'smoothjazz': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.8), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7]
    ],
    'jpop': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'kpop': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1), 0.8]
    ],
    'citypop': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7]
    ],
    'vaporwave': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 && Math.random() < 0.7), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8]
    ],
    'futurebass': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 1 && Math.random() < 0.4)), 0.7]
    ],
    'witchhouse': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 && Math.random() < 0.6), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0 || beatInMeasure % 16 === 8), 0.8]
    ],
    'synthpop': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'italo': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1), 0.8]
    ],
    'eurodance': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'hardstyle': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9]
    ],
    'gabber': [
        [(beatInMeasure) => (beatInMeasure % 0.5 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9]
    ],
    'psytrance': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'goa': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 3 && Math.random() < 0.5)), 0.9]
    ],
    'proghouse': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'deephouse': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.7), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7]
    ],
    'ukgarage': [
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.4], 
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'footwork': [
        [(beatInMeasure) => (beatInMeasure % 0.5 === 0 && Math.random() < 0.6), 0.3],
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7]
    ],
    'jungle': [
        [(beatInMeasure) => (beatInMeasure % 0.5 === 0), 0.2],
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8]
    ],
	    'gypsy': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 1 && Math.random() < 0.4)), 0.8]
    ],
    'mambo': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1 || beatInMeasure % 8 === 3), 0.8]
    ],
    'merengue': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'bachata': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 4 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 8 === 1 && Math.random() < 0.3)), 0.7]
    ],
    'son': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'rumba': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.7]
    ],
    'guaracha': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'chacha': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 4 === 3), 0.8]
    ],
    'danzon': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'bolero': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'pachanga': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'timba': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 1 || beatInMeasure % 8 === 3), 0.8]
    ],
    'charanga': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'mozambique': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.7]
    ],
    'conga': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.7]
    ],
    'bomba': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.7]
    ],
    'plena': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'guajira': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'montuno': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'guaguanco': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.7]
    ],
    'colombia': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.7]
    ],
    'yambu': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.3],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 5), 0.7]
    ],
    'guarapachangueo': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8]
    ],
    'bata': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.9]
    ],
    'iyesa': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.9]
    ],
    'makuta': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.9]
    ],
    'villancico': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'punto': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'tonada': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
	 'daf': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],                      
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 6), 0.5], 
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3), 0.7]  
    ],
    'darbuka': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0 || beatInMeasure % 4 === 1), 0.4], 
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 8 === 3), 0.6], 
        [(beatInMeasure) => (beatInMeasure % 8 === 4 || beatInMeasure % 8 === 7), 0.5]  
    ],
    'bendir': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.4],                       
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && beatInMeasure % 4 !== 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 3 || beatInMeasure % 8 === 7), 0.5]  
    ],
    'taarija': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5],                         
        [(beatInMeasure) => (beatInMeasure % 4 === 1), 0.4],                         
        [(beatInMeasure) => (beatInMeasure % 8 === 3 || beatInMeasure % 8 === 6), 0.6]  
    ],
    'tabla': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],                         
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.6],                        
        [(beatInMeasure) => (beatInMeasure % 8 === 2 || beatInMeasure % 8 === 5), 0.4]  
   ],
    'riqq':[
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],                       
        [(beatInMeasure) => (beatInMeasure % 4 === 1), 0.5],                         
        [(beatInMeasure) => (beatInMeasure % 8 === 3 || beatInMeasure % 8 === 7), 0.7] 
    ],         
    'rockkit': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3],                        
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.5],                         
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.2]                       
    ],
    'electronic': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],                        
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.6],                        
        [(beatInMeasure) => (beatInMeasure % 0.5 === 0), 0.4]                      
    ],
    'tbel': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],                        
        [(beatInMeasure) => (beatInMeasure % 4 === 1), 0.5],                        
        [(beatInMeasure) => (beatInMeasure % 8 === 3), 0.6]                         
    ],
    'qraqeb': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.4],                       
        [(beatInMeasure) => (beatInMeasure % 2 === 0.5), 0.6],                      
        [(beatInMeasure) => (beatInMeasure % 4 === 1.5), 0.5]                      
    ],
    'ney': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.3],                       
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.2],                       
        [(beatInMeasure) => (beatInMeasure % 8 === 3), 0.4]                          
    ],
    'oud': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],                      
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.3],                        
        [(beatInMeasure) => (beatInMeasure % 8 === 2), 0.6]                  
    ],
    'kanun': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.4],                       
        [(beatInMeasure) => (beatInMeasure % 2 === 0.5), 0.3],                   
        [(beatInMeasure) => (beatInMeasure % 8 === 3.5), 0.5]                   
    ],
    'neyzan': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6],                        
        [(beatInMeasure) => (beatInMeasure % 4 === 1), 0.4],                       
        [(beatInMeasure) => (beatInMeasure % 8 === 3), 0.7]                 
    ],
    'gasba': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],                    
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.3],                    
        [(beatInMeasure) => (beatInMeasure % 8 === 2.5), 0.6]                  
    ],
    'guembri': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],                    
        [(beatInMeasure) => (beatInMeasure % 4 === 1), 0.5],              
        [(beatInMeasure) => (beatInMeasure % 8 === 3.5), 0.6]                 
    ],
    'lotar': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],                       
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.4],                         
        [(beatInMeasure) => (beatInMeasure % 8 === 2.5), 0.7]                 
    ],
    'zurna': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8],                 
        [(beatInMeasure) => (beatInMeasure % 4 === 1), 0.6],                     
        [(beatInMeasure) => (beatInMeasure % 8 === 3), 0.9]                        
    ],
    'mizmar': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],                      
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.5],                   
        [(beatInMeasure) => (beatInMeasure % 8 === 2.5), 0.8]                     
    ],
    'rabab': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5],                
        [(beatInMeasure) => (beatInMeasure % 4 === 1), 0.3],                   
        [(beatInMeasure) => (beatInMeasure % 8 === 3.5), 0.6]                 
    ],
    'violin': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.4],               
        [(beatInMeasure) => (beatInMeasure % 2 === 0.5), 0.6],                    
        [(beatInMeasure) => (beatInMeasure % 8 === 2), 0.7]                    
    ],
    'accordion': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5],                    
        [(beatInMeasure) => (beatInMeasure % 4 === 1), 0.4],                   
        [(beatInMeasure) => (beatInMeasure % 8 === 3.5), 0.6]                     
    ],
    'synthesizer': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],                         
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.5],                       
        [(beatInMeasure) => (beatInMeasure % 8 === 2.5), 0.8]                  
    ],
    'chant': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],                      
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.4],                
        [(beatInMeasure) => (beatInMeasure % 8 === 3), 0.7]                        
    ],
    'handclap': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5],                       
        [(beatInMeasure) => (beatInMeasure % 4 === 1), 0.7],                      
        [(beatInMeasure) => (beatInMeasure % 8 === 3.5), 0.6]                    
    ],
    'fingercymbals': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.3],                       
        [(beatInMeasure) => (beatInMeasure % 2 === 0.5), 0.5],                
        [(beatInMeasure) => (beatInMeasure % 4 === 1.5), 0.4]              
    ],
    'waterdrum': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],                  
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.4],           
        [(beatInMeasure) => (beatInMeasure % 8 === 2.5), 0.5]                    
    ],
    'windchimes': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.7],                       
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],                        
        [(beatInMeasure) => (beatInMeasure % 2 === 1), 0.3]                 
    ],
    'thunder': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.9],               
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],                
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5]                       
    ],
    'rain': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.2],                     
        [(beatInMeasure) => (beatInMeasure % 2 === 0.5), 0.4],                   
        [(beatInMeasure) => (beatInMeasure % 4 === 1.5), 0.3]                      
    ],
	    'Classical': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8]
    ],
    'Jazz': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || (beatInMeasure % 4 === 3 && Math.random() < 0.3)), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 2 || beatInMeasure % 8 === 6), 0.4],
        [(beatInMeasure) => (beatInMeasure % 2 === 0 && Math.random() < 0.6), 0.3]
    ],
    'Blues': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 3 || beatInMeasure % 8 === 7), 0.3]
    ],
    'Rock': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4]
    ],
    'Metal': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 1 || beatInMeasure % 8 === 5), 0.6]
    ],
    'Pop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'R&B': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.4]
    ],
    'Soul': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 6), 0.4]
    ],
    'Funk': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 3 || beatInMeasure % 16 === 11), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Disco': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Reggae': [
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Country': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.4]
    ],
    'Electronic': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4]
    ],
    'Folk': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.6]
    ],
    'Punk': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'Indie': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4]
    ],
    'Alternative': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3]
    ],
    'Ambient': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0 && Math.random() < 0.4), 0.3],
        [(beatInMeasure) => (beatInMeasure % 32 === 16), 0.2],
        [(beatInMeasure) => (beatInMeasure % 64 === 0), 0.5]
    ],
    'Techno': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'House': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 2 || beatInMeasure % 16 === 10), 0.3]
    ],
    'Dubstep': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.8],
        [(beatInMeasure) => (beatInMeasure % 32 === 28), 0.6]
    ],
    'Drum and Bass': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.6]
    ],
    'Trap': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 6 || beatInMeasure % 16 === 14), 0.5]
    ],
    'Lo-fi': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 10 && Math.random() < 0.5), 0.3]
    ],
    'Synth-pop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4]
    ],
    'Electropop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'New Wave': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Post-punk': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4]
    ],
    'Grunge': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.5]
    ],
    'Emo': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4]
    ],
    'Progressive Rock': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4 || beatInMeasure % 16 === 14), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5]
    ],
	'Psychedelic Rock': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.4]
    ],
    'Hard Rock': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6]
    ],
    'Heavy Metal': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.7]
    ],
    'Death Metal': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 1.0]
    ],
    'Black Metal': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.7]
    ],
    'Thrash Metal': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 1 === 0 && Math.random() < 0.5), 0.6]
    ],
    'Power Metal': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7]
    ],
    'Gothic Metal': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8]
    ],
    'Industrial': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 6), 0.6]
    ],
    'Hardcore': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7]
    ],
    'Ska': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 1 || beatInMeasure % 4 === 3), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'Reggaeton': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4 || beatInMeasure % 8 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6]
    ],
    'Salsa': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0 || beatInMeasure % 16 === 3 || beatInMeasure % 16 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 10 || beatInMeasure % 16 === 12), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5]
    ],
    'Bachata': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Flamenco': [
        [(beatInMeasure) => (beatInMeasure % 12 === 0 || beatInMeasure % 12 === 3 || beatInMeasure % 12 === 6 || beatInMeasure % 12 === 8 || beatInMeasure % 12 === 10), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4]
    ],
    'Bossa Nova': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0 || beatInMeasure % 16 === 3 || beatInMeasure % 16 === 7 || beatInMeasure % 16 === 10), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'Samba': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 14), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 2 || beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5]
    ],
    'Tango': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 15), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.5]
    ],
    'Opera': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.7]
    ],
    'Choral': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.6]
    ],
    'Baroque': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.7]
    ],
    'Romantic': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.6]
    ],
    'Modern Classical': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 && Math.random() < 0.7), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.6]
    ],
    'Minimalism': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.3]
    ],
    'Avant-garde': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 && Math.random() < 0.5), 0.4],
        [(beatInMeasure) => (beatInMeasure % 7 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 13 === 0), 0.5]
    ],
    'Experimental': [
        [(beatInMeasure) => (Math.random() < 0.3), 0.4],
        [(beatInMeasure) => (beatInMeasure % 5 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.6]
    ],
    'Noise': [
        [(beatInMeasure) => (Math.random() < 0.8), 0.5],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6]
    ],
    'Drone': [
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 64 === 32), 0.2],
        [(beatInMeasure) => (beatInMeasure % 128 === 0), 0.4]
    ],
    'IDM': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0 || (beatInMeasure % 16 === 11 && Math.random() < 0.7)), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4 || beatInMeasure % 32 === 27), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 && Math.random() < 0.4), 0.3]
    ],
    'Glitch': [
        [(beatInMeasure) => (Math.random() < 0.4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.7]
    ],
    'Breakcore': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0 && Math.random() < 0.7), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 11 || beatInMeasure % 16 === 15), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9]
    ],
    'Hardstyle': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
	'Soca': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 3 || beatInMeasure % 16 === 11), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 6), 0.7]
    ],
    'Calypso': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Grime': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 14), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 10 && Math.random() < 0.6), 0.5]
    ],
    'Garage': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 13 || beatInMeasure % 16 === 15), 0.6]
    ],
    'Dub': [
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.9],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.6],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.4]
    ],
    'Dancehall': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 6), 0.6]
    ],
    'Hard Trance': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5]
    ],
    'Nu-Disco': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Phonk': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 6), 0.4]
    ],
    'Synthpop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'New Romantic': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.7]
    ],
    'Electro': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 10), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4]
    ],
    'Freestyle': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.5]
    ],
    'Electro Funk': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 3 || beatInMeasure % 16 === 11), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7]
    ],
    'Merengue': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 15), 0.5]
    ],
    'Mariachi': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.7]
    ],
    'K-pop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'J-pop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'City Pop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Viking Metal': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6]
    ],
    'Pirate Metal': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 2 || beatInMeasure % 8 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5]
    ],
    'Soundtrack': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 && Math.random() < 0.4), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.3],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.6]
    ],
    'Film Score': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 32 === 16), 0.4],
        [(beatInMeasure) => (beatInMeasure % 64 === 0), 0.7]
    ],
    'Future Bass': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 11), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5]
    ],
    'Plunderphonics': [
        [(beatInMeasure) => (Math.random() < 0.5 && beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'Folktronica': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.4]
    ],
    'Indietronica': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4]
    ],
    'Synthwave': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Vaporwave': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.3]
    ],
    'Chillwave': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.4]
    ],
    'Darkwave': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'Coldwave': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8]
    ],
	'Eletro Funk': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 3 || beatInMeasure % 16 === 11), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Merengue': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 15), 0.5]
    ],
    'Bachata': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 13), 0.4]
    ],
    'Tango': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Mariachi': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8]
    ],
    'K-pop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'J-pop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'City Pop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Enka': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.7]
    ],
    'Rai': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 3), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5]
    ],
    'Qawwali': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.8]
    ],
    'Bhangra': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 14), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 3), 0.6]
    ],
    'Carnatic': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 32 === 16), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6]
    ],
    'Hindustani': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 64 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.4]
    ],
    'Gamelan': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0 || beatInMeasure % 16 === 10), 0.6],
        [(beatInMeasure) => (beatInMeasure % 32 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.7]
    ],
    'Flamenco': [
        [(beatInMeasure) => (beatInMeasure % 12 === 0 || beatInMeasure % 12 === 3 || beatInMeasure % 12 === 6 || beatInMeasure % 12 === 8 || beatInMeasure % 12 === 10), 0.8],
        [(beatInMeasure) => (beatInMeasure % 12 === 11), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5]
    ],
    'Fado': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.6]
    ],
    'Chanson': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.6]
    ],
    'Schlager': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Klezmer': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.4]
    ],
    'Celtic': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 2 || beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.7]
    ],
    'Polka': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6]
    ],
    'Valse': [
        [(beatInMeasure) => (beatInMeasure % 3 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 3 === 1), 0.4],
        [(beatInMeasure) => (beatInMeasure % 12 === 0), 0.8]
    ],
    'Opera': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 16), 0.3],
        [(beatInMeasure) => (beatInMeasure % 64 === 0), 0.7]
    ],
    'Baroque': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.4],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8]
    ],
    'Contemporary Classical': [
        [(beatInMeasure) => (Math.random() < 0.3 && beatInMeasure % 8 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.3]
    ],
    'Minimalism': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 32 === 16), 0.5]
    ],
    'Experimental': [
        [(beatInMeasure) => (Math.random() < 0.4 && beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 13 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 7), 0.4]
    ],
    'Noise': [
        [(beatInMeasure) => (Math.random() < 0.7), 0.4],
        [(beatInMeasure) => (Math.random() < 0.2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.3]
    ],
    'Drone': [
        [(beatInMeasure) => (beatInMeasure % 64 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 128 === 64), 0.4],
        [(beatInMeasure) => (beatInMeasure % 256 === 0), 0.8]
    ],
    'Dark Ambient': [
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 64 === 32), 0.3],
        [(beatInMeasure) => (beatInMeasure % 128 === 0), 0.6]
    ],
    'IDM': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 11 || beatInMeasure % 32 === 26), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
	'Glitch': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0 || beatInMeasure % 16 === 11 || beatInMeasure % 32 === 26), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 16 === 7), 0.7],
        [(beatInMeasure) => (Math.random() < 0.4), 0.6]
    ],
    'Breakcore': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 3 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 11), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 16 === 14), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 10 || beatInMeasure % 32 === 28), 0.7]
    ],
    'Hardstyle': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'Gabber': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.5]
    ],
    'Happy Hardcore': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'Eurodance': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.5]
    ],
    'Trance': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Psytrance': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 1 || beatInMeasure % 4 === 2 || beatInMeasure % 4 === 3), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Goa Trance': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 13 || beatInMeasure % 16 === 15), 0.6]
    ],
    'Progressive Trance': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Dream Trance': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.4]
    ],
    'Uplifting Trance': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Hardcore Techno': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 15), 0.5]
    ],
    'Acid Techno': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.6]
    ],
    'Dub Techno': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5]
    ],
    'Minimal Techno': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Detroit Techno': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Lounge': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Chillout': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.6]
    ],
    'Nu Jazz': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 3), 0.5]
    ],
    'Acid Jazz': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'Soul Jazz': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Smooth Jazz': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.7]
    ],
    'Jazz Fusion': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 7), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Hard Bop': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 3), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.4]
    ],
    'Bebop': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 5), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Cool Jazz': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.6]
    ],
    'Free Jazz': [
        [(beatInMeasure) => (Math.random() < 0.4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 7 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 13 === 0), 0.4]
    ],
    'Modal Jazz': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.5],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.7]
    ],
    'Post-bop': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 11), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Latin Jazz': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 12), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 3), 0.6]
    ],
    'Gypsy Jazz': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.8]
    ],
	'Swing': [
        [(beatInMeasure) => (beatInMeasure % 12 === 0 || beatInMeasure % 12 === 8), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 12 === 4), 0.5]
    ],
    'Big Band': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4 || beatInMeasure % 16 === 14), 0.8]
    ],
    'Ragtime': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 2 || beatInMeasure % 8 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 4), 0.5]
    ],
    'Dixieland': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.5]
    ],
    'Third Stream': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 32 === 16), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6]
    ],
    'Jazz-funk': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Acid Jazz (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'Nu Jazz (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Bossa Nova': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 14), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 3), 0.5]
    ],
    'Samba': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 14), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 2), 0.6]
    ],
    'AfrobeatInMeasure': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 4 || beatInMeasure % 16 === 10 || beatInMeasure % 16 === 14), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 7), 0.5]
    ],
    'Highlife': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 6), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Juju': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 12), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.5]
    ],
    'Mbalax': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 7 || beatInMeasure % 16 === 15), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.5]
    ],
    'Makossa': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 10), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Soukous': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 14), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 11), 0.5]
    ],
    'Kwaito': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'Desert Blues': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 10), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Ethio-jazz': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Gnoua': [
        [(beatInMeasure) => (beatInMeasure % 12 === 0 || beatInMeasure % 12 === 4 || beatInMeasure % 12 === 8), 0.8],
        [(beatInMeasure) => (beatInMeasure % 12 === 6), 0.6],
        [(beatInMeasure) => (beatInMeasure % 3 === 0), 0.5]
    ],
    'Zouk': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 14), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.5]
    ],
    'Kizomba': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 7 || beatInMeasure % 16 === 15), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.4]
    ],
    'Soca (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 10 || beatInMeasure % 16 === 14), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 2), 0.6]
    ],
    'Calypso (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 16 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Dancehall (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6 || beatInMeasure % 16 === 14), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 3), 0.6]
    ],
    'Dub (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.5],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.4]
    ],
    'Grime (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 11 || beatInMeasure % 32 === 26), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'Garage (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 10 || beatInMeasure % 16 === 15), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    '2-Step': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 10 || beatInMeasure % 16 === 15), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 6), 0.5]
    ],
    'Future Garage': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 10), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'UK Bass': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 11), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Wonky': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 7 || beatInMeasure % 16 === 13), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 15), 0.5]
    ],
	'Downtempo': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.4]
    ],
    'Trip Hop': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 8 === 3), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Illbient': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 11), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5],
        [(beatInMeasure) => (beatInMeasure % 32 === 28), 0.4]
    ],
    'Acid Hop': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 13), 0.5]
    ],
    'Glitch Hop': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0 || beatInMeasure % 16 === 11 || beatInMeasure % 32 === 26), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2 || beatInMeasure % 16 === 7), 0.6],
        [(beatInMeasure) => (Math.random() < 0.4), 0.5]
    ],
    'Nu-Metal': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'Funk Metal': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 3 || beatInMeasure % 16 === 11), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Industrial Rock': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'Industrial Metal': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.7]
    ],
    'Digital Hardcore': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 15), 0.7]
    ],
    'EBM': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6]
    ],
    'Aggrotech': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.7]
    ],
    'Futurepop': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Synth-Goth': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.8]
    ],
    'Dark Electro': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'Electro-Industrial': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.6]
    ],
    'Power Noise': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (Math.random() < 0.6), 0.7],
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.5]
    ],
    'Dark Ambient (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.3],
        [(beatInMeasure) => (beatInMeasure % 64 === 32), 0.2],
        [(beatInMeasure) => (beatInMeasure % 128 === 0), 0.5]
    ],
    'Ritual Ambient': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 8), 0.3],
        [(beatInMeasure) => (beatInMeasure % 64 === 0), 0.6]
    ],
    'Drone Doom': [
        [(beatInMeasure) => (beatInMeasure % 64 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 128 === 64), 0.4],
        [(beatInMeasure) => (beatInMeasure % 256 === 0), 0.7]
    ],
    'Stoner Doom': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.5]
    ],
    'Sludge Doom': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.7],
        [(beatInMeasure) => (beatInMeasure % 32 === 28), 0.6]
    ],
    'Funeral Doom': [
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 32 === 16), 0.5],
        [(beatInMeasure) => (beatInMeasure % 64 === 0), 0.8]
    ],
    'Blackened Death Metal': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.7]
    ],
    'Technical Death Metal': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 16 === 3 || beatInMeasure % 16 === 7 || beatInMeasure % 16 === 11), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 1.0]
    ],
    'Melodic Death Metal': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.7]
    ],
    'Symphonic Death Metal': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7]
    ],
    'Brutal Death Metal': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.7]
    ],
    'Deathgrind': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.9],
        [(beatInMeasure) => (beatInMeasure % 16 === 15), 0.8]
    ],
    'Goregrind': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8],
        [(beatInMeasure) => (Math.random() < 0.7), 0.6]
    ],
	'Porngrind': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 13), 0.7]
    ],
    'Noise Metal': [
        [(beatInMeasure) => (Math.random() < 0.7), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 1 === 0 && Math.random() < 0.3), 0.5]
    ],
    'Mathcore': [
        [(beatInMeasure) => (beatInMeasure % 7 === 0 || beatInMeasure % 13 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 11), 0.7]
    ],
    'Screamo (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'Emocore': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.5]
    ],
    'Post-Hardcore': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'Metalcore (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.7]
    ],
    'Deathcore (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 15), 0.7]
    ],
    'Nintendocore': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Electronicore': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'Synthcore': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.5]
    ],
    'Cybergrind': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 16 === 11), 0.8],
        [(beatInMeasure) => (Math.random() < 0.6), 0.7]
    ],
    'Hardcore Punk': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 1.0]
    ],
    'Crust Punk': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.6]
    ],
    'D-beatInMeasure': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0 || beatInMeasure % 8 === 3 || beatInMeasure % 8 === 6), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 0.6]
    ],
    'Powerviolence': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 16 === 7), 0.8],
        [(beatInMeasure) => (Math.random() < 0.5), 0.7]
    ],
    'Grindcore (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 1 === 0), 1.0],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 16 === 15), 0.9]
    ],
    'Thrashcore': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.9],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.8],
        [(beatInMeasure) => (beatInMeasure % 1 === 0 && Math.random() < 0.6), 0.7]
    ],
    'Crossover Thrash': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.9]
    ],
    'Skate Punk': [
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.7],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Pop Punk': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ],
    'Ska Punk': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 1 || beatInMeasure % 4 === 3), 0.8],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.6]
    ],
    'Reggae Rock': [
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.8],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 14), 0.4]
    ],
    'Dub Rock': [
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.7],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.6],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.5]
    ],
    'Post-Rock (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 8 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 8), 0.4],
        [(beatInMeasure) => (beatInMeasure % 32 === 0), 0.7]
    ],
    'Math Rock': [
        [(beatInMeasure) => (beatInMeasure % 5 === 0 || beatInMeasure % 11 === 0), 0.7],
        [(beatInMeasure) => (beatInMeasure % 4 === 2), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 13), 0.5]
    ],
    'Space Rock': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 12), 0.7]
    ],
    'Krautrock (2nd Var)': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.8],
        [(beatInMeasure) => (beatInMeasure % 2 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.7]
    ],
    'Art Rock': [
        [(beatInMeasure) => (beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.4]
    ],
    'Experimental Rock': [
        [(beatInMeasure) => (Math.random() < 0.4), 0.5],
        [(beatInMeasure) => (beatInMeasure % 7 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 0), 0.7]
    ],
    'Avant-Garde Rock': [
        [(beatInMeasure) => (beatInMeasure % 13 === 0), 0.5],
        [(beatInMeasure) => (beatInMeasure % 5 === 0), 0.4],
        [(beatInMeasure) => (Math.random() < 0.3), 0.6]
    ],
    'Plunderphonics': [
        [(beatInMeasure) => (Math.random() < 0.5 && beatInMeasure % 4 === 0), 0.6],
        [(beatInMeasure) => (beatInMeasure % 16 === 10), 0.4],
        [(beatInMeasure) => (beatInMeasure % 8 === 4), 0.5]
    ]

	
};


//orgineel  major: [0, 2, 4, 5, 7, 9, 11],   major: [0, 2, 4, 6, 8, 10],
const SCALE_SEMITONES = {
    major: [0, 2, 4, 5, 7, 9, 11],
    minor: [0, 2, 3, 5, 7, 8, 10],
    dorian: [0, 2, 3, 5, 7, 9, 10],
    phrygian: [0, 1, 3, 5, 7, 8, 10],
    pentatonic: [0, 2, 4, 7, 9, 11],
    chromatic: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
    harmonic_minor: [0, 2, 3, 5, 7, 8, 11],
    blues: [0, 3, 5, 6, 7, 10],
    lydian: [0, 2, 4, 6, 7, 9, 11],
    mixolydian: [0, 2, 4, 5, 7, 9, 10],
    locrian: [0, 1, 3, 5, 6, 8, 10],
    harmonicMinor: [0, 2, 3, 5, 7, 8, 11],
    melodicMinor: [0, 2, 3, 5, 7, 9, 11],
    wholeTone: [0, 2, 4, 6, 8, 10],
    melodic_minor: [0, 2, 3, 5, 7, 9, 11],   
    whole_tone: [0, 2, 4, 6, 8, 10],        
    diminished: [0, 2, 3, 5, 6, 8, 9, 11],   
    augmented: [0, 3, 4, 7, 8, 11],        
    enigmatic: [0, 1, 4, 6, 8, 10, 11],      
    double_harmonic: [0, 1, 4, 5, 7, 8, 11], 
    hirajoshi: [0, 2, 3, 7, 8],              
    in_sen: [0, 1, 5, 7, 10],                
    yo: [0, 2, 5, 7, 9],                    
    hungarian_minor: [0, 2, 3, 6, 7, 8, 11],  
    gypsy: [0, 2, 3, 6, 7, 8, 10],           
    neapolitan_minor: [0, 1, 3, 5, 7, 8, 11], 
    persian: [0, 1, 4, 5, 6, 8, 11],         
    arabic: [0, 1, 4, 5, 7, 8, 11],           
    byzantine: [0, 1, 4, 5, 7, 8, 11],      
    balinese: [0, 1, 3, 5, 7, 8],             
    pelog: [0, 1, 3, 5, 7, 8, 10],           
    iwato: [0, 1, 5, 6, 10],                 
    prometheus: [0, 2, 4, 6, 9, 10],         
    tritone: [0, 1, 4, 6, 7, 10] ,
hyper_exploitation: [0, 1, 2, 6, 7, 8, 11],
    maqam_bayati: [0, 1, 3, 5, 7, 8, 10], 
    maqam_rast: [0, 2, 4, 5, 7, 9, 11], 
    maqam_shur: [0, 1, 3, 5, 7, 8, 10],
    maqam_saba: [0, 1, 3, 4, 7, 8, 10],
    maqam_hijaz: [0, 1, 4, 5, 7, 8, 10],
    harmonic_minor: [0, 2, 3, 5, 7, 8, 11],
minorPentatonic: [0, 3, 5, 7, 10],
chromatic: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
wholeTone: [0, 2, 4, 6, 8, 10],
diminished: [0, 2, 3, 5, 6, 8, 9, 11] 
} 


var SCALE_SEMITONES_ = new Array();
var terfdfg=0;
SCALE_SEMITONES_[terfdfg]=     [0, 2, 4, 5, 7, 9, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]= [0, 2, 3, 5, 7, 8, 10];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 3, 5, 7, 9, 10];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 3, 5, 7, 8, 10];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 4, 7, 9];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 4, 5, 7, 9, 10];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 3, 5, 7, 8, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 3, 5, 6, 7, 10];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 4, 6, 7, 9, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 4, 5, 7, 9, 10];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 3, 5, 6, 8, 10];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 3, 5, 7, 8, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 3, 5, 7, 9, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 4, 6, 8, 10];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 3, 5, 7, 9, 11];   
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 4, 6, 8, 10];     
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 3, 5, 6, 8, 9, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 3, 4, 7, 8, 11];       
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 4, 6, 8, 10, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 4, 5, 7, 8, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 3, 7, 8];              
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 5, 7, 10];                
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 5, 7, 9];                   
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 3, 6, 7, 8, 11];
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 3, 6, 7, 8, 10];           
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 3, 5, 7, 8, 11]; 
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 4, 5, 6, 8, 11];         
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 4, 5, 7, 8, 11];           
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 4, 5, 7, 8, 11];      
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 3, 5, 7, 8];             
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 3, 5, 7, 8, 10];           
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 5, 6, 10];                 
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 2, 4, 6, 9, 10];         
terfdfg++;     SCALE_SEMITONES_[terfdfg]=[0, 1, 4, 6, 7, 10];  
