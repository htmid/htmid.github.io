		function invertImage(src, width, height) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "anonymous"; // optional

        img.onload = () => {
            const canvas = document.createElement("canvas");
            canvas.width = width;
            canvas.height = height;

            const ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0, width, height);

            const imgData = ctx.getImageData(0, 0, width, height);
            const data = imgData.data;

            for (let i = 0; i < data.length; i += 4) {
                data[i]     = 255 - data[i];     // R
                data[i + 1] = 255 - data[i + 1]; // G
                data[i + 2] = 255 - data[i + 2]; // B
                // alpha unchanged
            }

            ctx.putImageData(imgData, 0, 0);

            resolve(canvas);
        };

        img.onerror = reject;
        img.src = src;
    });
}

var canvas090 = document.createElement('canvas');
canvas090.setAttribute('id', 'canvas090' );
canvas090.style.display="none";

const ctx090 = canvas090.getContext('2d');

function drawctx090() {
    canvas090.width = window.innerWidth;
    canvas090.height = window.innerHeight;
    const w = canvas090.width;
    const h = canvas090.height;
    const horizon = h * 0.6;
    
    // --- 1. RANDOM THEME PARAMETERS ---
    const primaryHue = Math.random() * 360;
    const primary = `hsl(${primaryHue}, 90%, 60%)`;
    const secondary = `hsl(${(primaryHue + 160) % 360}, 100%, 70%)`;
    const isSunset = Math.random() > 0.5;

    // --- 2. ATMOSPHERIC BACKGROUND ---
    const sky = ctx090.createLinearGradient(0, 0, 0, horizon);
    sky.addColorStop(0, '#000408');
    sky.addColorStop(1, '#0a1a2f');
    ctx090.fillStyle = sky;
    ctx090.fillRect(0, 0, w, horizon);

    // Procedural Mountains (Hazy Twilight)
    ctx090.fillStyle = "#01080b";
    ctx090.beginPath();
    ctx090.moveTo(0, horizon);
    for(let i=0; i<=w; i+=30) {
        ctx090.lineTo(i, horizon - 20 - (Math.random() * 40));
    }
    ctx090.lineTo(w, horizon);
    ctx090.fill();

    ctx090.save();
	
	
	
    ctx090.translate(w/2, horizon - 80);
    
    const iconSize = h * (0.15 + Math.random() * 0.2); // Random symbol size
    const shapeType = Math.floor(Math.random() * 4); // 0=Square, 1=Circle, 2=Hex, 3=Nested
    const symbolHue = Math.random() * 360;
    const shadowColor = `hsl(${symbolHue}, 100%, 50%)`;

    // A. Multi-Layer Diffusion Glow
    for(let i=10; i>5; i--) {
        ctx090.fillStyle = `hsla(${symbolHue}, 100%, 70%, ${0.08 / i})`;
        ctx090.beginPath();
        const r = iconSize * (1 + (i*0.1));
        if(shapeType === 0) ctx090.rect(-r,-r,r*2,r*2); // Square glow
        else ctx090.arc(0, 0, r, 0, Math.PI*2); // Circle glow
        ctx090.fill();
    }

    // B. Geometric Bounding Shape
    ctx090.lineWidth = 3 + Math.random()*3;
    ctx090.strokeStyle = "#fff";
    ctx090.shadowBlur = 30; ctx090.shadowColor = shadowColor;
    
    ctx090.beginPath();
    if(shapeType === 0) { // Symmetrical Squares
        ctx090.strokeRect(-iconSize, -iconSize, iconSize*2, iconSize*2);
        ctx090.strokeRect(-iconSize*0.8, -iconSize*0.8, iconSize*1.6, iconSize*1.6);
    } else if(shapeType === 1) { // Circles
        ctx090.arc(0, 0, iconSize, 0, Math.PI*2); ctx090.stroke();
        ctx090.beginPath(); ctx090.arc(0, 0, iconSize*0.8, 0, Math.PI*2); ctx090.stroke();
    } else { // Hexagons/Octagons
        const sides = shapeType === 2 ? 6 : 8;
        const angle = (Math.PI * 2) / sides;
        for(let i=0; i<=sides; i++) {
            const px = Math.cos(angle * i) * iconSize;
            const py = Math.sin(angle * i) * iconSize;
            if(i===0) ctx090.moveTo(px,py); else ctx090.lineTo(px,py);
        }
        ctx090.stroke();
    }


    // --- 5. DAWN / HORIZON SHINE ---
    const sun = ctx090.createRadialGradient(w/2, horizon, 0, w/2, horizon, w*0.4);
    sun.addColorStop(0, "rgba(255, 255, 255, 0.7)");
    sun.addColorStop(1, "transparent");
    ctx090.fillStyle = sun;
    ctx090.fillRect(-Math.round(w/2), -Math.round(h/2), w, h);
							  
							  	var fd=new Image();

							  fd.src='';
							
		//	invertImage(fd, canvas090.width, canvas090.height);
							  
				//	ctx090.drawImage(fd,-Math.round(canvas090.width/2) ,-Math.round(canvas090.height/2) , canvas090.width, canvas090.height);	
							  
    ctx090.shadowBlur = 0;

    // C. The Musical Symbol
	const symbols=[ "𝄞", "♫", "🎶", "🎼",      "𝅘𝅥𝅮 ", "𝅘𝅥𝅯 ", "𝅘𝅥𝅰 " ];
    const symbolSize = iconSize * (1.2 + Math.random() * 0.4);
    
    ctx090.fillStyle = "#fff";
    ctx090.shadowBlur = 40; ctx090.shadowColor = "#fff";
    ctx090.font = `${symbolSize}px serif`;
    ctx090.textAlign = "center"; ctx090.textBaseline = "middle";
    ctx090.fillText(symbols[Math.floor(Math.random()*symbols.length)], 0, 0);
    ctx090.restore();
    // --- 6. DATA RAIN (Floating Notes) ---
    ctx090.fillStyle = "#fff"; ctx090.font = "10px monospace";
    for(let i=0; i<50; i++) {
        ctx090.globalAlpha = Math.random() * 0.4;
        ctx090.fillText(Math.random() > 0.5 ? "♫" : "♩", Math.random()*w, Math.random()*h);
    }
 // --- 3. THE MASTER PROCESSING UNIT ---
    const coreX = w / 2;
    const coreY = horizon + (h - horizon) / 2;
    const coreSize = 140;
    const coreHue = Math.random() * 360;

    // Solid Housing
    ctx090.fillStyle = "#040404";
    ctx090.shadowBlur = 25; ctx090.shadowColor = `hsl(${coreHue}, 100%, 30%)`;
   // ctx090.fillRect(coreX - coreSize/2, coreY - coreSize/2, coreSize, coreSize);
    ctx090.shadowBlur = 0;

    // Gold/Neon Bezel
    ctx090.lineWidth = 2;
    ctx090.strokeStyle = `hsl(${coreHue}, 660%, 50%)`;
       ctx090.fillStyle = `hsl(${coreHue}, 33%, 25%)`;
     ctx090.fillRect(coreX - coreSize/2 + 5, coreY - coreSize/2 + 5, coreSize - 10, coreSize - 10);
    ctx090.strokeRect(coreX - coreSize/2 + 5, coreY - coreSize/2 + 5, coreSize - 10, coreSize - 10);

    // Center Branding
    const icons = ['▶', '♫', '𝄞', '𝄢'];
    ctx090.fillStyle = "#1a1a1a"; 
    ctx090.font = "bold 12px serif";
    ctx090.textAlign = "center"; ctx090.textBaseline = "middle";
   // ctx090.fillText(icons[Math.floor(Math.random()*icons.length)], coreX, coreY);
    
    //ctx090.font = "8px monospace";
    ctx090.fillStyle = `hsl(${coreHue}, 50%, 80%)`;
    ctx090.fillText(("CORE"+icons[Math.floor(Math.random()*icons.length)]), coreX, coreY + (coreSize/2 - 15));

    // --- 4. DATA BUS ROUTING ---
    function drawTrace(startX, startY, lines, type) {
        const spacing = 4;
        const startHue = Math.random() * 360;

        for (let l = 0; l < lines; l++) {
            const ly = startY + (l * spacing);
            const targetSide = (startX < coreX) ? coreX - coreSize/2 : coreX + coreSize/2;
            const targetY = (coreY - coreSize/2 + 15) + (Math.random() * (coreSize - 30));

            // Color Gradient: Start (Dark) to End (Glow)
            const grad = ctx090.createLinearGradient(startX, ly, targetSide, targetY);
            grad.addColorStop(0, `hsl(${startHue}, 60%, 30%)`);
            grad.addColorStop(1, `hsl(${(startHue+40)%360}, 80%, 50%)`);

            ctx090.beginPath();
            ctx090.strokeStyle = grad;
            ctx090.lineWidth = 1.1;
            ctx090.moveTo(startX, ly);

            // Manhattan 90-degree logic
            const midX = startX + (targetSide - startX) * (0.1 + Math.random() * 0.7);
            ctx090.lineTo(midX, ly);
            ctx090.lineTo(midX, targetY);
            ctx090.lineTo(targetSide, targetY);
            ctx090.stroke();

            // Solder Pad anchor
            ctx090.fillStyle = "#1a1100";
            ctx090.beginPath(); ctx090.arc(startX, ly, 1.2, 0, Math.PI*2); ctx090.fill();
        }
    }

    // Generate Peripheral Nodes
    for (let i = 0; i < 16; i++) {
        const isLeft = Math.random() > 0.5;
        const compX = isLeft ? Math.random() * (coreX - 250) : coreX + 250 + Math.random() * (w - coreX - 300);
        const compY = horizon + 40 + Math.random() * (h - horizon - 100);
        
        // Component Body
        ctx090.fillStyle = "#070707";
        ctx090.fillRect(compX, compY, 24, 12);
        
        // Technical Labeling (Small ID Tags)
        ctx090.fillStyle = "#1a2222";
        ctx090.font = "6px monospace";
        const label = (Math.random() > 0.5 ? "R" : "C") + Math.floor(Math.random()*999);
        ctx090.fillText(label, compX, compY - 4);
        
        const busStartX = isLeft ? compX + 24 : compX;
        drawTrace(busStartX, compY + 2, 3 + Math.floor(Math.random() * 5));
    }

    // --- 5. ATMOSPHERIC DETAILS ---
    ctx090.globalAlpha = 0.1;
    ctx090.fillStyle = "#444";
    for(let i=0; i<35; i++) {
        ctx090.font = "10px serif";
        ctx090.fillText(Math.random() > 0.5 ? "♫" : "♩", Math.random()*w, Math.random()*horizon);
    }
				
			
	
	return canvas090.toDataURL();
}
