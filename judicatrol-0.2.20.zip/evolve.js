

let tickCounter = 0;

    // Helper: Telt buren in een Moore Neighborhood (8 buren) met Torus (wrapping)
    const countMoore = (grid, x, y, width, height) => {
        let count = 0;
        for (let i = -1; i <= 1; i++) {
            for (let j = -1; j <= 1; j++) {
                if (i === 0 && j === 0) continue;
                if (grid[(y + i + height) % height][(x + j + width) % width]) count++;
            }
        }
        return count;
    };

    // Helper: Telt buren in een Von Neumann Neighborhood (4 buren: N, S, E, W)
    const countVonNeumann = (grid, x, y, width, height) => {
        let count = 0;
        if (grid[(y - 1 + height) % height][x]) count++;
        if (grid[(y + 1) % height][x]) count++;
        if (grid[y][(x - 1 + width) % width]) count++;
        if (grid[y][(x + 1) % width]) count++;
        return count;
    };

    // 0: Critters (Margolus Neighborhood)
    const doCritters = (grid, w, h) => {
		
        let next = Array.from({ length: h }, () => new Array(w));
        const offset = tickCounter % 2;
        for (let y = 0; y < h; y += 2) {
            for (let x = 0; x < w; x += 2) {
                const get = (dx, dy) => grid[(y + dy + offset) % h][(x + dx + offset) % w] ? 1 : 0;
                const set = (dx, dy, val) => next[(y + dy + offset) % h][(x + dx + offset) % w] = !!val;
                
                let n = get(0,0) + get(1,0) + get(0,1) + get(1,1);
                if (n === 0 || n === 1 || n === 4) {
                    set(0,0, get(1,1)); set(1,0, get(0,1)); set(0,1, get(1,0)); set(1,1, get(0,0));
                } else if (n === 2) {
                    set(0,0, get(0,0)); set(1,0, get(1,0)); set(0,1, get(0,1)); set(1,1, get(1,1));
                } else { // n === 3
                    set(0,0, !get(1,1)); set(1,0, !get(0,1)); set(0,1, !get(1,0)); set(1,1, !get(0,0));
                }
            }
        }
        return next;
    };

    // 1: Seeds (B2/S)
    const doSeeds = (grid, w, h) => {
        return grid.map((row, y) => row.map((state, x) => {
            const n = countMoore(grid, x, y, w, h);
            return !state && n === 2;
        }));
    };

    // 2: Replicator (B1357/S1357)
    const doReplicator = (grid, w, h) => {
        return grid.map((row, y) => row.map((state, x) => {
            const n = countMoore(grid, x, y, w, h);
            return (n % 2 !== 0);
        }));
    };

    // 3: Fredkin (Parity Rule)
    const doFredkin = (grid, w, h) => {
        return grid.map((row, y) => row.map((state, x) => {
            const n = countVonNeumann(grid, x, y, w, h);
            return (n % 2 !== 0);
        }));
    };

    // 4: Day & Night (B3678/S34678)
    const doDayNight = (grid, w, h) => {
        return grid.map((row, y) => row.map((state, x) => {
            const n = countMoore(grid, x, y, w, h);
            if (state) return (n === 3 || n === 4 || n === 6 || n === 7 || n === 8);
            return (n === 3 || n === 6 || n === 7 || n === 8);
        }));
    };
	
	// 5: Brian's Brain (Behoeft eigenlijk een extra state, maar hier gesimuleerd als flits)
const doBriansBrain = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return !state && n === 2; // Alleen dode cellen met exact 2 buren worden levend
    }));
};

// 6: HighLife (B36/S23) - Bekend om zijn 'replicator' pattern
const doHighLife = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n === 2 || n === 3) : (n === 3 || n === 6);
    }));
};

// 7: Glitch Parity (Von Neumann met een 'error' marge)
const doGlitchParity = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countVonNeumann(grid, x, y, w, h);
        return (n % 2 !== 0) || (n === 4 && Math.random() > 0.95);
    }));
};

// 8: Serviettes (B234/S) - CreÃ«ert kant-achtige structuren die snel verdwijnen
const doServiettes = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return !state && (n >= 2 && n <= 4);
    }));
};

// 9: Walled Cities (B45678/S2345) - CreÃ«ert stabiele 'eilanden'
const doWalledCities = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n >= 2 && n <= 5) : (n >= 4 && n <= 8);
    }));
};

// 10: Diffusion-Limited Glitch (Reageert op positie in het grid)
const doStochastic = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        const threshold = (x / w) * 4; // Links is stabieler dan rechts
        return n > threshold && n < 6;
    }));
};

// 11: Amoeba (B357/S1358) - Organische, pulserende vormen
const doAmoeba = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n===1 || n===3 || n===5 || n===8) : (n===3 || n===5 || n===7);
    }));
};

// 12: Maze (B3/S12345) - Groeit uit tot een perfect doolhof
const doMaze = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n >= 1 && n <= 5) : (n === 3);
    }));
};

// 13: 2x2 (B36/S125) - CreÃ«ert vreemde blokkerige patronen
const doTwoByTwo = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n === 1 || n === 2 || n === 5) : (n === 3 || n === 6);
    }));
};

// 14: Assimilation (B345/S4567) - Zeer stabiele, bijna kristalachtige groei
const doAssimilation = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n >= 4 && n <= 7) : (n >= 3 && n <= 5);
    }));
};

// 15: Coagulations (B378/S235678) - Bubbel-achtige structuren
const doCoagulations = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        if (state) return [2,3,5,6,7,8].includes(n);
        return [3,7,8].includes(n);
    }));
};

// 16: Dancy (B2/S23) - Een hyperactieve versie van Game of Life
const doDancy = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n === 2 || n === 3) : (n === 2);
    }));
};

// 17: Long Life (B345/S5) - Patronen die extreem langzaam veranderen
const doLongLife = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n === 5) : (n === 3 || n === 4 || n === 5);
    }));
};

// 18: Move (B368/S245) - Bekend om "slak-achtige" bewegende objecten
const doMove = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n === 2 || n === 4 || n === 5) : (n === 3 || n === 6 || n === 8);
    }));
};

// 19: Inverse Life (Inverteert de logica elke 100 ticks)
const doInverseLife = (grid, w, h) => {
    const invert = (tickCounter % 200 > 100);
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        let alive = state ? (n === 2 || n === 3) : (n === 3);
        return invert ? !alive : alive;
    }));
};

// 20: Stains (B3678/S235678) - Vult gaten op als een vloeistof
const doStains = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? [2,3,5,6,7,8].includes(n) : [3,6,7,8].includes(n);
    }));
};

// 21: Coral (B3/S45678) - Groeit als koraalriffen
const doCoral = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return state ? (n >= 4 && n <= 8) : (n === 3);
    }));
};

// 22: Majority (B5678/S45678) - Cellen proberen te doen wat hun buren doen
const doMajority = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        return n >= 5; // Simpele democratie
    }));
};

// 23: Diagonal Decay (Alleen groei op diagonalen)
const doDiagonal = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countVonNeumann(grid, x, y, w, h);
        const diag = grid[(y-1+h)%h][(x-1+w)%w] || grid[(y+1)%h][(x+1)%w];
        return state ? (n > 0) : (diag && n === 1);
    }));
};

// 24: Chaos Star (Random rule switching per pixel)
const doChaosStar = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        // Combineert Fredkin parity met Life-regels op basis van toeval
        if (Math.random() > 0.7) return (n % 2 !== 0);
        return state ? (n === 2 || n === 3) : (n === 3);
    }));
};
	
	// 25: Neural Ripple (Gebruikt een gewogen som van de buurt)
const doNeuralRipple = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const nMoore = countMoore(grid, x, y, w, h);
        const nVon = countVonNeumann(grid, x, y, w, h);
        // Neurale activatie: Moore minus Von Neumann (rand-detectie)
        const activation = (nMoore * 0.5) - (nVon * 0.2);
        return activation > 0.8 && activation < 2.5;
    }));
};

// 26: Synaptic Fire (Simuleert drempelwaarde-vuren)
const doSynapticFire = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        const excitation = state ? 0.4 : 0.0;
        return (n * 0.35 + excitation) > 1.1 && (n * 0.35 + excitation) < 3.2;
    }));
};

// 27: Gray-Scott Lite (Simuleert reactie-diffusie patronen)
const doGrayScottLite = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        // Een mix van overleving bij lage dichtheid en afsterven bij overbevolking
        if (state) return n >= 2 && n <= 4;
        return n === 3; // 'Inhibitor' logica
    }));
};

// 28: Neural Glider (Asymmetrische neurale activatie)
const doNeuralGlider = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        const bias = (x + y + tickCounter) % 2 === 0 ? 0.1 : -0.1;
        return (n * 0.4 + bias) > 1.2 && (n * 0.4 + bias) < 2.8;
    }));
};

// 29: Dendrite Growth (Groeit als zenuwvertakkingen)
const doDendrite = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        if (state) return n < 4; // Sterft af bij te veel contact (inhibitie)
        return n === 1; // Groeit alleen aan de uiteinden
    }));
};

// 30: Brain Waves (Pulserende patronen door tijds-oscillatie)
const doBrainWaves = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        const wave = Math.sin(tickCounter * 0.2) * 2;
        return n > (3 + wave) && n < (6 + wave);
    }));
};

// 31: Cortex (CreÃ«ert rimpelige, hersenpan-achtige structuren)
const doCortex = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        const v = countVonNeumann(grid, x, y, w, h);
        return (n === 3 || n === 7) || (state && v === 2);
    }));
};

// 32: Neuromorphic (Zelf-organiserende clusters)
const doNeuromorphic = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        // Sigmoid-achtige activatie drempel
        const sum = 1 / (1 + Math.exp(-(n - 3.5)));
        return sum > 0.5 && n < 7;
    }));
};

// 33: Perception (Reageert op patronen in plaats van aantal buren)
const doPerception = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        const horizontal = grid[y][(x-1+w)%w] && grid[y][(x+1)%w];
        const vertical = grid[(y-1+h)%h][x] && grid[(y+1)%h][x];
        return (horizontal || vertical) ? n < 4 : n === 3;
    }));
};

// 34: Bio-Electric (Kriskras ontladingen)
const doBioElectric = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countVonNeumann(grid, x, y, w, h);
        if (state) return n >= 1 && n <= 2;
        return n === 1 && Math.random() > 0.8; // Willekeurige 'vuring'
    }));
};

// 35: Quantum Superposition (Probabilistic collapse)
const doQuantum = (grid, w, h) => {
    return grid.map((row, y) => row.map((state, x) => {
        const n = countMoore(grid, x, y, w, h);
        const phase = (x * 0.1 + y * 0.1 + tickCounter * 0.05) % (Math.PI * 2);
        const probability = (Math.sin(phase) + 1) / 2;
        const collapsed = Math.random() < probability;
        
        if (collapsed) return state ? (n === 2 || n === 3) : (n === 3);
        return state ? (n !== 2 && n !== 3) : (n !== 3);
    }));
};	
	
    /**
     * De centrale evolutie functie
     * @param {number} index - 0 t/m 4 (Keuze van algoritme)
     * @param {boolean[][]} rows - De huidige 2D array
     * @returns {boolean[][]} De nieuwe 2D array
     */
    function evolve(index, rows){
        if (!rows || rows.length === 0) return rows;
        const h = rows.length;
        const w = rows[0].length;
        let result;
	let indexe=index+0;
        switch (index) {
			
        // --- BASIS SET (Klassiekers) ---
        case 0:  result = doCritters(rows, w, h); break;
        case 1:  result = doSeeds(rows, w, h); break;
        case 2:  result = doReplicator(rows, w, h); break;
        case 3:  result = doFredkin(rows, w, h); break;
        case 4:  result = doDayNight(rows, w, h); break;
        case 5:  result = doBriansBrain(rows, w, h); break;
        case 6:  result = doHighLife(rows, w, h); break;
        case 7:  result = doGlitchParity(rows, w, h); break;
        case 8:  result = doServiettes(rows, w, h); break;
	    case 9:  result = doWalledCities(rows, w, h); break;
        case 10: result = doStochastic(rows, w, h); break;
        case 11: result = doAmoeba(rows, w, h); break;
		case 12: result = doMaze(rows, w, h); break;
        case 13: result = doTwoByTwo(rows, w, h); break;
        case 14: result = doAssimilation(rows, w, h); break;
        case 15: result = doCoagulations(rows, w, h); break;
		case 16: result = doDancy(rows, w, h); break;
		case 17: result = doLongLife(rows, w, h); break;
        case 18: result = doMove(rows, w, h); break;
		case 19: result = doPerception(rows, w, h); break;        
		case 20: result = doStains(rows, w, h); break;
        case 21: result = doCoral(rows, w, h); break;
        case 22: result = doBioElectric(rows, w, h); break;       
        case 23: result = doDiagonal(rows, w, h); break;
        case 24: result = doChaosStar(rows, w, h); break;
		case 25: result = doNeuralRipple(rows, w, h); break;
        case 26: result = doNeuromorphic(rows, w, h); break;
		case 27: result = doGrayScottLite(rows, w, h); break;
        case 28: result = doNeuralGlider(rows, w, h); break;
        case 29: result = doDendrite(rows, w, h); break;
        case 30: result = doBrainWaves(rows, w, h); break;
        case 31: result = doCortex(rows, w, h); break;
		case 32: result = doQuantum(rows, w, h); break;
        
        default: result = rows;
        }



 	switch (indexe) {
	        // --- BASIS SET (Klassiekers) ---
        case 0:  resultll = "Critters"; break;
        case 1:  resultll = "Seeds";  break;
        case 2:  resultll = "Replicator"; break;
        case 3:  resultll = "Fredkin"; break;
        case 4:  resultll = "Day Night"; break;
        case 5:  resultll = "Brians Brain"; break;
        case 6:  resultll = "High Life"; break;
        case 7:  resultll = "Glitch Parity"; break;
        case 8:  resultll = "Serviettes"; break;
	case 9:  resultll = "Walled Cities"; break;
        case 10: resultll = "Stochastic"; break;
        case 11: resultll = "Amoeba"; break;
	case 12: resultll = "Maze"; break;
        case 13: resultll = "Two By Two"; break;
        case 14: resultll = "Assimilation"; break;
        case 15: resultll = "Coagulations"; break;
	case 16: resultll = "Dancy"; break;
	case 17: resultll = "Long Life"; break;
        case 18: resultll = "Move"; break;
	case 19: resultll = "Perception"; break;        
	case 20: resultll = "Stains"; break;
        case 21: resultll = "Coral"; break;
        case 22: resultll = "Bio Electric"; break;       
        case 23: resultll = "Diagonal"; break;
        case 24: resultll = "Chaos Star"; break;
	case 25: resultll = "Neural Ripple"; break;
        case 26: resultll = "Neuro Morphic"; break;
	case 27: resultll = "Gray Scott Lite"; break;
        case 28: resultll = "Neural Glider"; break;
        case 29: resultll = "Dendrite"; break;
        case 30: resultll = "Brain Waves"; break;
        case 31: resultll = "Cortex"; break;
	case 32: resultll = "Quantum"; break;
        default: resultll = "Rows";
	}

        
        return result;
    }

	

function evolveGeneralizedCA(rule, width, height, cyclic, radial, rng_, seedRowStrategy, r_) {
    // 1. Setup the rows container
    const rows = new Array(height);
    let row = new Array(width);

    // Use the passed rng_ (wielsieder) if available, else Math.random

    // 2. Initial Seed Row Strategy
    // bwbbb is the threshold for the initial random state
    const bwbbb =  randomFunc();

    for (let i = 0; i < width; i++) {
        // Initialize with 1 (active) or 0 (inactive)
        row[i] = randomFunc() < bwbbb ? 1 : 0;
    }
    rows[0] = row.slice();

    // 3. Rule Bit Pre-calculation
    const neighborhoodCount = Math.pow(2, 2 * radial + 1);
    let currentRule = r_; // Keep track of the actual rule number for mutation
    let ruleBits = new Array(neighborhoodCount);
    
    // Helper to refresh the lookup table when the rule mutates
    const updateRuleBits = (r) => {
        for (let mask = 0; mask < neighborhoodCount; mask++) {
            ruleBits[mask] = (r >> mask) & 1;
        }
    };
    updateRuleBits(currentRule);

    // 4. Evolution Loop
    for (let h = 1; h < height; h++) {
        
        // FINDING 2: Rule Mutation
        // Every 16 rows, there is a 15% chance to flip one bit of the rule.
        // This ensures the "DNA" of the music evolves and doesn't get stuck in a loop.
        if (h % 16 === 0 && randomFunc() < 0.15 && false) {
            const bitToFlip = Math.floor(randomFunc() * 8);
            currentRule = currentRule ^ (1 << bitToFlip);
            updateRuleBits(currentRule);
            // console.log(`Mutation at row ${h}: New Rule ${currentRule}`);
        }

        const next = new Array(width);
        for (let x = 0; x < width; x++) {
            let neighborhoodIndex = 0;

            for (let j = -radial; j <= radial; j++) {
                let cellState;

                if (cyclic) {
                    const neighborIndex = (x + j + width) % width;
                    cellState = row[neighborIndex];
                } else {
                    const neighborIndex = x + j;
                    if (neighborIndex < 0 || neighborIndex >= width) {
                        cellState = 0;
                    } else {
                        cellState = row[neighborIndex];
                    }
                }

                // Map neighborhood to a bit position index (e.g., 4, 2, 1)
                const bitPos = radial - j;

                // Check for 1 or true (supporting both numeric and boolean states)
                if (cellState === 1 || cellState === true) {
                    neighborhoodIndex += Math.pow(2, bitPos);
                }
            }

            // Determine the next cell state using the (potentially mutated) ruleBits
            next[x] = ruleBits[neighborhoodIndex];
        }
        
        rows[h] = next;
        row = next; // Update current row reference for the next vertical step
    }

    return rows;
}

