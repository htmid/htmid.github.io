

// Robust Base64 encoder for Worklet code
function toBase64(str) {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for(let i=0; i<bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}


	
	
	
	
	
	
	
	
		
/* ==========================================================================
   SF2 PARSER
   ========================================================================== */
class SF2Parser {
  constructor(buffer) {
    this.view = new DataView(buffer);
    this.pos = 0;
  }

  readStr(len) {
    let s = '';
    for(let i=0; i<len; i++) {
      const c = this.view.getUint8(this.pos + i);
      if(c !== 0) s += String.fromCharCode(c);
    }
    return s;
  }
  
  // Add this to your SF2Parser class
parseSamples() {
    // Navigate to the 'shdr' (Sample Header) chunk
    // Each header is 46 bytes. The sample rate is at offset 24 (4-byte Uint32)
    const sampleHeaders = [];
    for (let i = 0; i < numSamples; i++) {
        const offset = shdrOffset + (i * 46);
        sampleHeaders.push({
            name: this.readStr(20),
            start: this.view.getUint32(offset + 20, true),
            end: this.view.getUint32(offset + 24, true),
            sampleRate: this.view.getUint32(offset + 32, true), // Extract actual rate
            originalPitch: this.view.getUint8(offset + 40),
            pitchCorrection: this.view.getInt8(offset + 41)
        });
    }
    return sampleHeaders;
}

  parse() {
    // Basic RIFF check
    if (this.readStr(4) !== 'RIFF') throw new Error("Not a RIFF file");
    this.pos += 4; // size
    this.pos += 4; // skip
    if (this.readStr(4) !== 'sfbk') throw new Error("Not a SoundFont file");
    this.pos += 4;

    // Find chunks
    let pdtaInfo = null, sdtaInfo = null;
    let p = 12;
    while(p < this.view.byteLength - 8) {
      const id = String.fromCharCode(
        this.view.getUint8(p), this.view.getUint8(p+1),
        this.view.getUint8(p+2), this.view.getUint8(p+3)
      );
      const size = this.view.getUint32(p+4, true);

      if(id === 'LIST') {
        const type = String.fromCharCode(
          this.view.getUint8(p+8), this.view.getUint8(p+9),
          this.view.getUint8(p+10), this.view.getUint8(p+11)
        );
        if(type === 'pdta') pdtaInfo = { offset: p+12, size: size-4 };
        if(type === 'sdta') sdtaInfo = { offset: p+12, size: size-4 };
      }
      p += 8 + size + (size % 2);
    }

    if(!pdtaInfo || !sdtaInfo) throw new Error("Corrupt SF2: missing pdta/sdta");

    // Load Samples (SDTA)
    const pcm = new Int16Array(this.view.buffer, sdtaInfo.offset + 8, (sdtaInfo.size-8)/2);

    // Load Headers (PDTA)
    const pdta = this.parsePdta(pdtaInfo.offset, pdtaInfo.size);

    return { pcm, pdta };
  }

  parsePdta(offset, size) {
    let p = offset, end = offset + size;
    const data = { phdr:[], pbag:[], pgen:[], inst:[], ibag:[], igen:[], shdr:[] };

    while(p < end) {
      const id = String.fromCharCode(
        this.view.getUint8(p), this.view.getUint8(p+1),
        this.view.getUint8(p+2), this.view.getUint8(p+3)
      );
      const chSize = this.view.getUint32(p+4, true);
      const base = p + 8;

      if(id === 'phdr') {
        for(let i=0; i<chSize; i+=38) {
          data.phdr.push({
            preset: this.view.getUint16(base+i+20, true),
            bank: this.view.getUint16(base+i+22, true),
            pbagIdx: this.view.getUint16(base+i+24, true)
          });
        }
      } else if(id === 'pbag') {
        for(let i=0; i<chSize; i+=4) data.pbag.push({ genIdx: this.view.getUint16(base+i, true) });
      } else if(id === 'pgen') {
        for(let i=0; i<chSize; i+=4) data.pgen.push({ op: this.view.getUint16(base+i, true), val: this.view.getInt16(base+i+2, true) });
      } else if(id === 'inst') {
        for(let i=0; i<chSize; i+=22) data.inst.push({ ibagIdx: this.view.getUint16(base+i+20, true) });
      } else if(id === 'ibag') {
        for(let i=0; i<chSize; i+=4) data.ibag.push({ genIdx: this.view.getUint16(base+i, true) });
      } else if(id === 'igen') {
        for(let i=0; i<chSize; i+=4) data.igen.push({ op: this.view.getUint16(base+i, true), val: this.view.getInt16(base+i+2, true) });
      } else if(id === 'shdr') {
        for(let i=0; i<chSize; i+=46) {
          data.shdr.push({
            start: this.view.getUint32(base+i+20, true),
            end: this.view.getUint32(base+i+24, true),
            startLoop: this.view.getUint32(base+i+28, true),
            endLoop: this.view.getUint32(base+i+32, true),
            rate: this.view.getUint32(base+i+36, true),
            pitch: this.view.getUint8(base+i+40),
            corr: this.view.getInt8(base+i+41),
            type: this.view.getUint16(base+i+44, true)
          });
        }
      }
      p += 8 + chSize + (chSize%2);
    }
    return data;
  }
}


function buildRegions(sf2) {
  const regions = [];
  const d = sf2.pdta;

  // Generators IDs
  const G = { 
    keyRange:43, velRange:44, inst:41, sample:53, 
    root:58, coarse:51, fine:52, mode:54, 
    att:34, dec:36, sus:37, rel:38,
    overridingRootKey: 58 // Belangrijk voor drums!
  };
  const def = { att:-12000, dec:-12000, sus:0, rel:-12000 };

  const getGens = (bag, genList, idx, nextIdx) => {
    const res = {};
    const start = bag[idx].genIdx;
    const end = (nextIdx !== undefined) ? bag[nextIdx].genIdx : genList.length;
    for(let i=start; i<end; i++) res[genList[i].op] = genList[i].val;
    return res;
  }

  for(let i=0; i<d.phdr.length-1; i++) {
    const p = d.phdr[i];
    const pbagEnd = d.phdr[i+1].pbagIdx;

    let pGlobal = {};
    let pbIdx = p.pbagIdx;
    if(pbIdx < pbagEnd) {
      const g = getGens(d.pbag, d.pgen, pbIdx, pbIdx+1);
      if(g[G.inst] === undefined) { pGlobal = g; pbIdx++; }
    }

    for(; pbIdx < pbagEnd; pbIdx++) {
      const pLoc = getGens(d.pbag, d.pgen, pbIdx, pbIdx+1);
      const pComb = { ...pGlobal, ...pLoc };

      if(pComb[G.inst] === undefined) continue;
      const instIdx = pComb[G.inst];
      const inst = d.inst[instIdx];
      const ibagEnd = (d.inst[instIdx+1]) ? d.inst[instIdx+1].ibagIdx : d.ibag.length;

      let iGlobal = {};
      let ibIdx = inst.ibagIdx;
      if(ibIdx < ibagEnd) {
        const g = getGens(d.ibag, d.igen, ibIdx, ibIdx+1);
        if(g[G.sample] === undefined) { iGlobal = g; ibIdx++; }
      }

      for(; ibIdx < ibagEnd; ibIdx++) {
        const iLoc = getGens(d.ibag, d.igen, ibIdx, ibIdx+1);
        const all = { ...iGlobal, ...iLoc };

        if(all[G.sample] === undefined) continue;
        const sh = d.shdr[all[G.sample]];

        const getV = (k, df) => (all[k] !== undefined ? all[k] : (pComb[k] !== undefined ? pComb[k] : df));
        const range = (v) => v===undefined ? [0,127] : [v&0xFF, (v>>8)&0xFF];

        const pk = range(pComb[G.keyRange]), ik = range(all[G.keyRange]);
        const kMin = Math.max(pk[0], ik[0]), kMax = Math.min(pk[1], ik[1]);
        if(kMin > kMax) continue;

        const pv = range(pComb[G.velRange]), iv = range(all[G.velRange]);
        const vMin = Math.max(pv[0], iv[0]), vMax = Math.min(pv[1], iv[1]);
        if(vMin > vMax) continue;

        // --- DE CRUCIALE FIXES VOOR ROLAND/WINDOWS ---

        // 1. Root Key: SF2 spec zegt dat generator 58 de sh.pitch overschrijft
        let root = sh.pitch;
        if (all[G.overridingRootKey] !== undefined) root = all[G.overridingRootKey];
        else if (pComb[G.overridingRootKey] !== undefined) root = pComb[G.overridingRootKey];

        // 2. Fine Tune & Coarse Tune: Moeten bij elkaar opgeteld worden (Cents)
        // Tune = (sh.corr) + (Instrument Fine) + (Instrument Coarse * 100)
        const totalFineTune = (all[G.fine] || 0) + (all[G.coarse] || 0) * 100 + (sh.corr || 0);
        const presetTune = (pComb[G.fine] || 0) + (pComb[G.coarse] || 0) * 100;
        const tune = (totalFineTune + presetTune); // Houd dit in cents voor de Worklet

        // 3. Envelope: Correcte SF2 tijd-berekening
        const time = (c) => (c === -12000) ? 0 : Math.pow(2, c / 1200);
        const att = time(getV(G.att, def.att));
        const dec = time(getV(G.dec, def.dec));
        const rel = time(getV(G.rel, def.rel));
        const sus = Math.pow(10, -getV(G.sus, def.sus) / 200); // dB naar ratio

        const loopMode = getV(G.mode, 0);
        const loop = (loopMode === 1 || loopMode === 3);

        regions.push({
          bank: p.bank, preset: p.preset,
          kMin, kMax, vMin, vMax,
          start: sh.start, end: sh.end,
          loopStart: sh.startLoop, loopEnd: sh.endLoop,
          loop, 
          rate: sh.rate, // Dit moet naar de Worklet!
          root, 
          tune, // Nu in cents
          env: { a: att, d: dec, s: sus, r: rel }
        });
      }
    }
  }
  return regions;
}

/* ==========================================================================
   MIDI PARSER WITH CORRECT TIMING
   ========================================================================== */
class MidiParser {
  constructor(buffer) { 
    this.view = new DataView(buffer); 
    this.pos = 0; 
  }
  
  readInt(n) { 
    let x=0; 
    for(let i=0; i<n; i++) x=(x<<8)|this.view.getUint8(this.pos++); 
    return x; 
  }
  
  readVar() { 
    let x=0; 
    while(true) { 
      const b=this.view.getUint8(this.pos++); 
      x=(x<<7)|(b&0x7F); 
      if(!(b&0x80)) return x; 
    } 
  }

  parse() {
    if(this.readInt(4) !== 0x4D546864) throw new Error("Not MIDI");
    this.readInt(4); // len
    const fmt = this.readInt(2);
    const nTrk = this.readInt(2);
    const div = this.readInt(2);

    let allEvents = [];
    let tempo = 500000; // Default tempo (120 BPM)

    for(let i=0; i<nTrk; i++) {
      if(this.readInt(4) !== 0x4D54726B) continue; // Skip non-track
      const len = this.readInt(4);
      const end = this.pos + len;
      let ticks = 0;
      let status = 0;

      while(this.pos < end) {
        const delta = this.readVar();
        ticks += delta;
        let b = this.view.getUint8(this.pos);
        if(b & 0x80) { status = b; this.pos++; }

        const type = status >> 4;
        const ch = status & 0x0F;

        if(status === 0xFF) { // Meta
          const mType = this.view.getUint8(this.pos++);
          const mLen = this.readVar();
          if(mType === 0x51 && mLen === 3) {
            tempo = (this.view.getUint8(this.pos)<<16) | (this.view.getUint8(this.pos+1)<<8) | this.view.getUint8(this.pos+2);
            allEvents.push({ ticks, type:'tempo', val: tempo });
          }
          this.pos += mLen;
        } else if (status === 0xF0 || status === 0xF7) {
          const l = this.readVar(); this.pos += l;
        } else {
          const d1 = this.view.getUint8(this.pos++);
          if(type === 0x9 && d1 > 0) { // Note On
             const d2 = this.view.getUint8(this.pos++);
             if(d2 > 0) allEvents.push({ ticks, type:'on', ch, n:d1, v:d2 });
             else allEvents.push({ ticks, type:'off', ch, n:d1 });
          } else if(type === 0x8) { // Note Off
             const d2 = this.view.getUint8(this.pos++);
             allEvents.push({ ticks, type:'off', ch, n:d1 });
          } else if(type === 0xB) { // CC
             const d2 = this.view.getUint8(this.pos++);
             allEvents.push({ ticks, type:'cc', ch, cc:d1, val:d2 });
          } else if(type === 0xC) { // Prog
             allEvents.push({ ticks, type:'prg', ch, p:d1 });
          } else if(type === 0xE || type === 0xA || type === 0xD) {
             this.view.getUint8(this.pos++); // Skip d2
          }
        }
      }
    }

    // Sort events by tick
    allEvents.sort((a,b) => a.ticks - b.ticks);
    
    // Convert ticks to seconds with proper timing
    const finalEvents = [];
    let currentTempo = 500000; // Default tempo
    let currentTime = 0;
    let lastTick = 0;
    
    for(const event of allEvents) {
      // Calculate time for this event
      const deltaTicks = event.ticks - lastTick;
      
      // Convert ticks to seconds based on current tempo and division
      const secondsPerTick = currentTempo / (1000000.0 * div);
      const deltaTime = deltaTicks * secondsPerTick;
      
      currentTime += deltaTime;
      lastTick = event.ticks;
      
      // Update tempo if this is a tempo event
      if(event.type === 'tempo') {
        currentTempo = event.val;
      } else {
        finalEvents.push({
          ...event,
          time: currentTime
        });
      }
    }
    
    return {
      events: finalEvents,
      duration: currentTime,
      division: div,
      initialTempo: 500000
    };
  }
}



var entryo="Violation Entry ID-99";

/* ==========================================================================
   AUDIO WORKLET WITH CORRECT TIMING
   ========================================================================== */
const workletCode = `
class MidiWorklet extends AudioWorkletProcessor {
  constructor() {
    super();
    this.pcm = null;
    this.regions = [];
    this.presetMap = new Map();
    this.firstPresetKey = null;

    this.voices = [];
    this.channels = new Array(16).fill(0).map(() => ({ bank:0, prog:0 }));

    this.events = [];
    this.evtIdx = 0;
    this.currentTime = 0;
    this.playing = false;
    this.startTime = 0;
    this.pausedTime = 0;
    this.isPaused = false;
    this.progressFrameCount = 0;
    this.updateIntervalFrames = 128 * 15; 

    this.port.onmessage = (e) => {
      const d = e.data;
      if(d.type === 'SF2') {
        this.pcm = d.pcm;
        this.regions = d.regions;
        this.presetMap.clear();
        d.regions.forEach((r, i) => {
          const k = (r.bank<<7) | r.preset;
          if(!this.presetMap.has(k)) this.presetMap.set(k, []);
          this.presetMap.get(k).push(i);
          if(this.firstPresetKey === null) this.firstPresetKey = k;
        });
        this.port.postMessage({t:'log', msg:'Worklet: SF2 Loaded. Regions: ' + d.regions.length});
      }
      else if(d.type === 'MIDI') {
        this.events = d.events;
        this.evtIdx = 0;
        this.currentTime = 0;
        // FIX: use global currentTime provided by AudioWorklet scope
        this.startTime = currentTime; 
        this.pausedTime = 0;
        this.playing = true;
        this.isPaused = false;
        this.voices = [];
        this.port.postMessage({t:'log', msg:'Worklet: MIDI Playing...'});
        this.port.postMessage({t:'duration', duration: d.duration});
      }
      else if(d.type === 'STOP') {
        this.playing = false;
        this.isPaused = false;
        this.voices = [];
        this.port.postMessage({t:'progress', progress: 0});
      }
      else if(d.type === 'PAUSE') {
        this.isPaused = true;
        this.pausedTime = this.currentTime;
      }
      else if(d.type === 'RESUME') {
        this.isPaused = false;
        this.startTime = currentTime - this.pausedTime;
      }
    };
  }

  getRegions(ch, bank, prog) {
    if(ch === 9) {
      let key = (128 << 7) | prog;
      if(this.presetMap.has(key)) return this.presetMap.get(key);
      for(let [k, v] of this.presetMap) {
        if((k >> 7) === 128) return v;
      }
    } else {
      let key = (bank << 7) | prog;
      if(this.presetMap.has(key)) return this.presetMap.get(key);
      key = prog; 
      if(this.presetMap.has(key)) return this.presetMap.get(key);
    }
    if(this.firstPresetKey !== null) return this.presetMap.get(this.firstPresetKey);
    return null;
  }

  process(inputs, outputs) {
    if(!this.pcm || !this.playing || this.isPaused) return true;
    
    const outL = outputs[0][0];
    const outR = outputs[0][1];
    const dt = 128 / sampleRate;

    this.currentTime = currentTime - this.startTime;

    // --- Event Sequencing ---
    while(this.evtIdx < this.events.length) {
      const e = this.events[this.evtIdx];
      if(e.time > this.currentTime + dt) break;

      if(e.type === 'on') {
        const st = this.channels[e.ch];
        const bank = (e.ch === 9) ? 128 : st.bank;
        const indices = this.getRegions(e.ch, bank, st.prog);

        if(indices) {
          for(let i=0; i<indices.length; i++) {
            const r = this.regions[indices[i]];
            if(e.n >= r.kMin && e.n <= r.kMax && e.v >= r.vMin && e.v <= r.vMax) {
// 1. Calculate the base semitone distance from the root key
const semitones = e.n - r.root;

// 2. Convert the total tune cents into fractional semitones, then combine them
const totalSemitones = semitones + (r.tune / 100);

// 3. Compute the correct frequency scaling factor
const fRatio = Math.pow(2, totalSemitones / 12);

// 4. Calculate the stepping rate safely relative to the system's sampleRate
const rate = fRatio * (r.rate / sampleRate);

              this.voices.push({
                idx: indices[i],
                pos: 0, rate: rate,
                ch: e.ch, note: e.n,
                vel: e.v/127,
                state: 0, // 0:Att, 1:Dec, 2:Sus, 3:Rel, 4:Done
                envT: 0, envV: 0, relVol: 0,
                start: r.start, end: r.end,
                loop: r.loop, lStart: r.loopStart, lEnd: r.loopEnd,
                env: r.env
              });
            }
          }
        }
      }
      else if(e.type === 'off') {
        for(let v of this.voices) {
          if(v.ch === e.ch && v.note === e.n && v.state < 3) {
            v.state = 3; // Transition to Release
            v.relVol = v.envV;
            v.envT = 0; // Important: Reset timer for release calculation
          }
        }
      }
      else if(e.type === 'prg') { this.channels[e.ch].prog = e.p; }
      else if(e.type === 'cc' && e.cc === 0) { this.channels[e.ch].bank = e.val; }
      else if(e.type === 'tempo') {
        this.port.postMessage({t:'tempo', bpm: Math.round(60000000 / e.val)});
      }
      this.evtIdx++;
    }

    this.progressFrameCount += 128; 
    if (this.progressFrameCount >= this.updateIntervalFrames) {
        this.progressFrameCount = 0;
        if(this.events.length > 0) {
            const totalT = this.events[this.events.length-1].time;
            this.port.postMessage({t:'progress', progress: Math.min(1, this.currentTime / totalT)});
        }
    }

    if(this.evtIdx >= this.events.length && this.voices.length === 0) {
      this.playing = false;
      this.port.postMessage({t:'done'});
      this.port.postMessage({t:'progress', progress: 1});
    }

    // --- Audio Rendering ---
    for(let i=0; i<128; i++) {
      let L = 0;
      for(let vIdx=0; vIdx < this.voices.length; vIdx++) {
        const v = this.voices[vIdx];
        if(v.state === 4) continue;

        v.envT += (1/sampleRate);
        const e = v.env;
        let amp = 0;

        // CORRECTED ENVELOPE LOGIC
        if(v.state === 0) { // Attack
          amp = v.envT / Math.max(0.001, e.a);
          if(amp >= 1) { amp = 1; v.state = 1; v.envT = 0; }
        } else if(v.state === 1) { // Decay
          amp = 1.0 - (1.0 - e.s) * (v.envT / Math.max(0.001, e.d));
          if(v.envT >= e.d) { amp = e.s; v.state = 2; v.envT = 0; }
        } else if(v.state === 2) { // Sustain
          amp = e.s;
          // Stay here until 'off' event sets state to 3
        } else if(v.state === 3) { // Release
          amp = v.relVol * (1.0 - (v.envT / Math.max(0.001, e.r)));
          if(v.envT >= e.r || amp <= 0) { amp = 0; v.state = 4; }
        }
        v.envV = amp;

        // Sample Rendering
        let pInt = Math.floor(v.pos);
        let idx = v.start + pInt;

        if(v.loop) {
          if(idx >= v.lEnd) {
            v.pos -= (v.lEnd - v.lStart);
            idx = v.start + Math.floor(v.pos);
          }
        } else {
          if(idx >= v.end) { v.state = 4; continue; }
        }

        if(idx < this.pcm.length && idx >= 0) {
          const s = this.pcm[idx] / 32768;
          L += s * amp * v.vel;
        }
        v.pos += v.rate;
      }
      outL[i] = L * 0.25;
      if(outR) outR[i] = L * 0.25;
    }

    // Voice Cleanup
    for(let i=this.voices.length-1; i>=0; i--) {
      if(this.voices[i].state === 4) this.voices.splice(i, 1);
    }

    return true;
  }
}
registerProcessor('midi-proc', MidiWorklet);
`;





/* ==========================================================================
   APP CONTROLLER
   ========================================================================== */
    
var CURRENT_MIDI_FILE ="";
var MIDIF="";
let ctx = null;
let node = null;
let sf2Ready = false;
let midiData = null;
let isPlaying = false;
let isPaused = false;
var gewees=true;

